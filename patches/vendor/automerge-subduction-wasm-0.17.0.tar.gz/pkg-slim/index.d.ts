export * from "./automerge_subduction_wasm.js";
export declare function initFromBase64Wasm(base64Wasm: string): void;
