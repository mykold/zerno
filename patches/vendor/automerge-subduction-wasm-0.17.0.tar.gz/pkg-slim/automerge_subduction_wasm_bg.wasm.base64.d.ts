
  declare module "automerge_subduction_wasm_bg.wasm" {
    export const wasmBase64: string;
  }
