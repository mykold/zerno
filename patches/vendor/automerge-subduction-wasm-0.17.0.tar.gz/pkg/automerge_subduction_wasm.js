/* @ts-self-types="./automerge_subduction_wasm.d.ts" */
import * as wasm from "./automerge_subduction_wasm_bg.wasm";
import { __wbg_set_wasm } from "./automerge_subduction_wasm_bg.js";

__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
export {
    AuthenticatedLongPoll, AuthenticatedTransport, AuthenticatedWebSocket, BatchSyncRequest, BatchSyncResponse, BlobMeta, CallError, CommitId, CommitInput, CommitWithBlob, Depth, Digest, Fragment, FragmentInput, FragmentRequested, FragmentWithBlob, FragmentsArray, HashMetric, IndexedDbStorage, LooseCommit, MemorySigner, MemoryStorage, MessagePortTransport, Nonce, PeerBatchSyncResult, PeerId, PeerResultMap, RequestId, Sedimentree, SedimentreeHeads, SedimentreeId, SedimentreeIdsArray, SignedFragment, SignedLooseCommit, Subduction, SubductionHttpLongPoll, SubductionLongPoll, SubductionWebSocket, SyncMessage, SyncStats, Topic, WebCryptoSigner, clear_subduction_logger, commitIdOfBase58Id, init, makeMessagePortTransport, setSubductionLogLevel, set_subduction_logger
} from "./automerge_subduction_wasm_bg.js";
