/* tslint:disable */
/* eslint-disable */

/**
 * Connection and storage authorization policy.
 *
 * Throwing (or returning a rejected promise) denies the operation.
 * Resolving allows it.
 */
export interface Policy {
    authorizeConnect(peerId: PeerId): Promise<void>;
    authorizeFetch(peerId: PeerId, sedimentreeId: SedimentreeId): Promise<void>;
    authorizePut(requestor: PeerId, author: PeerId, sedimentreeId: SedimentreeId): Promise<void>;
    filterAuthorizedFetch(peerId: PeerId, ids: SedimentreeId[]): Promise<SedimentreeId[]>;
}



/**
 * Cryptographic signer interface.
 *
 * Allows JavaScript code to provide signing implementations (e.g. hardware
 * keys or remote signing services).
 */
export interface Signer {
    /** Sign a message; returns the 64-byte Ed25519 signature (sync or async). */
    sign(message: Uint8Array): Uint8Array | Promise<Uint8Array>;
    /** The 32-byte Ed25519 verifying (public) key. */
    verifyingKey(): Uint8Array;
}



/**
 * Ephemeral message authorization policy.
 *
 * Throwing (or returning a rejected promise) denies the operation.
 * Resolving allows it.
 */
export interface EphemeralPolicy {
    authorizeSubscribe(peerId: PeerId, topic: Topic): Promise<void>;
    authorizePublish(peerId: PeerId, topic: Topic): Promise<void>;
    filterAuthorizedSubscribers(topic: Topic, peers: PeerId[]): Promise<PeerId[]>;
}



/**
 * Handler for keyhive (SUK) protocol frames.
 *
 * Register via `Subduction.registerFrameHandler()`. The two methods
 * mirror the Rust `Handler` trait's `handle` / `on_peer_disconnect`.
 */
export interface FrameHandler {
    /** Called with the CBOR payload (no SUK envelope) for each inbound keyhive frame. */
    onMessage(payload: Uint8Array, peerId: PeerId): void;
    /** Called when a peer's last connection drops. */
    onPeerDisconnect(peerId: PeerId): void;
}



/**
 * Options for constructing a `Subduction` node.
 *
 * Passed as a single object literal: `new Subduction({ signer, storage, ... })`.
 * `signer` and `storage` are required; every other field is optional.
 */
export interface SubductionOptions {
    /** The cryptographic signer for this node's identity. */
    signer: Signer;
    /** Storage backend for persisting data. */
    storage: SedimentreeStorage;
    /**
     * Service identifier for discovery mode (e.g. `sync.example.com`). When
     * set, clients can connect without knowing the server's peer ID.
     */
    serviceName?: string;
    /** Custom depth metric function. */
    hashMetricOverride?: (digest: Digest) => Depth;
    /**
     * Cap on the number of sedimentrees kept resident in memory (default:
     * 1024). `0` or omitted uses the default.
     */
    maxResidentTrees?: number;
    /** Connection/storage authorization policy. Defaults to allow-all. */
    policy?: Policy;
    /** Ephemeral message authorization policy. Defaults to allow-all. */
    ephemeralPolicy?: EphemeralPolicy;
    /** Callback fired when a peer's heads change. */
    onRemoteHeads?: Function;
    /** Callback fired on inbound ephemeral messages. */
    onEphemeral?: Function;
    /**
     * Default per-call total deadline (milliseconds) for roundtrip syncs when
     * a call omits its own `timeoutMilliseconds`. Omit for the built-in
     * default (30000).
     */
    defaultTimeoutMilliseconds?: number;
}



export interface SedimentreeStorage {
    saveSedimentreeId(sedimentreeId: SedimentreeId): Promise<void>;
    deleteSedimentreeId(sedimentreeId: SedimentreeId): Promise<void>;
    loadAllSedimentreeIds(): Promise<SedimentreeId[]>;
    // Optional single-key existence check. When implemented, it is used on the
    // hydration hot path instead of enumerating every id via
    // loadAllSedimentreeIds (which is O(total) — e.g. an IndexedDB getAllKeys).
    // Backends over IndexedDB should implement this as a single `get`/`count`.
    containsSedimentreeId?(sedimentreeId: SedimentreeId): Promise<boolean>;

    // Compound storage for commits (signed data + blob stored together)
    saveCommit(sedimentreeId: SedimentreeId, commitId: CommitId, signedCommit: SignedLooseCommit, blob: Uint8Array): Promise<void>;
    loadCommit(sedimentreeId: SedimentreeId, commitId: CommitId): Promise<CommitWithBlob | null>;
    listCommitIds(sedimentreeId: SedimentreeId): Promise<CommitId[]>;
    loadAllCommits(sedimentreeId: SedimentreeId): Promise<CommitWithBlob[]>;
    deleteCommit(sedimentreeId: SedimentreeId, commitId: CommitId): Promise<void>;
    deleteAllCommits(sedimentreeId: SedimentreeId): Promise<void>;

    // Compound storage for fragments (signed data + blob stored together)
    saveFragment(sedimentreeId: SedimentreeId, fragmentHead: CommitId, signedFragment: SignedFragment, blob: Uint8Array): Promise<void>;
    loadFragment(sedimentreeId: SedimentreeId, fragmentHead: CommitId): Promise<FragmentWithBlob | null>;
    listFragmentIds(sedimentreeId: SedimentreeId): Promise<CommitId[]>;
    loadAllFragments(sedimentreeId: SedimentreeId): Promise<FragmentWithBlob[]>;
    deleteFragment(sedimentreeId: SedimentreeId, fragmentHead: CommitId): Promise<void>;
    deleteAllFragments(sedimentreeId: SedimentreeId): Promise<void>;

    // Batch save: write all commits + fragments in a single storage transaction.
    saveBatchAll(sedimentreeId: SedimentreeId, commits: Array<{commitId: CommitId, signedCommit: SignedLooseCommit, blob: Uint8Array}>, fragments: Array<{fragmentHead: CommitId, signedFragment: SignedFragment, blob: Uint8Array}>): Promise<number>;
}



export interface Transport {
    sendBytes(bytes: Uint8Array): Promise<void>;
    recvBytes(): Promise<Uint8Array>;
    disconnect(): Promise<void>;
    onDisconnect(callback: () => void): void;
}



/**
 * An authenticated HTTP long-poll transport.
 *
 * This wrapper proves that the transport has completed the Subduction handshake
 * and the peer identity has been cryptographically verified.
 *
 * Obtain via [`SubductionLongPoll::tryConnect`] or [`SubductionLongPoll::tryDiscover`].
 */
export class AuthenticatedLongPoll {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Convert to a transport-erased [`AuthenticatedTransport`](super::authenticated::WasmAuthenticatedTransport).
     */
    toTransport(): AuthenticatedTransport;
    /**
     * The verified peer identity.
     */
    readonly peerId: PeerId;
    /**
     * The session ID assigned by the server.
     */
    readonly sessionId: string;
}

/**
 * A transport-erased authenticated transport.
 *
 * Wraps an [`Authenticated<MessageTransport<JsTransport>>`] and is the common type
 * accepted by [`addConnection`](crate::subduction::WasmSubduction::add_connection).
 *
 * # Construction
 *
 * There are three ways to obtain an `AuthenticatedTransport`:
 *
 * 1. **Custom transport** — implement the `Transport` interface
 *    (`sendBytes`/`recvBytes`/`disconnect`/`onDisconnect`) and call
 *    [`setup`](Self::setup):
 *
 *    ```js
 *    const auth = await AuthenticatedTransport.setup(myTransport, signer, peerId, (peerId) => {
 *        console.log(`${peerId} disconnected`);
 *    });
 *    ```
 *
 * 2. **From WebSocket** — authenticate via [`SubductionWebSocket`] then convert:
 *
 *    ```js
 *    const wsAuth = await SubductionWebSocket.tryConnect(url, signer, peerId, (peerId) => {
 *        console.log(`${peerId} disconnected`);
 *    });
 *    const auth = wsAuth.toTransport();
 *    ```
 *
 * 3. **From HTTP long-poll** — same pattern via [`SubductionLongPoll`]:
 *
 *    ```js
 *    const lpAuth = await SubductionLongPoll.tryConnect(url, signer, peerId, (peerId) => {
 *        console.log(`${peerId} disconnected`);
 *    });
 *    const auth = lpAuth.toTransport();
 *    ```
 */
export class AuthenticatedTransport {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Accept an incoming handshake over a custom transport (responder side).
     *
     * This is the counterpart to [`setup`](Self::setup). The initiator calls
     * `setup`, and the responder calls `accept` over the same underlying channel.
     *
     * # Arguments
     *
     * * `transport` - A `Transport` implementing `sendBytes`/`recvBytes`/`disconnect`/`onDisconnect`
     * * `signer` - The responder's signer for authentication
     * * `max_drift_seconds` - Maximum acceptable clock drift in seconds (default: 600)
     *
     * # Errors
     *
     * Returns a [`HandshakeError`](WasmHandshakeError) if the handshake fails.
     */
    static accept(transport: Transport, signer: Signer, max_drift_seconds?: number | null, on_disconnect?: Function | null): Promise<AuthenticatedTransport>;
    /**
     * Run the Subduction handshake over a custom transport, producing an
     * authenticated transport.
     *
     * The `transport` object must implement the `Transport` interface
     * (`sendBytes`/`recvBytes`/`disconnect`/`onDisconnect`).
     * The same object is used for both the handshake phase and post-handshake
     * communication.
     *
     * # Arguments
     *
     * * `transport` - A `Transport` implementing `sendBytes`/`recvBytes`/`disconnect`/`onDisconnect`
     * * `signer` - The client's signer for authentication
     * * `expected_peer_id` - The expected server peer ID (verified during handshake)
     *
     * # Errors
     *
     * Returns a [`HandshakeError`](WasmHandshakeError) if the handshake fails.
     */
    static setup(transport: Transport, signer: Signer, expected_peer_id: PeerId, on_disconnect?: Function | null): Promise<AuthenticatedTransport>;
    /**
     * Run the Subduction handshake over a custom transport using discovery
     * mode, producing an authenticated transport.
     *
     * Unlike [`setup`](Self::setup) which requires a known peer ID,
     * this method discovers the peer's identity during the handshake
     * using a shared service name.
     *
     * # Arguments
     *
     * * `transport` - A `Transport` implementing `sendBytes`/`recvBytes`/`disconnect`/`onDisconnect`
     * * `signer` - The client's signer for authentication
     * * `service_name` - Shared service name for discovery.
     *   Defaults to [`DEFAULT_LOCAL_SERVICE_NAME`] (`"subduction:local"`) if omitted.
     *
     * # Errors
     *
     * Returns a [`HandshakeError`](WasmHandshakeError) if the handshake fails.
     */
    static setupDiscover(transport: Transport, signer: Signer, service_name?: string | null, on_disconnect?: Function | null): Promise<AuthenticatedTransport>;
    /**
     * The verified peer identity.
     */
    readonly peerId: PeerId;
}

/**
 * An authenticated WebSocket transport.
 *
 * This wrapper proves that the connection has completed the Subduction handshake
 * and the peer identity has been cryptographically verified.
 *
 * Obtain via [`SubductionWebSocket::setup`], [`SubductionWebSocket::tryConnect`],
 * or [`SubductionWebSocket::tryDiscover`].
 */
export class AuthenticatedWebSocket {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Convert to a transport-erased [`AuthenticatedTransport`](super::authenticated::WasmAuthenticatedTransport).
     */
    toTransport(): AuthenticatedTransport;
    /**
     * The verified peer identity.
     */
    readonly peerId: PeerId;
}

/**
 * Wasm wrapper for [`BatchSyncRequest`].
 */
export class BatchSyncRequest {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * The sedimentree ID this request corresponds to.
     */
    id(): SedimentreeId;
    /**
     * The request ID for this request.
     */
    request_id(): RequestId;
    /**
     * Whether this request subscribes to future updates.
     */
    subscribe(): boolean;
}

/**
 * Wasm wrapper for [`BatchSyncResponse`].
 */
export class BatchSyncResponse {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Upcasts; to the JS-import type for [`WasmBatchSyncResponse`].
     */
    __wasm_refgen_toWasmBatchSyncResponse(): BatchSyncResponse;
    /**
     * The sedimentree ID this response corresponds to.
     */
    id(): SedimentreeId;
    /**
     * The request ID this response corresponds to.
     */
    request_id(): RequestId;
}

/**
 * A Wasm wrapper around the [`BlobMeta`] type.
 */
export class BlobMeta {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Get the digest of the blob.
     */
    digest(): Digest;
    /**
     * Create a `BlobMeta` from a digest and size.
     *
     * This is useful for deserialization when the original blob is not available.
     * Since this is manual, the caller must ensure the digest and size are correct.
     */
    static fromDigestSize(digest: Digest, size_bytes: bigint): BlobMeta;
    /**
     * Create a new `BlobMeta` from the given blob contents.
     */
    constructor(blob: Uint8Array);
    /**
     * Get the size of the blob in bytes.
     */
    readonly sizeBytes: bigint;
}

/**
 * Wasm wrapper for call errors.
 */
export class CallError {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
}

/**
 * A user-supplied opaque identifier for a loose commit.
 *
 * Unlike [`Digest`](crate::digest::WasmDigest), which is a content hash
 * computed by the system, `CommitId` is provided by the caller at construction
 * time. This is the identity used for DAG traversal, fragment boundaries,
 * and sync.
 */
export class CommitId {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Upcasts; to the JS-import type for [`WasmCommitId`].
     */
    __wasm_refgen_toWasmCommitId(): CommitId;
    /**
     * Creates a new commit identifier from its Base58 string representation.
     *
     * # Errors
     *
     * Returns an error if the string cannot be decoded or is not 32 bytes.
     */
    static fromBase58(s: string): CommitId;
    /**
     * Creates a new commit identifier from its byte representation.
     *
     * # Errors
     *
     * Returns an error if the byte slice is not exactly 32 bytes.
     */
    static fromBytes(bytes: Uint8Array): CommitId;
    /**
     * Creates a new commit identifier from its hexadecimal string representation.
     *
     * # Errors
     *
     * Returns an error if the string is not valid hex or not 32 bytes.
     */
    static fromHexString(s: string): CommitId;
    /**
     * Creates a new commit identifier from its byte representation.
     *
     * # Errors
     *
     * Returns an error if the byte slice is not exactly 32 bytes.
     */
    constructor(bytes: Uint8Array);
    /**
     * Returns the byte representation of the commit identifier.
     */
    toBytes(): Uint8Array;
    /**
     * Returns the hexadecimal string representation.
     */
    toHexString(): string;
}

/**
 * One unsigned commit + its blob, ready for bulk insertion.
 *
 * Construct with `new CommitInput(looseCommit, blob)` from JavaScript;
 * pass arrays of these to the batch write methods
 * ([`addBatch`](crate::subduction::WasmSubduction::add_batch) /
 * [`storeBuiltBatch`](crate::subduction::WasmSubduction::store_built_batch),
 * [`addCommitsBatch`](crate::subduction::WasmSubduction::add_commits_batch) /
 * [`storeCommitsBatch`](crate::subduction::WasmSubduction::store_commits_batch)).
 */
export class CommitInput {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Pair an unsigned [`LooseCommit`](sedimentree_core::loose_commit::LooseCommit)
     * with the bytes of its associated blob.
     *
     * `blob` accepts any `BufferSource`-like value from JavaScript
     * (`Uint8Array`, `ArrayBuffer`, plain `number[]`); `wasm_bindgen` copies
     * the bytes into a `Vec<u8>` owned by this struct.
     */
    constructor(commit: LooseCommit, blob: Uint8Array);
    /**
     * A copy of the blob bytes.
     */
    readonly blob: Uint8Array;
    /**
     * A copy of the underlying unsigned commit.
     */
    readonly commit: LooseCommit;
}

/**
 * A commit stored with its associated blob.
 */
export class CommitWithBlob {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Upcasts; to the JS-import type for [`WasmCommitWithBlob`].
     */
    __wasm_refgen_toWasmCommitWithBlob(): CommitWithBlob;
    /**
     * Create a new commit with blob.
     */
    constructor(signed: SignedLooseCommit, blob: Uint8Array);
    /**
     * Get the blob.
     */
    readonly blob: Uint8Array;
    /**
     * Get the signed commit.
     */
    readonly signed: SignedLooseCommit;
}

/**
 * A JavaScript wrapper around `Depth`.
 */
export class Depth {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Internal method for a hack crossing the JS boundary.
     */
    __subduction_castToDepth(): Depth;
    /**
     * Upcasts; to the JS-import type for [`WasmDepth`].
     */
    __wasm_refgen_toWasmDepth(): Depth;
    /**
     * Creates a new `WasmDepth` from a JavaScript value.
     *
     * # Errors
     *
     * Returns a `NotU32Error` if the JS value is not safely coercible to `u32`.
     */
    constructor(js_value: any);
    /**
     * Whether this depth qualifies the commit as an eligible fragment head.
     *
     * Returns `true` for any nonzero depth. Mirrors
     * [`Depth::is_boundary`](sedimentree_core::depth::Depth::is_boundary).
     * Use this from JavaScript instead of comparing `value > 0` directly so
     * the boundary semantic stays in lock-step with the Rust definition.
     */
    readonly isBoundary: boolean;
    /**
     * The depth value as an integer.
     */
    readonly value: number;
}

/**
 * A wrapper around digest bytes for use in JavaScript via wasm-bindgen.
 *
 * Since JavaScript doesn't have Rust's type system, this stores raw bytes
 * and converts to/from typed `Digest<T>` at the Rust boundary.
 */
export class Digest {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Upcasts; to the JS-import type for [`WasmDigest`].
     */
    __wasm_refgen_toWasmDigest(): Digest;
    /**
     * Creates a new digest from its Base58 string representation.
     *
     * # Errors
     *
     * Returns a `WasmInvalidDigest` error if the string cannot be decoded or is not a valid digest.
     */
    static fromBase58(s: string): Digest;
    /**
     * Creates a new digest from its byte representation.
     *
     * # Errors
     *
     * Returns a `WasmValue` error if the byte slice is not a valid digest.
     */
    static fromBytes(bytes: Uint8Array): Digest;
    /**
     * Creates a new digest from its hexadecimal string representation.
     *
     * # Errors
     *
     * Returns a [`WasmInvalidDigest`] if the string is not a valid digest.
     */
    static fromHexString(s: string): Digest;
    /**
     * Creates a new digest from its byte representation.
     *
     * # Errors
     *
     * Returns a `WasmValue` error if the byte slice is not a valid digest.
     */
    constructor(bytes: Uint8Array);
    /**
     * Returns the byte representation of the digest.
     */
    toBytes(): Uint8Array;
    /**
     * Returns the hexadecimal string representation of the digest.
     */
    toHexString(): string;
}

/**
 * A data fragment used in the Sedimentree system.
 */
export class Fragment {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Upcasts; to the JS-import type for [`WasmFragment`].
     */
    __wasm_refgen_toWasmFragment(): Fragment;
    /**
     * Create a new fragment from the given sedimentree ID, head, boundary, checkpoints, and blob metadata.
     */
    constructor(sedimentree_id: SedimentreeId, head: CommitId, boundary: CommitId[], checkpoints: CommitId[], blob_meta: BlobMeta);
    /**
     * Get the blob metadata of the fragment.
     */
    readonly blobMeta: BlobMeta;
    /**
     * Get the boundary commit identifiers of the fragment.
     */
    readonly boundary: CommitId[];
    /**
     * Get the head commit identifier of the fragment.
     */
    readonly head: CommitId;
}

/**
 * One unsigned fragment + its blob, ready for bulk insertion.
 *
 * Construct with `new FragmentInput(fragment, blob)` from JavaScript;
 * pass arrays of these to the batch write methods
 * ([`addBatch`](crate::subduction::WasmSubduction::add_batch) /
 * [`storeBuiltBatch`](crate::subduction::WasmSubduction::store_built_batch),
 * [`addFragmentsBatch`](crate::subduction::WasmSubduction::add_fragments_batch) /
 * [`storeFragmentsBatch`](crate::subduction::WasmSubduction::store_fragments_batch)).
 */
export class FragmentInput {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Pair an unsigned [`Fragment`](sedimentree_core::fragment::Fragment)
     * with the bytes of its associated blob.
     *
     * `blob` accepts any `BufferSource`-like value from JavaScript
     * (`Uint8Array`, `ArrayBuffer`, plain `number[]`); `wasm_bindgen` copies
     * the bytes into a `Vec<u8>` owned by this struct.
     */
    constructor(fragment: Fragment, blob: Uint8Array);
    /**
     * A copy of the blob bytes.
     */
    readonly blob: Uint8Array;
    /**
     * A copy of the underlying unsigned fragment.
     */
    readonly fragment: Fragment;
}

/**
 * A request for a specific fragment in the Sedimentree system.
 */
export class FragmentRequested {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Create a new fragment request from the given commit ID.
     */
    constructor(commit_id: CommitId, depth: Depth);
    /**
     * Get the depth of the requested fragment.
     */
    readonly depth: Depth;
    /**
     * Get the head commit identifier of the requested fragment.
     */
    readonly head: CommitId;
}

/**
 * A fragment stored with its associated blob.
 */
export class FragmentWithBlob {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Upcasts; to the JS-import type for [`WasmFragmentWithBlob`].
     */
    __wasm_refgen_toWasmFragmentWithBlob(): FragmentWithBlob;
    /**
     * Create a new fragment with blob.
     */
    constructor(signed: SignedFragment, blob: Uint8Array);
    /**
     * Get the blob.
     */
    readonly blob: Uint8Array;
    /**
     * Get the signed fragment.
     */
    readonly signed: SignedFragment;
}

export class FragmentsArray {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Upcasts; to the JS-import type for [`WasmFragmentsArray`].
     */
    __wasm_refgen_toWasmFragmentsArray(): FragmentsArray;
}

/**
 * An overridable hash metric.
 */
export class HashMetric {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Create a new `WasmHashMetric` with an optional JavaScript function.
     *
     * Defaults to counting leading zero bytes if no function is provided.
     */
    constructor(func?: Function | null);
}

/**
 * `IndexedDB` storage backend with compound storage (signed + blob together).
 */
export class IndexedDbStorage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Delete all commits for a sedimentree.
     *
     * # Errors
     *
     * Returns a [`WasmDeleteAllCommitsError`] if commits could not be deleted.
     */
    deleteAllCommits(sedimentree_id: SedimentreeId): Promise<void>;
    /**
     * Delete all fragments for a sedimentree.
     *
     * # Errors
     *
     * Returns a [`WasmDeleteAllFragmentsError`] if fragments could not be deleted.
     */
    deleteAllFragments(sedimentree_id: SedimentreeId): Promise<void>;
    /**
     * Delete a commit by digest.
     *
     * # Errors
     *
     * Returns a [`WasmDeleteCommitError`] if the commit could not be deleted.
     */
    deleteCommit(sedimentree_id: SedimentreeId, commit_id: CommitId): Promise<void>;
    /**
     * Delete a fragment by its identifier.
     *
     * # Errors
     *
     * Returns a [`WasmDeleteFragmentError`] if the fragment could not be deleted.
     */
    deleteFragment(sedimentree_id: SedimentreeId, fragment_head: CommitId): Promise<void>;
    /**
     * Delete a Sedimentree ID from storage.
     *
     * # Errors
     *
     * Returns [`WasmDeleteSedimentreeIdError`] if deletion failed.
     */
    deleteSedimentreeId(sedimentree_id: SedimentreeId): Promise<void>;
    /**
     * Get the name of the fragment store.
     */
    fragmentStoreName(): string;
    /**
     * List all commit IDs for a sedimentree.
     *
     * # Errors
     *
     * Returns a [`WasmListDigestsError`] if commit IDs could not be listed.
     */
    listCommitIds(sedimentree_id: SedimentreeId): Promise<CommitId[]>;
    /**
     * List all fragment IDs for a sedimentree.
     *
     * # Errors
     *
     * Returns a [`WasmListDigestsError`] if fragment IDs could not be listed.
     */
    listFragmentIds(sedimentree_id: SedimentreeId): Promise<CommitId[]>;
    /**
     * Load all commits for a sedimentree, returning `CommitWithBlob[]`.
     *
     * # Errors
     *
     * Returns a [`WasmLoadAllCommitsError`] if commits could not be loaded.
     */
    loadAllCommits(sedimentree_id: SedimentreeId): Promise<CommitWithBlob[]>;
    /**
     * Load all fragments for a sedimentree, returning `FragmentWithBlob[]`.
     *
     * # Errors
     *
     * Returns a [`WasmLoadAllFragmentsError`] if fragments could not be loaded.
     */
    loadAllFragments(sedimentree_id: SedimentreeId): Promise<FragmentWithBlob[]>;
    /**
     * Load all Sedimentree IDs from storage.
     *
     * # Errors
     *
     * Returns [`WasmLoadAllSedimentreeIdsError`] if there was a problem loading.
     */
    loadAllSedimentreeIds(): Promise<SedimentreeId[]>;
    /**
     * Load a commit by its identifier, returning `CommitWithBlob` or null.
     *
     * # Errors
     *
     * Returns a [`WasmLoadCommitError`] if the commit could not be loaded.
     */
    loadCommit(sedimentree_id: SedimentreeId, commit_id: CommitId): Promise<CommitWithBlob | undefined>;
    /**
     * Load a fragment by its identifier, returning `FragmentWithBlob` or null.
     *
     * # Errors
     *
     * Returns a [`WasmLoadFragmentError`] if the fragment could not be loaded.
     */
    loadFragment(sedimentree_id: SedimentreeId, fragment_head: CommitId): Promise<FragmentWithBlob | undefined>;
    /**
     * Get the name of the loose commit store.
     */
    looseCommitStoreName(): string;
    /**
     * Save a batch of commits and fragments in a single IDB transaction.
     *
     * Each commit element must be a JS object with `{commitId, signedCommit, blob}`.
     * Each fragment element must be a JS object with `{fragmentHead, signedFragment, blob}`.
     * This matches the shape produced by `JsStorage::save_batch`.
     *
     * The sedimentree ID is _not_ registered here — the caller
     * (`JsStorage::save_batch`) handles that via a separate
     * `saveSedimentreeId` call so the contract is enforced at the
     * duck-typed layer regardless of backend.
     *
     * # Errors
     *
     * Returns [`WasmSaveBatchAllError`] on transaction, store access, or
     * record extraction failures.
     */
    saveBatchAll(sedimentree_id: SedimentreeId, commits: Array<any>, fragments: Array<any>): Promise<number>;
    /**
     * Save a commit with its blob to storage (compound storage).
     *
     * The `commit_id` parameter is used as the storage key and _must_
     * match the `head()` embedded in the signed commit payload. The
     * caller is responsible for maintaining this invariant; the storage
     * layer does not decode the signed payload to verify it.
     *
     * # Errors
     *
     * Returns a [`WasmSaveCommitError`] if the commit could not be saved.
     */
    saveCommit(sedimentree_id: SedimentreeId, commit_id: CommitId, signed: SignedLooseCommit, blob: Uint8Array): Promise<void>;
    /**
     * Save a fragment with its blob to storage (compound storage).
     *
     * # Errors
     *
     * Returns a [`WasmSaveFragmentError`] if the fragment could not be saved.
     */
    saveFragment(sedimentree_id: SedimentreeId, fragment_head: CommitId, signed: SignedFragment, blob: Uint8Array): Promise<void>;
    /**
     * Insert a Sedimentree ID into storage.
     *
     * # Errors
     *
     * Returns [`WasmSaveSedimentreeIdError`] if saving a [`SedimentreeId`] fails.
     */
    saveSedimentreeId(sedimentree_id: SedimentreeId): Promise<void>;
    /**
     * Get the name of the `sedimentreeId` store.
     */
    sedimentreeIdStoreName(): string;
    /**
     * Create a new `IndexedDbStorage` instance, opening (or creating) the database.
     *
     * If `name` is `None`, uses the default database name
     * `"@automerge/subduction/db"`.
     *
     * Pass a custom name for multi-tenant scenarios or isolated storage
     * instances within the same origin.
     *
     * # Errors
     *
     * Returns a `JsValue` if the database could not be opened.
     */
    static setup(factory: IDBFactory, name?: string | null): Promise<IndexedDbStorage>;
}

/**
 * A Wasm wrapper around the [`LooseCommit`] type.
 */
export class LooseCommit {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Upcasts; to the JS-import type for [`WasmLooseCommit`].
     */
    __wasm_refgen_toWasmLooseCommit(): LooseCommit;
    /**
     * Create a new `LooseCommit` from the given sedimentree ID, head, parents, and blob metadata.
     */
    constructor(sedimentree_id: SedimentreeId, head: CommitId, parents: CommitId[], blob_meta: BlobMeta);
    /**
     * Get the blob metadata of the commit.
     */
    readonly blobMeta: BlobMeta;
    /**
     * Get the commit's head identifier.
     */
    readonly commitId: CommitId;
    /**
     * Get the digest of the commit (content hash).
     */
    readonly digest: Digest;
    /**
     * Get the parent commit identifiers.
     */
    readonly parents: CommitId[];
}

/**
 * An in-memory Ed25519 signer exposed to JavaScript.
 *
 * Implements the `Signer` interface (`sign` / `verifyingKey`) so it can be
 * passed anywhere a [`JsSigner`](crate::signer::JsSigner) is expected.
 *
 * # Example
 *
 * ```javascript
 * import { MemorySigner } from "@automerge/subduction";
 *
 * const signer = MemorySigner.generate();
 * console.log("Peer ID:", signer.peerId().toString());
 * ```
 */
export class MemorySigner {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Create a signer from raw 32-byte Ed25519 secret key bytes.
     *
     * # Errors
     *
     * Returns an error if `bytes` is not exactly 32 bytes.
     */
    static fromBytes(bytes: Uint8Array): MemorySigner;
    /**
     * Create a new signer with a randomly generated Ed25519 key.
     *
     * # Panics
     *
     * Panics if the system random number generator fails.
     */
    static generate(): MemorySigner;
    /**
     * Create a new signer with a randomly generated Ed25519 key.
     *
     * This is the JS constructor (`new MemorySigner()`), equivalent to
     * [`generate`](Self::generate).
     *
     * # Panics
     *
     * Panics if the system random number generator fails.
     */
    constructor();
    /**
     * Get the peer ID derived from this signer's verifying key.
     */
    peerId(): PeerId;
    /**
     * Sign a message and return the 64-byte Ed25519 signature as a `Uint8Array`.
     *
     * This fulfils the `Signer.sign(message)` interface contract.
     * Returns a `Promise<Uint8Array>` for consistency with the async signer interface.
     */
    sign(message: Uint8Array): Promise<Uint8Array>;
    /**
     * Get the 32-byte Ed25519 verifying (public) key as a `Uint8Array`.
     *
     * This fulfils the `Signer.verifyingKey()` interface contract.
     */
    verifyingKey(): Uint8Array;
}

/**
 * An in-memory storage implementation for use in tests and development.
 *
 * This wraps the core `MemoryStorage` and exposes it via the `SedimentreeStorage` interface.
 */
export class MemoryStorage {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Single-key existence check for a sedimentree id (O(1)).
     *
     * Implements the optional `containsSedimentreeId` storage method so the
     * hydration hot path avoids enumerating every id.
     */
    containsSedimentreeId(sedimentree_id: SedimentreeId): Promise<any>;
    /**
     * Delete all commits for a sedimentree.
     */
    deleteAllCommits(sedimentree_id: SedimentreeId): Promise<any>;
    /**
     * Delete all fragments for a sedimentree.
     */
    deleteAllFragments(sedimentree_id: SedimentreeId): Promise<any>;
    /**
     * Delete a single commit by its ID.
     */
    deleteCommit(sedimentree_id: SedimentreeId, commit_id: CommitId): Promise<any>;
    /**
     * Delete a fragment by its identifier.
     */
    deleteFragment(sedimentree_id: SedimentreeId, fragment_head: CommitId): Promise<any>;
    /**
     * Delete a sedimentree ID.
     */
    deleteSedimentreeId(sedimentree_id: SedimentreeId): Promise<any>;
    /**
     * List all commit IDs for a sedimentree.
     */
    listCommitIds(sedimentree_id: SedimentreeId): Promise<any>;
    /**
     * List all fragment IDs for a sedimentree.
     */
    listFragmentIds(sedimentree_id: SedimentreeId): Promise<any>;
    /**
     * Load all commits for a sedimentree, returning `CommitWithBlob[]`.
     */
    loadAllCommits(sedimentree_id: SedimentreeId): Promise<any>;
    /**
     * Load all fragments for a sedimentree, returning `FragmentWithBlob[]`.
     */
    loadAllFragments(sedimentree_id: SedimentreeId): Promise<any>;
    /**
     * Load all sedimentree IDs.
     */
    loadAllSedimentreeIds(): Promise<any>;
    /**
     * Load a single commit by its ID, returning `CommitWithBlob` or null.
     */
    loadCommit(sedimentree_id: SedimentreeId, commit_id: CommitId): Promise<any>;
    /**
     * Load a fragment by its identifier, returning `FragmentWithBlob` or null.
     */
    loadFragment(sedimentree_id: SedimentreeId, fragment_head: CommitId): Promise<any>;
    /**
     * Create a new in-memory storage instance.
     */
    constructor();
    /**
     * Save commits and fragments in a single batch.
     */
    saveBatchAll(sedimentree_id: SedimentreeId, commits: Array<any>, fragments: Array<any>): Promise<any>;
    /**
     * Save a commit with its blob.
     *
     * The `commit_id` parameter must match the `head()` embedded in
     * the signed commit payload. Returns an error if they differ.
     *
     * # Errors
     *
     * Returns a JS error if:
     * - The signed payload cannot be decoded
     * - The `commit_id` does not match the embedded `head()`
     */
    saveCommit(sedimentree_id: SedimentreeId, commit_id: CommitId, signed_commit: SignedLooseCommit, blob: Uint8Array): Promise<any>;
    /**
     * Save a fragment with its blob.
     */
    saveFragment(sedimentree_id: SedimentreeId, _fragment_head: CommitId, signed_fragment: SignedFragment, blob: Uint8Array): Promise<any>;
    /**
     * Save a sedimentree ID.
     */
    saveSedimentreeId(sedimentree_id: SedimentreeId): Promise<any>;
}

/**
 * A `Transport` backed by a `MessagePort` (or any object with
 * `postMessage` / `onmessage` / `close`).
 *
 * Implements the byte-oriented `Transport` interface (`sendBytes`,
 * `recvBytes`, `disconnect`) using the port as the underlying channel.
 * After the handshake, the [`Authenticated`] wrapper provides the sync API.
 */
export class MessagePortTransport {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Disconnect (close the port) and fire the `onDisconnect` callback
     * if registered. The callback is taken out of the cell before
     * invocation, so it may safely re-enter the transport (e.g. to
     * register a new callback) without tripping a `BorrowMutError`.
     */
    disconnect(): Promise<any>;
    /**
     * Create a new connection wrapping the given `MessagePort`.
     */
    constructor(port: any);
    /**
     * Register a callback to be invoked when the transport disconnects.
     * Part of the [`Transport`](super::JsTransport) interface contract.
     */
    onDisconnect(callback: Function): void;
    /**
     * Receive raw bytes (for the handshake phase).
     */
    recvBytes(): Promise<any>;
    /**
     * Send raw bytes (for the handshake phase).
     */
    sendBytes(bytes: Uint8Array): Promise<any>;
}

/**
 * A 64-bit nonce represented as big-endian bytes.
 */
export class Nonce {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Create a new [`WasmNonce`] from exactly 8 big-endian bytes.
     *
     * # Errors
     *
     * Returns [`WasmNonceError`] if the input is not exactly 8 bytes.
     */
    constructor(bytes: Uint8Array);
    /**
     * Generate a random nonce.
     *
     * # Panics
     *
     * Panics if the system random number generator fails.
     */
    static random(): Nonce;
    /**
     * Get the nonce as big-endian bytes.
     */
    readonly bytes: Uint8Array;
}

/**
 * Result of a peer batch sync request.
 */
export class PeerBatchSyncResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Statistics about the sync operation.
     */
    readonly stats: SyncStats;
    /**
     * Whether the batch sync was successful with at least one connection.
     */
    readonly success: boolean;
    /**
     * Errors that occurred during the batch sync.
     */
    readonly transportErrors: Error[];
}

/**
 * A JavaScript-compatible wrapper around the Rust `PeerId` type.
 */
export class PeerId {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Creates a new `WasmPeerId` from a `PeerId`.
     *
     * # Errors
     *
     * Returns a `WasmInvalidPeerId` if the provided byte slice is not exactly 32 bytes long.
     */
    constructor(bytes: Uint8Array);
    /**
     * Returns the byte representation of the `PeerId`.
     */
    toBytes(): Uint8Array;
    /**
     * Returns the string representation of the `PeerId`.
     */
    toString(): string;
}

/**
 * Map of peer IDs to their batch sync results.
 */
export class PeerResultMap {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Get all entries in the peer result map.
     */
    entries(): PeerBatchSyncResult[];
    /**
     * Get the result for a specific peer ID.
     */
    getResult(peer_id: PeerId): PeerBatchSyncResult | undefined;
}

/**
 * Wasm wrapper for [`RequestId`].
 */
export class RequestId {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Upcasts; to the JS-import type for [`WasmRequestId`].
     */
    __wasm_refgen_toWasmRequestId(): RequestId;
    /**
     * Create a new [`RequestId`] from a requestor peer ID and nonce.
     */
    constructor(requestor: PeerId, nonce: Nonce);
    /**
     * The request nonce.
     */
    readonly nonce: Nonce;
    /**
     * The peer ID of the requestor.
     */
    readonly requestor: PeerId;
}

/**
 * The main Sedimentree data structure.
 */
export class Sedimentree {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Create an empty Sedimentree.
     */
    static empty(): Sedimentree;
    /**
     * Create a new Sedimentree from fragments and loose commits.
     */
    constructor(fragments: Fragment[], commits: LooseCommit[]);
}

/**
 * Heads of a single sedimentree, returned by
 * [`WasmSubduction::get_all_heads`](WasmSubduction::get_all_heads).
 */
export class SedimentreeHeads {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * The current heads of the sedimentree.
     */
    readonly heads: CommitId[];
    /**
     * The sedimentree ID these heads belong to.
     */
    readonly id: SedimentreeId;
}

/**
 * A Wasm wrapper around the [`SedimentreeId`] type.
 */
export class SedimentreeId {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Upcasts; to the JS-import type for [`WasmSedimentreeId`].
     */
    __wasm_refgen_toWasmSedimentreeId(): SedimentreeId;
    /**
     * Create an ID from a byte array.
     *
     * # Errors
     *
     * Returns `Not32Bytes` if the provided byte array is not exactly 32 bytes long.
     */
    static fromBytes(bytes: Uint8Array): SedimentreeId;
    /**
     * Returns the raw bytes of this ID.
     */
    toBytes(): Uint8Array;
    /**
     * Returns the string representation of the ID.
     */
    toString(): string;
}

export class SedimentreeIdsArray {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Upcasts; to the JS-import type for [`WasmSedimentreeIdsArray`].
     */
    __wasm_refgen_toWasmSedimentreeIdsArray(): SedimentreeIdsArray;
}

/**
 * A Wasm wrapper around `Signed<Fragment>`.
 */
export class SignedFragment {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Upcasts; to the JS-import type for [`WasmSignedFragment`].
     */
    __wasm_refgen_toWasmSignedFragment(): SignedFragment;
    /**
     * Encode this signed fragment to raw bytes.
     */
    encode(): Uint8Array;
    /**
     * Decode a `SignedFragment` from raw bytes.
     *
     * # Errors
     *
     * Returns an error if the bytes are not a valid signed fragment.
     */
    static tryDecode(bytes: Uint8Array): SignedFragment;
    /**
     * Get the unsigned payload without re-verifying the signature.
     *
     * # Errors
     *
     * Returns an error if the payload cannot be decoded.
     */
    readonly payload: Fragment;
}

/**
 * A Wasm wrapper around `Signed<LooseCommit>`.
 */
export class SignedLooseCommit {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Upcasts; to the JS-import type for [`WasmSignedLooseCommit`].
     */
    __wasm_refgen_toWasmSignedLooseCommit(): SignedLooseCommit;
    /**
     * Encode this signed loose commit to raw bytes.
     */
    encode(): Uint8Array;
    /**
     * Decode a `SignedLooseCommit` from raw bytes.
     *
     * # Errors
     *
     * Returns an error if the bytes are not a valid signed loose commit.
     */
    static tryDecode(bytes: Uint8Array): SignedLooseCommit;
    /**
     * Get the unsigned payload without re-verifying the signature.
     *
     * # Errors
     *
     * Returns an error if the payload cannot be decoded.
     */
    readonly payload: LooseCommit;
}

/**
 * Wasm bindings for [`Subduction`](subduction_core::Subduction)
 */
export class Subduction {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Accept a connection from a peer over any [`Transport`](JsTransport).
     *
     * Performs the responder side of the handshake, then adds the authenticated
     * connection. This is the counterpart to [`connectTransport`](Self::connect_transport).
     *
     * # Arguments
     *
     * * `transport` - Any JS object with `sendBytes`/`recvBytes`/`disconnect`
     * * `service_name` - Shared service name for discovery
     *
     * # Errors
     *
     * Returns an error if the handshake or connection fails.
     */
    acceptTransport(transport: Transport, service_name: string): Promise<PeerId>;
    /**
     * Bulk-insert commits and fragments into a sedimentree, then broadcast
     * (the `add_*` combinator = [`storeBuiltBatch`](Self::store_built_batch) +
     * [`syncWithAllPeers`](Self::sync_with_all_peers)).
     *
     * Unlike [`addCommit`](Self::add_commit) and
     * [`addFragment`](Self::add_fragment) — which each re-minimize the tree
     * and push to peers per call — this method inserts everything first,
     * runs `minimize_tree` once at the end, and then performs a single
     * `sync_with_all_peers` to propagate the new state. For workloads that
     * add many commits or fragments at once this avoids `O(N²)` minimize work
     * and `N` redundant broadcasts.
     *
     * Returns the per-peer broadcast outcome as a
     * [`PeerResultMap`](WasmPeerResultMap). This **awaits the broadcast**, so
     * an unresponsive peer can stall the call for up to `timeout_milliseconds`
     * (or the configured default when omitted); callers wanting a
     * non-blocking durable write should use
     * [`storeBuiltBatch`](Self::store_built_batch) instead.
     *
     * Either list may be empty; passing two empty lists is a no-op (no
     * minimize, no broadcast) and yields an empty map.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if any blob does not match its claimed
     * [`BlobMeta`](sedimentree_core::blob::BlobMeta), or if a local
     * [`Storage`](sedimentree_wasm::storage::JsStorage) error is hit while
     * persisting the batch or while ingesting inbound data during the
     * trailing broadcast. Per-peer transport failures are reported inside the
     * returned map, not as an error.
     */
    addBatch(id: SedimentreeId, commits: CommitInput[], fragments: FragmentInput[], timeout_milliseconds?: number | null): Promise<PeerResultMap>;
    /**
     * Add a commit with its associated blob to the storage, then push it to
     * authorized subscribers (the `add_*` combinator =
     * [`storeCommit`](Self::store_commit) + best-effort push).
     *
     * The commit metadata (including `BlobMeta`) is computed internally from
     * the provided blob, ensuring consistency by construction.
     *
     * Propagation is a best-effort `send` to subscribers; it does not block
     * on peer acks (no per-peer result is produced for single-item pushes).
     * For a durable write with no propagation, use
     * [`storeCommit`](Self::store_commit).
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if storage, networking, or policy fail.
     */
    addCommit(id: SedimentreeId, head: CommitId, parents: CommitId[], blob: Uint8Array): Promise<FragmentRequested | undefined>;
    /**
     * Bulk-insert commits into a sedimentree, then broadcast (the `add_*`
     * combinator = [`storeCommitsBatch`](Self::store_commits_batch) +
     * [`syncWithAllPeers`](Self::sync_with_all_peers)).
     *
     * Like [`addBatch`](Self::add_batch) for the commits half only. Returns
     * the per-peer broadcast outcome as a
     * [`PeerResultMap`](WasmPeerResultMap) and **awaits the broadcast** (an
     * unresponsive peer can stall the call for up to `timeout_milliseconds`).
     * An empty list is a no-op and yields an empty map.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if any blob does not match its claimed
     * [`BlobMeta`](sedimentree_core::blob::BlobMeta), or if storage fails.
     * Per-peer transport failures are reported inside the returned map.
     */
    addCommitsBatch(id: SedimentreeId, commits: CommitInput[], timeout_milliseconds?: number | null): Promise<PeerResultMap>;
    /**
     * Onboard an authenticated transport: add it and sync all sedimentrees.
     *
     * Accepts an [`AuthenticatedTransport`](WasmAuthenticatedTransport),
     * obtained via [`AuthenticatedTransport.setup`](WasmAuthenticatedTransport::setup),
     * [`AuthenticatedWebSocket.toTransport`], or [`AuthenticatedLongPoll.toTransport`].
     *
     * Returns `true` if this is a new peer, `false` if already connected.
     *
     * Add an authenticated transport to tracking.
     *
     * This does not perform any synchronization. To sync after adding,
     * call [`fullSyncWithPeer`](Self::full_sync_with_peer).
     *
     * Returns `true` if this is a new peer, `false` if already connected.
     *
     * # Errors
     *
     * Returns an error if the connection is rejected by the policy.
     */
    addConnection(transport: AuthenticatedTransport): Promise<boolean>;
    /**
     * Add a fragment with its associated blob to the storage, then push it to
     * authorized subscribers (the `add_*` combinator =
     * [`storeFragment`](Self::store_fragment) + best-effort push).
     *
     * The fragment metadata (including `BlobMeta`) is computed internally from
     * the provided blob, ensuring consistency by construction.
     *
     * Propagation is a best-effort `send` to subscribers; it does not block
     * on peer acks. For a durable write with no propagation, use
     * [`storeFragment`](Self::store_fragment).
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if storage, networking, or policy fail.
     */
    addFragment(id: SedimentreeId, head: CommitId, boundary: CommitId[], checkpoints: CommitId[], blob: Uint8Array): Promise<void>;
    /**
     * Bulk-insert fragments into a sedimentree, then broadcast (the `add_*`
     * combinator = [`storeFragmentsBatch`](Self::store_fragments_batch) +
     * [`syncWithAllPeers`](Self::sync_with_all_peers)).
     *
     * Like [`addBatch`](Self::add_batch) for the fragments half only. Returns
     * the per-peer broadcast outcome as a
     * [`PeerResultMap`](WasmPeerResultMap) and **awaits the broadcast** (an
     * unresponsive peer can stall the call for up to `timeout_milliseconds`).
     * An empty list is a no-op and yields an empty map.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if any blob does not match its claimed
     * [`BlobMeta`](sedimentree_core::blob::BlobMeta), or if storage fails.
     * Per-peer transport failures are reported inside the returned map.
     */
    addFragmentsBatch(id: SedimentreeId, fragments: FragmentInput[], timeout_milliseconds?: number | null): Promise<PeerResultMap>;
    /**
     * Persist a whole [`Sedimentree`](sedimentree_wasm::WasmSedimentree)
     * **and** broadcast it to all connected peers (the `add_*` combinator =
     * [`storeSedimentree`](Self::store_sedimentree) +
     * [`syncWithAllPeers`](Self::sync_with_all_peers)).
     *
     * Returns the per-peer broadcast outcome as a
     * [`PeerResultMap`](WasmPeerResultMap). This **awaits the broadcast**, so
     * an unresponsive peer can stall the call for up to `timeout_milliseconds`
     * (or the configured default when omitted); callers wanting a
     * non-blocking durable write should use
     * [`storeSedimentree`](Self::store_sedimentree) instead.
     *
     * # Errors
     *
     * Returns [`WasmWriteError`] if a referenced blob is missing, or on
     * storage I/O — including storage errors hit while ingesting inbound data
     * during the trailing sync. The local store uses the trusting local
     * putter (no network policy check). Per-peer transport failures during
     * the broadcast are reported inside the returned map, not as an error.
     */
    addSedimentree(id: SedimentreeId, sedimentree: Sedimentree, blobs: Uint8Array[], timeout_milliseconds?: number | null): Promise<PeerResultMap>;
    /**
     * Compute the [`WasmDepth`] of a commit identifier under this node's
     * configured hash metric.
     *
     * Combine with [`WasmDepth::isBoundary`] to decide whether a commit is an
     * eligible fragment head — for example after [`addBatch`](Self::add_batch),
     * where the per-call `FragmentRequested` signal returned by
     * [`addCommit`](Self::add_commit) is unavailable.
     */
    commitDepth(commit_id: CommitId): Depth;
    /**
     * Connect to a peer via WebSocket and add the connection.
     *
     * This performs the cryptographic handshake, verifies the server's identity,
     * and adds the authenticated connection for syncing.
     *
     * Returns the verified peer ID on success.
     *
     * # Arguments
     *
     * * `address` - The WebSocket URL to connect to
     * * `expected_peer_id` - The expected server peer ID (verified during handshake)
     *
     * # Errors
     *
     * Returns an error if connection, handshake, or adding the connection fails.
     */
    connect(address: URL, expected_peer_id: PeerId): Promise<PeerId>;
    /**
     * Connect to a peer via WebSocket using discovery mode and add the connection.
     *
     * Returns the discovered and verified peer ID on success.
     *
     * # Arguments
     *
     * * `address` - The WebSocket URL to connect to
     * * `service_name` - The service name for discovery (defaults to URL host)
     *
     * # Errors
     *
     * Returns an error if connection, handshake, or adding the connection fails.
     */
    connectDiscover(address: URL, service_name?: string | null): Promise<PeerId>;
    /**
     * Connect to a peer via HTTP long-poll using discovery mode.
     *
     * Returns the discovered and verified peer ID on success.
     *
     * # Arguments
     *
     * * `base_url` - The server's HTTP base URL (e.g., `http://localhost:8080`)
     * * `service_name` - The service name for discovery (defaults to `base_url`)
     *
     * # Errors
     *
     * Returns an error if connection, handshake, or adding the connection fails.
     */
    connectDiscoverLongPoll(base_url: string, service_name?: string | null): Promise<PeerId>;
    /**
     * Connect to a peer via HTTP long-poll and add the connection.
     *
     * Returns the verified peer ID on success.
     *
     * # Arguments
     *
     * * `base_url` - The server's HTTP base URL (e.g., `http://localhost:8080`)
     * * `expected_peer_id` - The expected server peer ID (verified during handshake)
     *
     * # Errors
     *
     * Returns an error if connection, handshake, or adding the connection fails.
     */
    connectLongPoll(base_url: string, expected_peer_id: PeerId): Promise<PeerId>;
    /**
     * Connect to a peer over any [`Transport`](JsTransport) using discovery mode.
     *
     * Performs a discovery handshake, then adds the authenticated connection.
     * The peer's identity is discovered during the handshake.
     *
     * # Arguments
     *
     * * `transport` - Any JS object with `sendBytes`/`recvBytes`/`disconnect`
     * * `service_name` - Shared service name for discovery
     *
     * # Errors
     *
     * Returns an error if the handshake or connection fails.
     */
    connectTransport(transport: Transport, service_name: string): Promise<PeerId>;
    /**
     * Disconnect from all peers.
     *
     * # Errors
     *
     * Returns a [`WasmDisconnectionError`] if disconnection was not graceful.
     */
    disconnectAll(): Promise<void>;
    /**
     * Disconnect from a peer by its ID.
     *
     * # Errors
     *
     * Returns a `WasmDisconnectionError` if disconnection fails.
     */
    disconnectFromPeer(peer_id: PeerId): Promise<boolean>;
    /**
     * Fetch blobs by their digests, with an optional timeout in milliseconds.
     *
     * # Errors
     *
     * Returns a [`WasmIoError`] if storage or networking fail.
     */
    fetchBlobs(id: SedimentreeId, timeout_milliseconds?: number | null): Promise<Uint8Array[] | undefined>;
    /**
     * Sync all known Sedimentree IDs with all connected peers.
     */
    fullSyncWithAllPeers(timeout_milliseconds?: number | null): Promise<PeerBatchSyncResult>;
    /**
     * Sync all known Sedimentree IDs with a single peer.
     *
     * # Arguments
     *
     * * `peer_id` - The peer to sync with
     * * `subscribe` - Whether to subscribe to future updates (default: `true`)
     * * `timeout_milliseconds` - Optional per-call total deadline in milliseconds; omit to use the configured default
     */
    fullSyncWithPeer(peer_id: PeerId, subscribe?: boolean | null, timeout_milliseconds?: number | null): Promise<PeerBatchSyncResult>;
    /**
     * Get the current heads for every locally known sedimentree.
     *
     * An inner empty heads array means the sedimentree exists but has no
     * heads yet.
     */
    getAllHeads(): Promise<SedimentreeHeads[]>;
    /**
     * Get a local blob by its digest.
     *
     * # Errors
     *
     * Returns a [`JsStorageError`] if JS storage fails.
     */
    getBlob(id: SedimentreeId, digest: Digest): Promise<Uint8Array | undefined>;
    /**
     * Get all local blobs for a given Sedimentree ID.
     *
     * # Errors
     *
     * Returns a [`JsStorageError`] if JS storage fails.
     */
    getBlobs(id: SedimentreeId): Promise<Uint8Array[]>;
    /**
     * Get all commits for a given Sedimentree ID
     */
    getCommits(id: SedimentreeId): Promise<LooseCommit[] | undefined>;
    /**
     * Get the peer IDs of all connected peers.
     */
    getConnectedPeerIds(): Promise<PeerId[]>;
    /**
     * Get all fragments for a given Sedimentree ID
     */
    getFragments(id: SedimentreeId): Promise<Fragment[] | undefined>;
    /**
     * Link two local [`Subduction`](WasmSubduction) instances over a
     * [`MessageChannel`](web_sys::MessageChannel).
     *
     * Creates a `MessageChannel`, performs a discovery handshake between
     * the two instances, and adds the connections to both. This is the
     * simplest way to sync two local instances.
     *
     * # Errors
     *
     * Returns an error if the handshake or connection fails.
     */
    static link(a: Subduction, b: Subduction): Promise<void>;
    /**
     * Create a new [`Subduction`] instance from an options object.
     *
     * ```js
     * new Subduction({ signer, storage, serviceName: "sync.example.com" });
     * ```
     *
     * `signer` and `storage` are required; all other fields are optional.
     * See [`SubductionOptions`] for the full field list and defaults.
     *
     * # Errors
     *
     * Returns a [`WasmInitError`] if the required `signer` or `storage` field
     * is missing (`undefined`/`null`). The TypeScript interface marks these as
     * required, so this only fires for callers that bypass the type checker.
     *
     * # Panics
     *
     * Panics if `hashMetricOverride` is provided but the underlying JS value
     * cannot be cast to a `Function`.
     */
    constructor(opts: SubductionOptions);
    /**
     * Publish an ephemeral message to all subscribers of a topic.
     *
     * The payload is opaque bytes — encoding is the caller's responsibility.
     * Messages are fire-and-forget; delivery is best-effort.
     *
     * # Panics
     *
     * Panics if the platform's random number generator fails.
     */
    publishEphemeral(topic: Topic, payload: Uint8Array): Promise<void>;
    /**
     * Register a handler for keyhive protocol frames.
     *
     * When a frame arrives with the `SUK\0` schema header, the CBOR
     * payload (without the SUK envelope) and the sender's peer ID are
     * forwarded to the handler's `onMessage` method. When a peer
     * disconnects, `onPeerDisconnect` is called.
     *
     * Only one handler can be registered at a time. Calling this again
     * replaces the previous handler. Pass `null`/`undefined` to unregister.
     */
    registerFrameHandler(handler?: FrameHandler | null): Promise<void>;
    /**
     * Remove a Sedimentree and all associated data.
     *
     * # Errors
     *
     * Returns a [`WasmIoError`] if storage or networking fail.
     */
    removeSedimentree(id: SedimentreeId): Promise<void>;
    /**
     * Get all known Sedimentree IDs
     */
    sedimentreeIds(): Promise<SedimentreeId[]>;
    /**
     * Send a keyhive frame to a specific peer.
     *
     * `payload` is the CBOR-encoded content (e.g., a `SignedMessage`).
     * Subduction wraps it in the `SUK\0` envelope before sending.
     *
     * # Errors
     *
     * Returns an error if the peer has no active connection or if sending fails.
     */
    sendKeyhiveMessage(payload: Uint8Array, peer_id: PeerId): Promise<void>;
    /**
     * Bulk-insert commits and fragments into a sedimentree **without**
     * broadcasting (the `store_*` tier).
     *
     * Inserts everything first and runs `minimize_tree` once at the end —
     * avoiding the `O(N²)` minimize work of looping
     * [`storeCommit`](Self::store_commit) — but performs **no** network
     * propagation. Useful for ingestion paths (local replay, hydration from
     * another store) where the caller drives sync separately or not at all.
     *
     * Each [`WasmCommitInput`] bundles an unsigned
     * [`LooseCommit`](sedimentree_core::loose_commit::LooseCommit) with its
     * blob; each [`WasmFragmentInput`] bundles an unsigned
     * [`Fragment`](sedimentree_core::fragment::Fragment) with its blob.
     * Either list may be empty; two empty lists is a no-op.
     *
     * Use [`addBatch`](Self::add_batch) for the store-and-broadcast
     * combinator.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if any blob does not match its claimed
     * [`BlobMeta`](sedimentree_core::blob::BlobMeta), or if storage fails.
     */
    storeBuiltBatch(id: SedimentreeId, commits: CommitInput[], fragments: FragmentInput[]): Promise<void>;
    /**
     * Persist a single commit with its blob locally **without** broadcasting
     * (the `store_*` tier).
     *
     * The commit metadata (including `BlobMeta`) is computed internally from
     * the provided blob, ensuring consistency by construction.
     *
     * Durability only: never waits on a peer. Use
     * [`addCommit`](Self::add_commit) for the store-and-push combinator.
     *
     * Returns the [`WasmFragmentRequested`] signal when the commit lands on a
     * fragment boundary, exactly as [`addCommit`](Self::add_commit) does.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] on storage I/O failure. This local-only
     * path uses the trusting local putter, so no network policy is consulted.
     */
    storeCommit(id: SedimentreeId, head: CommitId, parents: CommitId[], blob: Uint8Array): Promise<FragmentRequested | undefined>;
    /**
     * Bulk-insert commits into a sedimentree **without** broadcasting (the
     * `store_*` tier).
     *
     * Like [`storeBuiltBatch`](Self::store_built_batch) for the commits half
     * only. Each [`WasmCommitInput`] bundles an unsigned commit with its
     * blob; an empty list is a no-op.
     *
     * Use [`addCommitsBatch`](Self::add_commits_batch) for the
     * store-and-broadcast combinator.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if any blob does not match its claimed
     * [`BlobMeta`](sedimentree_core::blob::BlobMeta), or if storage fails.
     */
    storeCommitsBatch(id: SedimentreeId, commits: CommitInput[]): Promise<void>;
    /**
     * Persist a single fragment with its blob locally **without**
     * broadcasting (the `store_*` tier).
     *
     * The fragment metadata (including `BlobMeta`) is computed internally from
     * the provided blob, ensuring consistency by construction.
     *
     * Durability only: never waits on a peer. Use
     * [`addFragment`](Self::add_fragment) for the store-and-push combinator.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] on storage I/O failure. This local-only
     * path uses the trusting local putter, so no network policy is consulted.
     */
    storeFragment(id: SedimentreeId, head: CommitId, boundary: CommitId[], checkpoints: CommitId[], blob: Uint8Array): Promise<void>;
    /**
     * Bulk-insert fragments into a sedimentree **without** broadcasting (the
     * `store_*` tier).
     *
     * Like [`storeBuiltBatch`](Self::store_built_batch) for the fragments
     * half only. Each [`WasmFragmentInput`] bundles an unsigned fragment with
     * its blob; an empty list is a no-op.
     *
     * Use [`addFragmentsBatch`](Self::add_fragments_batch) for the
     * store-and-broadcast combinator.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if any blob does not match its claimed
     * [`BlobMeta`](sedimentree_core::blob::BlobMeta), or if storage fails.
     */
    storeFragmentsBatch(id: SedimentreeId, fragments: FragmentInput[]): Promise<void>;
    /**
     * Persist a whole [`Sedimentree`](sedimentree_wasm::WasmSedimentree)
     * locally **without** broadcasting (the `store_*` tier).
     *
     * Durability only: never waits on a peer. Drive
     * [`syncWithAllPeers`](Self::sync_with_all_peers) yourself to propagate.
     * Use [`addSedimentree`](Self::add_sedimentree) for the
     * store-and-broadcast combinator.
     *
     * # Errors
     *
     * Returns [`WasmWriteError`] if a referenced blob is missing or storage
     * I/O fails. This local-only path uses the trusting local putter, so no
     * network policy is consulted.
     */
    storeSedimentree(id: SedimentreeId, sedimentree: Sedimentree, blobs: Uint8Array[]): Promise<void>;
    /**
     * Subscribe to ephemeral messages for the given topics
     * from all connected peers.
     */
    subscribeEphemeral(topics: Topic[]): Promise<void>;
    /**
     * Request batch sync for a given Sedimentree ID from all connected peers.
     *
     * # Arguments
     *
     * * `id` - The sedimentree ID to sync
     * * `subscribe` - Whether to subscribe for incremental updates
     * * `timeout_milliseconds` - Optional per-call total deadline in milliseconds; omit to use the configured default
     *
     * # Errors
     *
     * Returns a [`WasmIoError`] if storage or networking fail.
     */
    syncWithAllPeers(id: SedimentreeId, subscribe: boolean, timeout_milliseconds?: number | null): Promise<PeerResultMap>;
    /**
     * Request batch sync for a given Sedimentree ID from a specific peer.
     *
     * # Arguments
     *
     * * `to_ask` - The peer ID to sync with
     * * `id` - The sedimentree ID to sync
     * * `subscribe` - Whether to subscribe for incremental updates
     * * `timeout_milliseconds` - Optional per-call total deadline in milliseconds; omit to use the configured default
     *
     * # Cancellation
     *
     * The call is bounded by `timeout_milliseconds` (or the configured
     * default). **Abandoning the returned `Promise` — e.g. via
     * `Promise.race([syncWithPeer(...), timeout(5000)])` — does NOT cancel
     * the underlying sync:** the work runs on the Wasm executor, not the
     * `Promise`, so it continues until the deadline elapses, the response
     * arrives, or the peer disconnects. To stop it early, set a shorter
     * `timeout_milliseconds` or disconnect the peer
     * ([`disconnect_from_peer`](Self::disconnect_from_peer) /
     * [`disconnect_all`](Self::disconnect_all)).
     *
     * # Errors
     *
     * Returns a [`WasmIoError`] if storage or networking fail.
     */
    syncWithPeer(to_ask: PeerId, id: SedimentreeId, subscribe: boolean, timeout_milliseconds?: number | null): Promise<PeerBatchSyncResult>;
    /**
     * Unsubscribe from ephemeral messages for the given topics
     * from all connected peers.
     */
    unsubscribeEphemeral(topics: Topic[]): Promise<void>;
    /**
     * Get the backing storage.
     */
    readonly storage: any;
}

/**
 * JS-facing wrapper around [`HttpLongPollTransport`] that exposes the
 * byte-oriented [`Transport`](super::JsTransport) interface
 * (`sendBytes`/`recvBytes`/`disconnect`/`onDisconnect`) so it can be used as a
 * duck-typed `JsTransport` from JavaScript.
 */
export class SubductionHttpLongPoll {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Disconnect from the peer gracefully.
     *
     * Fires the `onDisconnect` callback if one is registered.
     *
     * # Errors
     *
     * Returns an error if the disconnect fails.
     */
    disconnect(): Promise<void>;
    /**
     * Register a callback to be invoked when the transport disconnects.
     *
     * Part of the [`Transport`](super::JsTransport) interface contract.
     * Typically called by internal wiring rather than directly by user code.
     */
    onDisconnect(callback: Function): void;
    /**
     * Receive the next message frame as raw bytes.
     *
     * # Errors
     *
     * Returns an error if the inbound channel is closed.
     */
    recvBytes(): Promise<Uint8Array>;
    /**
     * Send raw bytes over the transport.
     *
     * # Errors
     *
     * Returns an error if the outbound channel is closed.
     */
    sendBytes(bytes: Uint8Array): Promise<void>;
}

/**
 * HTTP long-poll transport factory for browser/worker environments.
 *
 * Analogous to [`SubductionWebSocket`] but uses HTTP long-poll instead of WebSocket.
 */
export class SubductionLongPoll {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Connect to a server with a known peer ID.
     *
     * # Arguments
     *
     * * `base_url` - The server's HTTP base URL (e.g., `http://localhost:8080`)
     * * `signer` - The client's signer for authentication
     * * `expected_peer_id` - The expected server peer ID (verified during handshake)
     * * `on_disconnect` - Optional callback invoked with the peer's [`PeerId`] when the connection closes
     *
     * # Errors
     *
     * Returns [`LongPollTransportError`] if connection or handshake fails.
     */
    static tryConnect(base_url: string, signer: Signer, expected_peer_id: PeerId, on_disconnect?: Function | null): Promise<AuthenticatedLongPoll>;
    /**
     * Connect to a server using discovery mode.
     *
     * # Arguments
     *
     * * `base_url` - The server's HTTP base URL (e.g., `http://localhost:8080`)
     * * `signer` - The client's signer for authentication
     * * `service_name` - The service name for discovery. If omitted, the base URL is used.
     *
     * # Errors
     *
     * Returns [`LongPollTransportError`] if connection or handshake fails.
     */
    static tryDiscover(base_url: string, signer: Signer, service_name?: string | null, on_disconnect?: Function | null): Promise<AuthenticatedLongPoll>;
}

/**
 * A WebSocket transport exposing the byte-oriented `Transport` interface.
 *
 * Raw bytes from the WebSocket's `onmessage` handler are buffered in an
 * `async_channel` and returned via `recvBytes`. No message decoding or
 * request-response routing happens here — that's handled by
 * [`MessageTransport`](subduction_core::transport::message::MessageTransport).
 */
export class SubductionWebSocket {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Disconnect from the peer gracefully.
     */
    disconnect(): Promise<void>;
    /**
     * Register a callback to be invoked when the WebSocket closes.
     *
     * Part of the [`Transport`](super::JsTransport) interface contract.
     * Typically called by internal wiring (factory methods like `tryConnect`
     * and `tryDiscover`) rather than directly by user code.
     *
     * The callback is fired from the browser WebSocket's `onclose` handler.
     */
    onDisconnect(callback: Function): void;
    /**
     * Receive the next message frame as raw bytes.
     *
     * # Errors
     *
     * Returns [`ReadFromClosedChannel`] if the channel has been closed.
     */
    recvBytes(): Promise<Uint8Array>;
    /**
     * Send raw bytes over the WebSocket.
     *
     * # Errors
     *
     * Returns [`WasmSendError`] if the bytes could not be sent.
     */
    sendBytes(bytes: Uint8Array): Promise<void>;
    /**
     * Authenticate an existing WebSocket via handshake.
     *
     * This performs the Subduction handshake protocol over the provided WebSocket
     * to establish mutual identity. The WebSocket can be in CONNECTING or OPEN state.
     *
     * # Arguments
     *
     * * `ws` - An existing WebSocket (CONNECTING or OPEN)
     * * `signer` - The client's signer for authentication
     * * `expected_peer_id` - The expected server peer ID (verified during handshake)
     * * `on_disconnect` - Optional callback invoked with the peer's [`PeerId`] when the connection closes
     *
     * # Errors
     *
     * Returns an error if the handshake fails (signature invalid, wrong peer, etc.)
     */
    static setup(ws: WebSocket, signer: Signer, expected_peer_id: PeerId, on_disconnect?: Function | null): Promise<AuthenticatedWebSocket>;
    /**
     * Connect to a WebSocket server with mutual authentication via handshake.
     *
     * # Arguments
     *
     * * `address` - The WebSocket URL to connect to
     * * `signer` - The client's signer for authentication
     * * `expected_peer_id` - The expected server peer ID (verified during handshake)
     * * `on_disconnect` - Optional callback invoked with the peer's [`PeerId`] when the connection closes
     *
     * # Errors
     *
     * Returns an error if:
     * - The WebSocket connection could not be established
     * - The handshake fails (signature invalid, wrong server, clock drift, etc.)
     */
    static tryConnect(address: URL, signer: Signer, expected_peer_id: PeerId, on_disconnect?: Function | null): Promise<AuthenticatedWebSocket>;
    /**
     * Connect to a WebSocket server using discovery mode.
     *
     * This method performs a cryptographic handshake using a service name
     * instead of a known peer ID. The server's peer ID is discovered during
     * the handshake and returned.
     *
     * # Arguments
     *
     * * `address` - The WebSocket URL to connect to
     * * `signer` - The client's signer for authentication
     * * `service_name` - The service name for discovery (e.g., `localhost:8080`).
     *   If omitted, the host is extracted from the URL.
     * * `on_disconnect` - Optional callback invoked with the peer's [`PeerId`] when the connection closes
     *
     * # Errors
     *
     * Returns an error if:
     * - The WebSocket connection could not be established
     * - The handshake fails (signature invalid, clock drift, etc.)
     */
    static tryDiscover(address: URL, signer: Signer, service_name?: string | null, on_disconnect?: Function | null): Promise<AuthenticatedWebSocket>;
}

/**
 * Wasm wrapper for [`SyncMessage`].
 */
export class SyncMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Upcasts; to the JS-import type for [`WasmMessage`].
     */
    __wasm_refgen_toWasmMessage(): SyncMessage;
    /**
     * Create a [`SyncMessage::BatchSyncRequest`] message.
     */
    static batchSyncRequest(request: BatchSyncRequest): SyncMessage;
    /**
     * Create a [`SyncMessage::BatchSyncResponse`] message.
     */
    static batchSyncResponse(response: BatchSyncResponse): SyncMessage;
    /**
     * Deserialize a message from bytes.
     *
     * # Errors
     *
     * Returns a [`JsMessageDeserializationError`] if deserialization fails.
     */
    static fromBytes(bytes: Uint8Array): SyncMessage;
    /**
     * Serialize the message to bytes.
     */
    toBytes(): Uint8Array;
    /**
     * The `Blob` for commit or fragment messages, if applicable.
     */
    readonly blob: Uint8Array | undefined;
    /**
     * The [`LooseCommit`] for a [`SyncMessage::LooseCommit`], if applicable.
     *
     * Decodes the signed payload to extract the underlying commit.
     */
    readonly commit: LooseCommit | undefined;
    /**
     * The [`Fragment`] for a [`SyncMessage::Fragment`], if applicable.
     *
     * Decodes the signed payload to extract the underlying fragment.
     */
    readonly fragment: Fragment | undefined;
    /**
     * The [`BatchSyncRequest`] for a [`SyncMessage::BatchSyncRequest`], if applicable.
     */
    readonly request: BatchSyncRequest | undefined;
    /**
     * The [`BatchSyncResponse`] for a [`SyncMessage::BatchSyncResponse`], if applicable.
     */
    readonly response: BatchSyncResponse | undefined;
    /**
     * The [`SedimentreeId`] associated with this message, if any.
     */
    readonly sedimentreeId: SedimentreeId | undefined;
    /**
     * The message variant name.
     */
    readonly type: string;
}

/**
 * Statistics from a sync operation.
 *
 * The "sent" counts reflect items that were _successfully_ sent over the wire,
 * not just items that were requested.
 */
export class SyncStats {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Number of commits received from the peer.
     */
    readonly commitsReceived: number;
    /**
     * Number of commits successfully sent to the peer.
     */
    readonly commitsSent: number;
    /**
     * Number of fragments received from the peer.
     */
    readonly fragmentsReceived: number;
    /**
     * Number of fragments successfully sent to the peer.
     */
    readonly fragmentsSent: number;
    /**
     * Returns true if no commits or fragments were transferred.
     *
     * Note: `remoteHeads` may still be non-empty (heads metadata is not
     * considered "data" for this check).
     */
    readonly isEmpty: boolean;
    /**
     * The remote peer's heads for this sedimentree.
     */
    readonly remoteHeads: CommitId[];
    /**
     * Total items received (commits + fragments).
     */
    readonly totalReceived: number;
    /**
     * Total items sent (commits + fragments).
     */
    readonly totalSent: number;
}

/**
 * A Wasm wrapper around the ephemeral [`Topic`] type.
 *
 * Topics are opaque 32-byte identifiers for ephemeral pubsub channels.
 * A [`SedimentreeId`] can be used as a topic, but topics are not
 * limited to sedimentrees.
 *
 * [`SedimentreeId`]: sedimentree_core::id::SedimentreeId
 */
export class Topic {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Upcasts; to the JS-import type for [`WasmTopic`].
     */
    __wasm_refgen_toWasmTopic(): Topic;
    /**
     * Create a topic from a 32-byte array.
     *
     * # Errors
     *
     * Returns an error if the provided byte array is not exactly 32 bytes.
     */
    static fromBytes(bytes: Uint8Array): Topic;
    /**
     * Returns the raw 32 bytes of this topic.
     */
    toBytes(): Uint8Array;
    /**
     * Returns a shortened hex prefix representation (first 4 bytes + `…`).
     */
    toString(): string;
}

/**
 * An Ed25519 signer using the browser's `WebCrypto` API.
 *
 * This signer generates and stores Ed25519 keys using `crypto.subtle`,
 * providing secure key generation and signing operations. The key is
 * persisted to `IndexedDB` so it survives page reloads.
 *
 * # Example
 *
 * ```javascript
 * import { WebCryptoSigner } from "@automerge/subduction";
 *
 * const signer = await WebCryptoSigner.setup();
 * console.log("Peer ID:", signer.peerId().toString());
 * ```
 */
export class WebCryptoSigner {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Get the peer ID derived from this signer's verifying key.
     *
     * # Panics
     *
     * Panics if the stored public key bytes are invalid (should never happen).
     */
    peerId(): PeerId;
    /**
     * Set up the signer, loading an existing key from `IndexedDB` or generating a new one.
     *
     * # Errors
     *
     * Returns an error if `WebCrypto` or `IndexedDB` operations fail.
     */
    static setup(): Promise<WebCryptoSigner>;
    /**
     * Sign a message and return the 64-byte Ed25519 signature.
     *
     * # Errors
     *
     * Returns an error if `WebCrypto` signing fails.
     */
    sign(message: Uint8Array): Promise<Uint8Array>;
    /**
     * Get the 32-byte Ed25519 verifying (public) key.
     */
    verifyingKey(): Uint8Array;
}

/**
 * Clear the JavaScript logger callback registered via [`set_subduction_logger`].
 * See [`set_subduction_log_level`].
 */
export function clear_subduction_logger(): void;

/**
 * Compute the commit ID of a base58-encoded ID string.
 *
 * # Errors
 *
 * Returns a `WasmFromBase58Error` if the input string is not valid base58.
 */
export function commitIdOfBase58Id(b58_str: string): CommitId;

/**
 * Install the panic hook and the shared rich tracing stack (reloadable level
 * filter + console layer + JS-callback layer). The initial level is read from
 * `SUBDUCTION_LOG_LEVEL` (`localStorage` / `process.env`), defaulting to WARN.
 * Idempotent; whichever subscriber installs first wins.
 */
export function init(): void;

/**
 * Convenience factory — equivalent to `new MessagePortTransport(port)`.
 */
export function makeMessagePortTransport(port: any): MessagePortTransport;

/**
 * Set the log level at runtime. Valid: `"trace"`, `"debug"`, `"info"`,
 * `"warn"`, `"error"`, `"off"`. Persisted to `localStorage`.
 *
 * This crate is the single definition site for the workspace's Wasm log
 * controls. Crates that depend on it (`subduction_wasm`, and transitively the
 * umbrella) re-export these via `pub use` rather than redefining them, so the
 * JS export appears exactly once per bundle with no duplicate-symbol clash.
 *
 * # Errors
 *
 * Returns an error if the level string is invalid or tracing is uninitialized.
 */
export function setSubductionLogLevel(level: string): void;

/**
 * Forward every tracing event to a JavaScript callback
 * `(level, target, message, fields)`. See [`set_subduction_log_level`].
 */
export function set_subduction_logger(callback: Function): void;
