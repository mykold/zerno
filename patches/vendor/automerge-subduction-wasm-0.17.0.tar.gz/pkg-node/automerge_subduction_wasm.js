/* @ts-self-types="./automerge_subduction_wasm.d.ts" */
const { tryIntoJsSedimentreeIdsArray } = require(String.raw`./snippets/sedimentree_wasm-3d69959caf5a34b6/inline1.js`);

/**
 * An authenticated HTTP long-poll transport.
 *
 * This wrapper proves that the transport has completed the Subduction handshake
 * and the peer identity has been cryptographically verified.
 *
 * Obtain via [`SubductionLongPoll::tryConnect`] or [`SubductionLongPoll::tryDiscover`].
 */
class AuthenticatedLongPoll {
    static __wrap(ptr) {
        const obj = Object.create(AuthenticatedLongPoll.prototype);
        obj.__wbg_ptr = ptr;
        AuthenticatedLongPollFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AuthenticatedLongPollFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_authenticatedlongpoll_free(ptr, 0);
    }
    /**
     * The verified peer identity.
     * @returns {PeerId}
     */
    get peerId() {
        const ret = wasm.authenticatedlongpoll_peerId(this.__wbg_ptr);
        return PeerId.__wrap(ret);
    }
    /**
     * The session ID assigned by the server.
     * @returns {string}
     */
    get sessionId() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.authenticatedlongpoll_sessionId(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Convert to a transport-erased [`AuthenticatedTransport`](super::authenticated::WasmAuthenticatedTransport).
     * @returns {AuthenticatedTransport}
     */
    toTransport() {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.authenticatedlongpoll_toTransport(ptr);
        return AuthenticatedTransport.__wrap(ret);
    }
}
if (Symbol.dispose) AuthenticatedLongPoll.prototype[Symbol.dispose] = AuthenticatedLongPoll.prototype.free;
exports.AuthenticatedLongPoll = AuthenticatedLongPoll;

/**
 * A transport-erased authenticated transport.
 *
 * Wraps an [`Authenticated<MessageTransport<JsTransport>>`] and is the common type
 * accepted by [`addConnection`](crate::subduction::WasmSubduction::add_connection).
 *
 * # Construction
 *
 * There are three ways to obtain an `AuthenticatedTransport`:
 *
 * 1. **Custom transport** — implement the `Transport` interface
 *    (`sendBytes`/`recvBytes`/`disconnect`/`onDisconnect`) and call
 *    [`setup`](Self::setup):
 *
 *    ```js
 *    const auth = await AuthenticatedTransport.setup(myTransport, signer, peerId, (peerId) => {
 *        console.log(`${peerId} disconnected`);
 *    });
 *    ```
 *
 * 2. **From WebSocket** — authenticate via [`SubductionWebSocket`] then convert:
 *
 *    ```js
 *    const wsAuth = await SubductionWebSocket.tryConnect(url, signer, peerId, (peerId) => {
 *        console.log(`${peerId} disconnected`);
 *    });
 *    const auth = wsAuth.toTransport();
 *    ```
 *
 * 3. **From HTTP long-poll** — same pattern via [`SubductionLongPoll`]:
 *
 *    ```js
 *    const lpAuth = await SubductionLongPoll.tryConnect(url, signer, peerId, (peerId) => {
 *        console.log(`${peerId} disconnected`);
 *    });
 *    const auth = lpAuth.toTransport();
 *    ```
 */
class AuthenticatedTransport {
    static __wrap(ptr) {
        const obj = Object.create(AuthenticatedTransport.prototype);
        obj.__wbg_ptr = ptr;
        AuthenticatedTransportFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AuthenticatedTransportFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_authenticatedtransport_free(ptr, 0);
    }
    /**
     * Accept an incoming handshake over a custom transport (responder side).
     *
     * This is the counterpart to [`setup`](Self::setup). The initiator calls
     * `setup`, and the responder calls `accept` over the same underlying channel.
     *
     * # Arguments
     *
     * * `transport` - A `Transport` implementing `sendBytes`/`recvBytes`/`disconnect`/`onDisconnect`
     * * `signer` - The responder's signer for authentication
     * * `max_drift_seconds` - Maximum acceptable clock drift in seconds (default: 600)
     *
     * # Errors
     *
     * Returns a [`HandshakeError`](WasmHandshakeError) if the handshake fails.
     * @param {Transport} transport
     * @param {Signer} signer
     * @param {number | null} [max_drift_seconds]
     * @param {Function | null} [on_disconnect]
     * @returns {Promise<AuthenticatedTransport>}
     */
    static accept(transport, signer, max_drift_seconds, on_disconnect) {
        const ret = wasm.authenticatedtransport_accept(transport, signer, isLikeNone(max_drift_seconds) ? Number.MAX_SAFE_INTEGER : (max_drift_seconds) >>> 0, isLikeNone(on_disconnect) ? 0 : addToExternrefTable0(on_disconnect));
        return ret;
    }
    /**
     * The verified peer identity.
     * @returns {PeerId}
     */
    get peerId() {
        const ret = wasm.authenticatedtransport_peerId(this.__wbg_ptr);
        return PeerId.__wrap(ret);
    }
    /**
     * Run the Subduction handshake over a custom transport, producing an
     * authenticated transport.
     *
     * The `transport` object must implement the `Transport` interface
     * (`sendBytes`/`recvBytes`/`disconnect`/`onDisconnect`).
     * The same object is used for both the handshake phase and post-handshake
     * communication.
     *
     * # Arguments
     *
     * * `transport` - A `Transport` implementing `sendBytes`/`recvBytes`/`disconnect`/`onDisconnect`
     * * `signer` - The client's signer for authentication
     * * `expected_peer_id` - The expected server peer ID (verified during handshake)
     *
     * # Errors
     *
     * Returns a [`HandshakeError`](WasmHandshakeError) if the handshake fails.
     * @param {Transport} transport
     * @param {Signer} signer
     * @param {PeerId} expected_peer_id
     * @param {Function | null} [on_disconnect]
     * @returns {Promise<AuthenticatedTransport>}
     */
    static setup(transport, signer, expected_peer_id, on_disconnect) {
        _assertClass(expected_peer_id, PeerId);
        const ret = wasm.authenticatedtransport_setup(transport, signer, expected_peer_id.__wbg_ptr, isLikeNone(on_disconnect) ? 0 : addToExternrefTable0(on_disconnect));
        return ret;
    }
    /**
     * Run the Subduction handshake over a custom transport using discovery
     * mode, producing an authenticated transport.
     *
     * Unlike [`setup`](Self::setup) which requires a known peer ID,
     * this method discovers the peer's identity during the handshake
     * using a shared service name.
     *
     * # Arguments
     *
     * * `transport` - A `Transport` implementing `sendBytes`/`recvBytes`/`disconnect`/`onDisconnect`
     * * `signer` - The client's signer for authentication
     * * `service_name` - Shared service name for discovery.
     *   Defaults to [`DEFAULT_LOCAL_SERVICE_NAME`] (`"subduction:local"`) if omitted.
     *
     * # Errors
     *
     * Returns a [`HandshakeError`](WasmHandshakeError) if the handshake fails.
     * @param {Transport} transport
     * @param {Signer} signer
     * @param {string | null} [service_name]
     * @param {Function | null} [on_disconnect]
     * @returns {Promise<AuthenticatedTransport>}
     */
    static setupDiscover(transport, signer, service_name, on_disconnect) {
        var ptr0 = isLikeNone(service_name) ? 0 : passStringToWasm0(service_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.authenticatedtransport_setupDiscover(transport, signer, ptr0, len0, isLikeNone(on_disconnect) ? 0 : addToExternrefTable0(on_disconnect));
        return ret;
    }
}
if (Symbol.dispose) AuthenticatedTransport.prototype[Symbol.dispose] = AuthenticatedTransport.prototype.free;
exports.AuthenticatedTransport = AuthenticatedTransport;

/**
 * An authenticated WebSocket transport.
 *
 * This wrapper proves that the connection has completed the Subduction handshake
 * and the peer identity has been cryptographically verified.
 *
 * Obtain via [`SubductionWebSocket::setup`], [`SubductionWebSocket::tryConnect`],
 * or [`SubductionWebSocket::tryDiscover`].
 */
class AuthenticatedWebSocket {
    static __wrap(ptr) {
        const obj = Object.create(AuthenticatedWebSocket.prototype);
        obj.__wbg_ptr = ptr;
        AuthenticatedWebSocketFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AuthenticatedWebSocketFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_authenticatedwebsocket_free(ptr, 0);
    }
    /**
     * The verified peer identity.
     * @returns {PeerId}
     */
    get peerId() {
        const ret = wasm.authenticatedwebsocket_peerId(this.__wbg_ptr);
        return PeerId.__wrap(ret);
    }
    /**
     * Convert to a transport-erased [`AuthenticatedTransport`](super::authenticated::WasmAuthenticatedTransport).
     * @returns {AuthenticatedTransport}
     */
    toTransport() {
        const ptr = this.__destroy_into_raw();
        const ret = wasm.authenticatedwebsocket_toTransport(ptr);
        return AuthenticatedTransport.__wrap(ret);
    }
}
if (Symbol.dispose) AuthenticatedWebSocket.prototype[Symbol.dispose] = AuthenticatedWebSocket.prototype.free;
exports.AuthenticatedWebSocket = AuthenticatedWebSocket;

/**
 * Wasm wrapper for [`BatchSyncRequest`].
 */
class BatchSyncRequest {
    static __wrap(ptr) {
        const obj = Object.create(BatchSyncRequest.prototype);
        obj.__wbg_ptr = ptr;
        BatchSyncRequestFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        BatchSyncRequestFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_batchsyncrequest_free(ptr, 0);
    }
    /**
     * The sedimentree ID this request corresponds to.
     * @returns {SedimentreeId}
     */
    id() {
        const ret = wasm.batchsyncrequest_id(this.__wbg_ptr);
        return SedimentreeId.__wrap(ret);
    }
    /**
     * The request ID for this request.
     * @returns {RequestId}
     */
    request_id() {
        const ret = wasm.batchsyncrequest_request_id(this.__wbg_ptr);
        return RequestId.__wrap(ret);
    }
    /**
     * Whether this request subscribes to future updates.
     * @returns {boolean}
     */
    subscribe() {
        const ret = wasm.batchsyncrequest_subscribe(this.__wbg_ptr);
        return ret !== 0;
    }
}
if (Symbol.dispose) BatchSyncRequest.prototype[Symbol.dispose] = BatchSyncRequest.prototype.free;
exports.BatchSyncRequest = BatchSyncRequest;

/**
 * Wasm wrapper for [`BatchSyncResponse`].
 */
class BatchSyncResponse {
    static __wrap(ptr) {
        const obj = Object.create(BatchSyncResponse.prototype);
        obj.__wbg_ptr = ptr;
        BatchSyncResponseFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        BatchSyncResponseFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_batchsyncresponse_free(ptr, 0);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmBatchSyncResponse`].
     * @returns {BatchSyncResponse}
     */
    __wasm_refgen_toWasmBatchSyncResponse() {
        const ret = wasm.batchsyncresponse___wasm_refgen_toWasmBatchSyncResponse(this.__wbg_ptr);
        return BatchSyncResponse.__wrap(ret);
    }
    /**
     * The sedimentree ID this response corresponds to.
     * @returns {SedimentreeId}
     */
    id() {
        const ret = wasm.batchsyncresponse_id(this.__wbg_ptr);
        return SedimentreeId.__wrap(ret);
    }
    /**
     * The request ID this response corresponds to.
     * @returns {RequestId}
     */
    request_id() {
        const ret = wasm.batchsyncresponse_request_id(this.__wbg_ptr);
        return RequestId.__wrap(ret);
    }
}
if (Symbol.dispose) BatchSyncResponse.prototype[Symbol.dispose] = BatchSyncResponse.prototype.free;
exports.BatchSyncResponse = BatchSyncResponse;

/**
 * A Wasm wrapper around the [`BlobMeta`] type.
 */
class BlobMeta {
    static __wrap(ptr) {
        const obj = Object.create(BlobMeta.prototype);
        obj.__wbg_ptr = ptr;
        BlobMetaFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        BlobMetaFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_blobmeta_free(ptr, 0);
    }
    /**
     * Get the digest of the blob.
     * @returns {Digest}
     */
    digest() {
        const ret = wasm.blobmeta_digest(this.__wbg_ptr);
        return Digest.__wrap(ret);
    }
    /**
     * Create a `BlobMeta` from a digest and size.
     *
     * This is useful for deserialization when the original blob is not available.
     * Since this is manual, the caller must ensure the digest and size are correct.
     * @param {Digest} digest
     * @param {bigint} size_bytes
     * @returns {BlobMeta}
     */
    static fromDigestSize(digest, size_bytes) {
        _assertClass(digest, Digest);
        const ret = wasm.blobmeta_fromDigestSize(digest.__wbg_ptr, size_bytes);
        return BlobMeta.__wrap(ret);
    }
    /**
     * Create a new `BlobMeta` from the given blob contents.
     * @param {Uint8Array} blob
     */
    constructor(blob) {
        const ptr0 = passArray8ToWasm0(blob, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.blobmeta_new(ptr0, len0);
        this.__wbg_ptr = ret;
        BlobMetaFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Get the size of the blob in bytes.
     * @returns {bigint}
     */
    get sizeBytes() {
        const ret = wasm.blobmeta_sizeBytes(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
}
if (Symbol.dispose) BlobMeta.prototype[Symbol.dispose] = BlobMeta.prototype.free;
exports.BlobMeta = BlobMeta;

/**
 * Wasm wrapper for call errors.
 */
class CallError {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CallErrorFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_callerror_free(ptr, 0);
    }
}
if (Symbol.dispose) CallError.prototype[Symbol.dispose] = CallError.prototype.free;
exports.CallError = CallError;

/**
 * A user-supplied opaque identifier for a loose commit.
 *
 * Unlike [`Digest`](crate::digest::WasmDigest), which is a content hash
 * computed by the system, `CommitId` is provided by the caller at construction
 * time. This is the identity used for DAG traversal, fragment boundaries,
 * and sync.
 */
class CommitId {
    static __wrap(ptr) {
        const obj = Object.create(CommitId.prototype);
        obj.__wbg_ptr = ptr;
        CommitIdFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    static __unwrap(jsValue) {
        if (!(jsValue instanceof CommitId)) {
            return 0;
        }
        return jsValue.__destroy_into_raw();
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CommitIdFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_commitid_free(ptr, 0);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmCommitId`].
     * @returns {CommitId}
     */
    __wasm_refgen_toWasmCommitId() {
        const ret = wasm.commitid___wasm_refgen_toWasmCommitId(this.__wbg_ptr);
        return CommitId.__wrap(ret);
    }
    /**
     * Creates a new commit identifier from its Base58 string representation.
     *
     * # Errors
     *
     * Returns an error if the string cannot be decoded or is not 32 bytes.
     * @param {string} s
     * @returns {CommitId}
     */
    static fromBase58(s) {
        const ptr0 = passStringToWasm0(s, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.commitid_fromBase58(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return CommitId.__wrap(ret[0]);
    }
    /**
     * Creates a new commit identifier from its byte representation.
     *
     * # Errors
     *
     * Returns an error if the byte slice is not exactly 32 bytes.
     * @param {Uint8Array} bytes
     * @returns {CommitId}
     */
    static fromBytes(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.commitid_fromBytes(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return CommitId.__wrap(ret[0]);
    }
    /**
     * Creates a new commit identifier from its hexadecimal string representation.
     *
     * # Errors
     *
     * Returns an error if the string is not valid hex or not 32 bytes.
     * @param {string} s
     * @returns {CommitId}
     */
    static fromHexString(s) {
        const ptr0 = passStringToWasm0(s, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.commitid_fromHexString(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return CommitId.__wrap(ret[0]);
    }
    /**
     * Creates a new commit identifier from its byte representation.
     *
     * # Errors
     *
     * Returns an error if the byte slice is not exactly 32 bytes.
     * @param {Uint8Array} bytes
     */
    constructor(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.commitid_new(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        CommitIdFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Returns the byte representation of the commit identifier.
     * @returns {Uint8Array}
     */
    toBytes() {
        const ret = wasm.commitid_toBytes(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * Returns the hexadecimal string representation.
     * @returns {string}
     */
    toHexString() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.commitid_toHexString(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) CommitId.prototype[Symbol.dispose] = CommitId.prototype.free;
exports.CommitId = CommitId;

/**
 * One unsigned commit + its blob, ready for bulk insertion.
 *
 * Construct with `new CommitInput(looseCommit, blob)` from JavaScript;
 * pass arrays of these to the batch write methods
 * ([`addBatch`](crate::subduction::WasmSubduction::add_batch) /
 * [`storeBuiltBatch`](crate::subduction::WasmSubduction::store_built_batch),
 * [`addCommitsBatch`](crate::subduction::WasmSubduction::add_commits_batch) /
 * [`storeCommitsBatch`](crate::subduction::WasmSubduction::store_commits_batch)).
 */
class CommitInput {
    static __unwrap(jsValue) {
        if (!(jsValue instanceof CommitInput)) {
            return 0;
        }
        return jsValue.__destroy_into_raw();
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CommitInputFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_commitinput_free(ptr, 0);
    }
    /**
     * A copy of the blob bytes.
     * @returns {Uint8Array}
     */
    get blob() {
        const ret = wasm.commitinput_blob(this.__wbg_ptr);
        return ret;
    }
    /**
     * A copy of the underlying unsigned commit.
     * @returns {LooseCommit}
     */
    get commit() {
        const ret = wasm.commitinput_commit(this.__wbg_ptr);
        return LooseCommit.__wrap(ret);
    }
    /**
     * Pair an unsigned [`LooseCommit`](sedimentree_core::loose_commit::LooseCommit)
     * with the bytes of its associated blob.
     *
     * `blob` accepts any `BufferSource`-like value from JavaScript
     * (`Uint8Array`, `ArrayBuffer`, plain `number[]`); `wasm_bindgen` copies
     * the bytes into a `Vec<u8>` owned by this struct.
     * @param {LooseCommit} commit
     * @param {Uint8Array} blob
     */
    constructor(commit, blob) {
        _assertClass(commit, LooseCommit);
        var ptr0 = commit.__destroy_into_raw();
        const ptr1 = passArray8ToWasm0(blob, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.commitinput_new(ptr0, ptr1, len1);
        this.__wbg_ptr = ret;
        CommitInputFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
}
if (Symbol.dispose) CommitInput.prototype[Symbol.dispose] = CommitInput.prototype.free;
exports.CommitInput = CommitInput;

/**
 * A commit stored with its associated blob.
 */
class CommitWithBlob {
    static __wrap(ptr) {
        const obj = Object.create(CommitWithBlob.prototype);
        obj.__wbg_ptr = ptr;
        CommitWithBlobFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CommitWithBlobFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_commitwithblob_free(ptr, 0);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmCommitWithBlob`].
     * @returns {CommitWithBlob}
     */
    __wasm_refgen_toWasmCommitWithBlob() {
        const ret = wasm.commitwithblob___wasm_refgen_toWasmCommitWithBlob(this.__wbg_ptr);
        return CommitWithBlob.__wrap(ret);
    }
    /**
     * Get the blob.
     * @returns {Uint8Array}
     */
    get blob() {
        const ret = wasm.commitwithblob_blob(this.__wbg_ptr);
        return ret;
    }
    /**
     * Create a new commit with blob.
     * @param {SignedLooseCommit} signed
     * @param {Uint8Array} blob
     */
    constructor(signed, blob) {
        _assertClass(signed, SignedLooseCommit);
        var ptr0 = signed.__destroy_into_raw();
        const ret = wasm.commitwithblob_new(ptr0, blob);
        this.__wbg_ptr = ret;
        CommitWithBlobFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Get the signed commit.
     * @returns {SignedLooseCommit}
     */
    get signed() {
        const ret = wasm.commitwithblob_signed(this.__wbg_ptr);
        return SignedLooseCommit.__wrap(ret);
    }
}
if (Symbol.dispose) CommitWithBlob.prototype[Symbol.dispose] = CommitWithBlob.prototype.free;
exports.CommitWithBlob = CommitWithBlob;

/**
 * A JavaScript wrapper around `Depth`.
 */
class Depth {
    static __wrap(ptr) {
        const obj = Object.create(Depth.prototype);
        obj.__wbg_ptr = ptr;
        DepthFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        DepthFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_depth_free(ptr, 0);
    }
    /**
     * Internal method for a hack crossing the JS boundary.
     * @returns {Depth}
     */
    __subduction_castToDepth() {
        const ret = wasm.depth___subduction_castToDepth(this.__wbg_ptr);
        return Depth.__wrap(ret);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmDepth`].
     * @returns {Depth}
     */
    __wasm_refgen_toWasmDepth() {
        const ret = wasm.depth___wasm_refgen_toWasmDepth(this.__wbg_ptr);
        return Depth.__wrap(ret);
    }
    /**
     * Whether this depth qualifies the commit as an eligible fragment head.
     *
     * Returns `true` for any nonzero depth. Mirrors
     * [`Depth::is_boundary`](sedimentree_core::depth::Depth::is_boundary).
     * Use this from JavaScript instead of comparing `value > 0` directly so
     * the boundary semantic stays in lock-step with the Rust definition.
     * @returns {boolean}
     */
    get isBoundary() {
        const ret = wasm.depth_isBoundary(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Creates a new `WasmDepth` from a JavaScript value.
     *
     * # Errors
     *
     * Returns a `NotU32Error` if the JS value is not safely coercible to `u32`.
     * @param {any} js_value
     */
    constructor(js_value) {
        const ret = wasm.depth_new(js_value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        DepthFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * The depth value as an integer.
     * @returns {number}
     */
    get value() {
        const ret = wasm.depth_value(this.__wbg_ptr);
        return ret >>> 0;
    }
}
if (Symbol.dispose) Depth.prototype[Symbol.dispose] = Depth.prototype.free;
exports.Depth = Depth;

/**
 * A wrapper around digest bytes for use in JavaScript via wasm-bindgen.
 *
 * Since JavaScript doesn't have Rust's type system, this stores raw bytes
 * and converts to/from typed `Digest<T>` at the Rust boundary.
 */
class Digest {
    static __wrap(ptr) {
        const obj = Object.create(Digest.prototype);
        obj.__wbg_ptr = ptr;
        DigestFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        DigestFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_digest_free(ptr, 0);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmDigest`].
     * @returns {Digest}
     */
    __wasm_refgen_toWasmDigest() {
        const ret = wasm.digest___wasm_refgen_toWasmDigest(this.__wbg_ptr);
        return Digest.__wrap(ret);
    }
    /**
     * Creates a new digest from its Base58 string representation.
     *
     * # Errors
     *
     * Returns a `WasmInvalidDigest` error if the string cannot be decoded or is not a valid digest.
     * @param {string} s
     * @returns {Digest}
     */
    static fromBase58(s) {
        const ptr0 = passStringToWasm0(s, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.digest_fromBase58(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return Digest.__wrap(ret[0]);
    }
    /**
     * Creates a new digest from its byte representation.
     *
     * # Errors
     *
     * Returns a `WasmValue` error if the byte slice is not a valid digest.
     * @param {Uint8Array} bytes
     * @returns {Digest}
     */
    static fromBytes(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.digest_fromBytes(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return Digest.__wrap(ret[0]);
    }
    /**
     * Creates a new digest from its hexadecimal string representation.
     *
     * # Errors
     *
     * Returns a [`WasmInvalidDigest`] if the string is not a valid digest.
     * @param {string} s
     * @returns {Digest}
     */
    static fromHexString(s) {
        const ptr0 = passStringToWasm0(s, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.digest_fromHexString(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return Digest.__wrap(ret[0]);
    }
    /**
     * Creates a new digest from its byte representation.
     *
     * # Errors
     *
     * Returns a `WasmValue` error if the byte slice is not a valid digest.
     * @param {Uint8Array} bytes
     */
    constructor(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.digest_new(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        DigestFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Returns the byte representation of the digest.
     * @returns {Uint8Array}
     */
    toBytes() {
        const ret = wasm.digest_toBytes(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * Returns the hexadecimal string representation of the digest.
     * @returns {string}
     */
    toHexString() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.digest_toHexString(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) Digest.prototype[Symbol.dispose] = Digest.prototype.free;
exports.Digest = Digest;

/**
 * A data fragment used in the Sedimentree system.
 */
class Fragment {
    static __wrap(ptr) {
        const obj = Object.create(Fragment.prototype);
        obj.__wbg_ptr = ptr;
        FragmentFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FragmentFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_fragment_free(ptr, 0);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmFragment`].
     * @returns {Fragment}
     */
    __wasm_refgen_toWasmFragment() {
        const ret = wasm.fragment___wasm_refgen_toWasmFragment(this.__wbg_ptr);
        return Fragment.__wrap(ret);
    }
    /**
     * Get the blob metadata of the fragment.
     * @returns {BlobMeta}
     */
    get blobMeta() {
        const ret = wasm.fragment_blobMeta(this.__wbg_ptr);
        return BlobMeta.__wrap(ret);
    }
    /**
     * Get the boundary commit identifiers of the fragment.
     * @returns {CommitId[]}
     */
    get boundary() {
        const ret = wasm.fragment_boundary(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Get the head commit identifier of the fragment.
     * @returns {CommitId}
     */
    get head() {
        const ret = wasm.fragment_head(this.__wbg_ptr);
        return CommitId.__wrap(ret);
    }
    /**
     * Create a new fragment from the given sedimentree ID, head, boundary, checkpoints, and blob metadata.
     * @param {SedimentreeId} sedimentree_id
     * @param {CommitId} head
     * @param {CommitId[]} boundary
     * @param {CommitId[]} checkpoints
     * @param {BlobMeta} blob_meta
     */
    constructor(sedimentree_id, head, boundary, checkpoints, blob_meta) {
        _assertClass(sedimentree_id, SedimentreeId);
        _assertClass(head, CommitId);
        const ptr0 = passArrayJsValueToWasm0(boundary, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayJsValueToWasm0(checkpoints, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        _assertClass(blob_meta, BlobMeta);
        const ret = wasm.fragment_new(sedimentree_id.__wbg_ptr, head.__wbg_ptr, ptr0, len0, ptr1, len1, blob_meta.__wbg_ptr);
        this.__wbg_ptr = ret;
        FragmentFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
}
if (Symbol.dispose) Fragment.prototype[Symbol.dispose] = Fragment.prototype.free;
exports.Fragment = Fragment;

/**
 * One unsigned fragment + its blob, ready for bulk insertion.
 *
 * Construct with `new FragmentInput(fragment, blob)` from JavaScript;
 * pass arrays of these to the batch write methods
 * ([`addBatch`](crate::subduction::WasmSubduction::add_batch) /
 * [`storeBuiltBatch`](crate::subduction::WasmSubduction::store_built_batch),
 * [`addFragmentsBatch`](crate::subduction::WasmSubduction::add_fragments_batch) /
 * [`storeFragmentsBatch`](crate::subduction::WasmSubduction::store_fragments_batch)).
 */
class FragmentInput {
    static __unwrap(jsValue) {
        if (!(jsValue instanceof FragmentInput)) {
            return 0;
        }
        return jsValue.__destroy_into_raw();
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FragmentInputFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_fragmentinput_free(ptr, 0);
    }
    /**
     * A copy of the blob bytes.
     * @returns {Uint8Array}
     */
    get blob() {
        const ret = wasm.fragmentinput_blob(this.__wbg_ptr);
        return ret;
    }
    /**
     * A copy of the underlying unsigned fragment.
     * @returns {Fragment}
     */
    get fragment() {
        const ret = wasm.fragmentinput_fragment(this.__wbg_ptr);
        return Fragment.__wrap(ret);
    }
    /**
     * Pair an unsigned [`Fragment`](sedimentree_core::fragment::Fragment)
     * with the bytes of its associated blob.
     *
     * `blob` accepts any `BufferSource`-like value from JavaScript
     * (`Uint8Array`, `ArrayBuffer`, plain `number[]`); `wasm_bindgen` copies
     * the bytes into a `Vec<u8>` owned by this struct.
     * @param {Fragment} fragment
     * @param {Uint8Array} blob
     */
    constructor(fragment, blob) {
        _assertClass(fragment, Fragment);
        var ptr0 = fragment.__destroy_into_raw();
        const ptr1 = passArray8ToWasm0(blob, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.fragmentinput_new(ptr0, ptr1, len1);
        this.__wbg_ptr = ret;
        FragmentInputFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
}
if (Symbol.dispose) FragmentInput.prototype[Symbol.dispose] = FragmentInput.prototype.free;
exports.FragmentInput = FragmentInput;

/**
 * A request for a specific fragment in the Sedimentree system.
 */
class FragmentRequested {
    static __wrap(ptr) {
        const obj = Object.create(FragmentRequested.prototype);
        obj.__wbg_ptr = ptr;
        FragmentRequestedFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FragmentRequestedFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_fragmentrequested_free(ptr, 0);
    }
    /**
     * Get the depth of the requested fragment.
     * @returns {Depth}
     */
    get depth() {
        const ret = wasm.fragmentrequested_depth(this.__wbg_ptr);
        return Depth.__wrap(ret);
    }
    /**
     * Get the head commit identifier of the requested fragment.
     * @returns {CommitId}
     */
    get head() {
        const ret = wasm.fragmentrequested_head(this.__wbg_ptr);
        return CommitId.__wrap(ret);
    }
    /**
     * Create a new fragment request from the given commit ID.
     * @param {CommitId} commit_id
     * @param {Depth} depth
     */
    constructor(commit_id, depth) {
        _assertClass(commit_id, CommitId);
        _assertClass(depth, Depth);
        const ret = wasm.fragmentrequested_new(commit_id.__wbg_ptr, depth.__wbg_ptr);
        this.__wbg_ptr = ret;
        FragmentRequestedFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
}
if (Symbol.dispose) FragmentRequested.prototype[Symbol.dispose] = FragmentRequested.prototype.free;
exports.FragmentRequested = FragmentRequested;

/**
 * A fragment stored with its associated blob.
 */
class FragmentWithBlob {
    static __wrap(ptr) {
        const obj = Object.create(FragmentWithBlob.prototype);
        obj.__wbg_ptr = ptr;
        FragmentWithBlobFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FragmentWithBlobFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_fragmentwithblob_free(ptr, 0);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmFragmentWithBlob`].
     * @returns {FragmentWithBlob}
     */
    __wasm_refgen_toWasmFragmentWithBlob() {
        const ret = wasm.fragmentwithblob___wasm_refgen_toWasmFragmentWithBlob(this.__wbg_ptr);
        return FragmentWithBlob.__wrap(ret);
    }
    /**
     * Get the blob.
     * @returns {Uint8Array}
     */
    get blob() {
        const ret = wasm.fragmentwithblob_blob(this.__wbg_ptr);
        return ret;
    }
    /**
     * Create a new fragment with blob.
     * @param {SignedFragment} signed
     * @param {Uint8Array} blob
     */
    constructor(signed, blob) {
        _assertClass(signed, SignedFragment);
        var ptr0 = signed.__destroy_into_raw();
        const ret = wasm.fragmentwithblob_new(ptr0, blob);
        this.__wbg_ptr = ret;
        FragmentWithBlobFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Get the signed fragment.
     * @returns {SignedFragment}
     */
    get signed() {
        const ret = wasm.fragmentwithblob_signed(this.__wbg_ptr);
        return SignedFragment.__wrap(ret);
    }
}
if (Symbol.dispose) FragmentWithBlob.prototype[Symbol.dispose] = FragmentWithBlob.prototype.free;
exports.FragmentWithBlob = FragmentWithBlob;

class FragmentsArray {
    static __wrap(ptr) {
        const obj = Object.create(FragmentsArray.prototype);
        obj.__wbg_ptr = ptr;
        FragmentsArrayFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FragmentsArrayFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_fragmentsarray_free(ptr, 0);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmFragmentsArray`].
     * @returns {FragmentsArray}
     */
    __wasm_refgen_toWasmFragmentsArray() {
        const ret = wasm.fragmentsarray___wasm_refgen_toWasmFragmentsArray(this.__wbg_ptr);
        return FragmentsArray.__wrap(ret);
    }
}
if (Symbol.dispose) FragmentsArray.prototype[Symbol.dispose] = FragmentsArray.prototype.free;
exports.FragmentsArray = FragmentsArray;

/**
 * An overridable hash metric.
 */
class HashMetric {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        HashMetricFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_hashmetric_free(ptr, 0);
    }
    /**
     * Create a new `WasmHashMetric` with an optional JavaScript function.
     *
     * Defaults to counting leading zero bytes if no function is provided.
     * @param {Function | null} [func]
     */
    constructor(func) {
        const ret = wasm.hashmetric_new(isLikeNone(func) ? 0 : addToExternrefTable0(func));
        this.__wbg_ptr = ret;
        HashMetricFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
}
if (Symbol.dispose) HashMetric.prototype[Symbol.dispose] = HashMetric.prototype.free;
exports.HashMetric = HashMetric;

/**
 * `IndexedDB` storage backend with compound storage (signed + blob together).
 */
class IndexedDbStorage {
    static __wrap(ptr) {
        const obj = Object.create(IndexedDbStorage.prototype);
        obj.__wbg_ptr = ptr;
        IndexedDbStorageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        IndexedDbStorageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_indexeddbstorage_free(ptr, 0);
    }
    /**
     * Delete all commits for a sedimentree.
     *
     * # Errors
     *
     * Returns a [`WasmDeleteAllCommitsError`] if commits could not be deleted.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<void>}
     */
    deleteAllCommits(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.indexeddbstorage_deleteAllCommits(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * Delete all fragments for a sedimentree.
     *
     * # Errors
     *
     * Returns a [`WasmDeleteAllFragmentsError`] if fragments could not be deleted.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<void>}
     */
    deleteAllFragments(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.indexeddbstorage_deleteAllFragments(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * Delete a commit by digest.
     *
     * # Errors
     *
     * Returns a [`WasmDeleteCommitError`] if the commit could not be deleted.
     * @param {SedimentreeId} sedimentree_id
     * @param {CommitId} commit_id
     * @returns {Promise<void>}
     */
    deleteCommit(sedimentree_id, commit_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        _assertClass(commit_id, CommitId);
        const ret = wasm.indexeddbstorage_deleteCommit(this.__wbg_ptr, sedimentree_id.__wbg_ptr, commit_id.__wbg_ptr);
        return ret;
    }
    /**
     * Delete a fragment by its identifier.
     *
     * # Errors
     *
     * Returns a [`WasmDeleteFragmentError`] if the fragment could not be deleted.
     * @param {SedimentreeId} sedimentree_id
     * @param {CommitId} fragment_head
     * @returns {Promise<void>}
     */
    deleteFragment(sedimentree_id, fragment_head) {
        _assertClass(sedimentree_id, SedimentreeId);
        _assertClass(fragment_head, CommitId);
        const ret = wasm.indexeddbstorage_deleteFragment(this.__wbg_ptr, sedimentree_id.__wbg_ptr, fragment_head.__wbg_ptr);
        return ret;
    }
    /**
     * Delete a Sedimentree ID from storage.
     *
     * # Errors
     *
     * Returns [`WasmDeleteSedimentreeIdError`] if deletion failed.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<void>}
     */
    deleteSedimentreeId(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.indexeddbstorage_deleteSedimentreeId(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * Get the name of the fragment store.
     * @returns {string}
     */
    fragmentStoreName() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.indexeddbstorage_fragmentStoreName(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * List all commit IDs for a sedimentree.
     *
     * # Errors
     *
     * Returns a [`WasmListDigestsError`] if commit IDs could not be listed.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<CommitId[]>}
     */
    listCommitIds(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.indexeddbstorage_listCommitIds(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * List all fragment IDs for a sedimentree.
     *
     * # Errors
     *
     * Returns a [`WasmListDigestsError`] if fragment IDs could not be listed.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<CommitId[]>}
     */
    listFragmentIds(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.indexeddbstorage_listFragmentIds(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * Load all commits for a sedimentree, returning `CommitWithBlob[]`.
     *
     * # Errors
     *
     * Returns a [`WasmLoadAllCommitsError`] if commits could not be loaded.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<CommitWithBlob[]>}
     */
    loadAllCommits(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.indexeddbstorage_loadAllCommits(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * Load all fragments for a sedimentree, returning `FragmentWithBlob[]`.
     *
     * # Errors
     *
     * Returns a [`WasmLoadAllFragmentsError`] if fragments could not be loaded.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<FragmentWithBlob[]>}
     */
    loadAllFragments(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.indexeddbstorage_loadAllFragments(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * Load all Sedimentree IDs from storage.
     *
     * # Errors
     *
     * Returns [`WasmLoadAllSedimentreeIdsError`] if there was a problem loading.
     * @returns {Promise<SedimentreeId[]>}
     */
    loadAllSedimentreeIds() {
        const ret = wasm.indexeddbstorage_loadAllSedimentreeIds(this.__wbg_ptr);
        return ret;
    }
    /**
     * Load a commit by its identifier, returning `CommitWithBlob` or null.
     *
     * # Errors
     *
     * Returns a [`WasmLoadCommitError`] if the commit could not be loaded.
     * @param {SedimentreeId} sedimentree_id
     * @param {CommitId} commit_id
     * @returns {Promise<CommitWithBlob | undefined>}
     */
    loadCommit(sedimentree_id, commit_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        _assertClass(commit_id, CommitId);
        const ret = wasm.indexeddbstorage_loadCommit(this.__wbg_ptr, sedimentree_id.__wbg_ptr, commit_id.__wbg_ptr);
        return ret;
    }
    /**
     * Load a fragment by its identifier, returning `FragmentWithBlob` or null.
     *
     * # Errors
     *
     * Returns a [`WasmLoadFragmentError`] if the fragment could not be loaded.
     * @param {SedimentreeId} sedimentree_id
     * @param {CommitId} fragment_head
     * @returns {Promise<FragmentWithBlob | undefined>}
     */
    loadFragment(sedimentree_id, fragment_head) {
        _assertClass(sedimentree_id, SedimentreeId);
        _assertClass(fragment_head, CommitId);
        const ret = wasm.indexeddbstorage_loadFragment(this.__wbg_ptr, sedimentree_id.__wbg_ptr, fragment_head.__wbg_ptr);
        return ret;
    }
    /**
     * Get the name of the loose commit store.
     * @returns {string}
     */
    looseCommitStoreName() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.indexeddbstorage_looseCommitStoreName(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Save a batch of commits and fragments in a single IDB transaction.
     *
     * Each commit element must be a JS object with `{commitId, signedCommit, blob}`.
     * Each fragment element must be a JS object with `{fragmentHead, signedFragment, blob}`.
     * This matches the shape produced by `JsStorage::save_batch`.
     *
     * The sedimentree ID is _not_ registered here — the caller
     * (`JsStorage::save_batch`) handles that via a separate
     * `saveSedimentreeId` call so the contract is enforced at the
     * duck-typed layer regardless of backend.
     *
     * # Errors
     *
     * Returns [`WasmSaveBatchAllError`] on transaction, store access, or
     * record extraction failures.
     * @param {SedimentreeId} sedimentree_id
     * @param {Array<any>} commits
     * @param {Array<any>} fragments
     * @returns {Promise<number>}
     */
    saveBatchAll(sedimentree_id, commits, fragments) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.indexeddbstorage_saveBatchAll(this.__wbg_ptr, sedimentree_id.__wbg_ptr, commits, fragments);
        return ret;
    }
    /**
     * Save a commit with its blob to storage (compound storage).
     *
     * The `commit_id` parameter is used as the storage key and _must_
     * match the `head()` embedded in the signed commit payload. The
     * caller is responsible for maintaining this invariant; the storage
     * layer does not decode the signed payload to verify it.
     *
     * # Errors
     *
     * Returns a [`WasmSaveCommitError`] if the commit could not be saved.
     * @param {SedimentreeId} sedimentree_id
     * @param {CommitId} commit_id
     * @param {SignedLooseCommit} signed
     * @param {Uint8Array} blob
     * @returns {Promise<void>}
     */
    saveCommit(sedimentree_id, commit_id, signed, blob) {
        _assertClass(sedimentree_id, SedimentreeId);
        _assertClass(commit_id, CommitId);
        _assertClass(signed, SignedLooseCommit);
        const ret = wasm.indexeddbstorage_saveCommit(this.__wbg_ptr, sedimentree_id.__wbg_ptr, commit_id.__wbg_ptr, signed.__wbg_ptr, blob);
        return ret;
    }
    /**
     * Save a fragment with its blob to storage (compound storage).
     *
     * # Errors
     *
     * Returns a [`WasmSaveFragmentError`] if the fragment could not be saved.
     * @param {SedimentreeId} sedimentree_id
     * @param {CommitId} fragment_head
     * @param {SignedFragment} signed
     * @param {Uint8Array} blob
     * @returns {Promise<void>}
     */
    saveFragment(sedimentree_id, fragment_head, signed, blob) {
        _assertClass(sedimentree_id, SedimentreeId);
        _assertClass(fragment_head, CommitId);
        _assertClass(signed, SignedFragment);
        const ret = wasm.indexeddbstorage_saveFragment(this.__wbg_ptr, sedimentree_id.__wbg_ptr, fragment_head.__wbg_ptr, signed.__wbg_ptr, blob);
        return ret;
    }
    /**
     * Insert a Sedimentree ID into storage.
     *
     * # Errors
     *
     * Returns [`WasmSaveSedimentreeIdError`] if saving a [`SedimentreeId`] fails.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<void>}
     */
    saveSedimentreeId(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.indexeddbstorage_saveSedimentreeId(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * Get the name of the `sedimentreeId` store.
     * @returns {string}
     */
    sedimentreeIdStoreName() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.indexeddbstorage_sedimentreeIdStoreName(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Create a new `IndexedDbStorage` instance, opening (or creating) the database.
     *
     * If `name` is `None`, uses the default database name
     * `"@automerge/subduction/db"`.
     *
     * Pass a custom name for multi-tenant scenarios or isolated storage
     * instances within the same origin.
     *
     * # Errors
     *
     * Returns a `JsValue` if the database could not be opened.
     * @param {IDBFactory} factory
     * @param {string | null} [name]
     * @returns {Promise<IndexedDbStorage>}
     */
    static setup(factory, name) {
        var ptr0 = isLikeNone(name) ? 0 : passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.indexeddbstorage_setup(factory, ptr0, len0);
        return ret;
    }
}
if (Symbol.dispose) IndexedDbStorage.prototype[Symbol.dispose] = IndexedDbStorage.prototype.free;
exports.IndexedDbStorage = IndexedDbStorage;

/**
 * A Wasm wrapper around the [`LooseCommit`] type.
 */
class LooseCommit {
    static __wrap(ptr) {
        const obj = Object.create(LooseCommit.prototype);
        obj.__wbg_ptr = ptr;
        LooseCommitFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        LooseCommitFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_loosecommit_free(ptr, 0);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmLooseCommit`].
     * @returns {LooseCommit}
     */
    __wasm_refgen_toWasmLooseCommit() {
        const ret = wasm.loosecommit___wasm_refgen_toWasmLooseCommit(this.__wbg_ptr);
        return LooseCommit.__wrap(ret);
    }
    /**
     * Get the blob metadata of the commit.
     * @returns {BlobMeta}
     */
    get blobMeta() {
        const ret = wasm.loosecommit_blobMeta(this.__wbg_ptr);
        return BlobMeta.__wrap(ret);
    }
    /**
     * Get the commit's head identifier.
     * @returns {CommitId}
     */
    get commitId() {
        const ret = wasm.loosecommit_commitId(this.__wbg_ptr);
        return CommitId.__wrap(ret);
    }
    /**
     * Get the digest of the commit (content hash).
     * @returns {Digest}
     */
    get digest() {
        const ret = wasm.loosecommit_digest(this.__wbg_ptr);
        return Digest.__wrap(ret);
    }
    /**
     * Create a new `LooseCommit` from the given sedimentree ID, head, parents, and blob metadata.
     * @param {SedimentreeId} sedimentree_id
     * @param {CommitId} head
     * @param {CommitId[]} parents
     * @param {BlobMeta} blob_meta
     */
    constructor(sedimentree_id, head, parents, blob_meta) {
        _assertClass(sedimentree_id, SedimentreeId);
        _assertClass(head, CommitId);
        const ptr0 = passArrayJsValueToWasm0(parents, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        _assertClass(blob_meta, BlobMeta);
        const ret = wasm.loosecommit_new(sedimentree_id.__wbg_ptr, head.__wbg_ptr, ptr0, len0, blob_meta.__wbg_ptr);
        this.__wbg_ptr = ret;
        LooseCommitFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Get the parent commit identifiers.
     * @returns {CommitId[]}
     */
    get parents() {
        const ret = wasm.loosecommit_parents(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) LooseCommit.prototype[Symbol.dispose] = LooseCommit.prototype.free;
exports.LooseCommit = LooseCommit;

/**
 * An in-memory Ed25519 signer exposed to JavaScript.
 *
 * Implements the `Signer` interface (`sign` / `verifyingKey`) so it can be
 * passed anywhere a [`JsSigner`](crate::signer::JsSigner) is expected.
 *
 * # Example
 *
 * ```javascript
 * import { MemorySigner } from "@automerge/subduction";
 *
 * const signer = MemorySigner.generate();
 * console.log("Peer ID:", signer.peerId().toString());
 * ```
 */
class MemorySigner {
    static __wrap(ptr) {
        const obj = Object.create(MemorySigner.prototype);
        obj.__wbg_ptr = ptr;
        MemorySignerFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        MemorySignerFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_memorysigner_free(ptr, 0);
    }
    /**
     * Create a signer from raw 32-byte Ed25519 secret key bytes.
     *
     * # Errors
     *
     * Returns an error if `bytes` is not exactly 32 bytes.
     * @param {Uint8Array} bytes
     * @returns {MemorySigner}
     */
    static fromBytes(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.memorysigner_fromBytes(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return MemorySigner.__wrap(ret[0]);
    }
    /**
     * Create a new signer with a randomly generated Ed25519 key.
     *
     * # Panics
     *
     * Panics if the system random number generator fails.
     * @returns {MemorySigner}
     */
    static generate() {
        const ret = wasm.memorysigner_generate();
        return MemorySigner.__wrap(ret);
    }
    /**
     * Create a new signer with a randomly generated Ed25519 key.
     *
     * This is the JS constructor (`new MemorySigner()`), equivalent to
     * [`generate`](Self::generate).
     *
     * # Panics
     *
     * Panics if the system random number generator fails.
     */
    constructor() {
        const ret = wasm.memorysigner_new();
        this.__wbg_ptr = ret;
        MemorySignerFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Get the peer ID derived from this signer's verifying key.
     * @returns {PeerId}
     */
    peerId() {
        const ret = wasm.memorysigner_peerId(this.__wbg_ptr);
        return PeerId.__wrap(ret);
    }
    /**
     * Sign a message and return the 64-byte Ed25519 signature as a `Uint8Array`.
     *
     * This fulfils the `Signer.sign(message)` interface contract.
     * Returns a `Promise<Uint8Array>` for consistency with the async signer interface.
     * @param {Uint8Array} message
     * @returns {Promise<Uint8Array>}
     */
    sign(message) {
        const ptr0 = passArray8ToWasm0(message, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.memorysigner_sign(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Get the 32-byte Ed25519 verifying (public) key as a `Uint8Array`.
     *
     * This fulfils the `Signer.verifyingKey()` interface contract.
     * @returns {Uint8Array}
     */
    verifyingKey() {
        const ret = wasm.memorysigner_verifyingKey(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) MemorySigner.prototype[Symbol.dispose] = MemorySigner.prototype.free;
exports.MemorySigner = MemorySigner;

/**
 * An in-memory storage implementation for use in tests and development.
 *
 * This wraps the core `MemoryStorage` and exposes it via the `SedimentreeStorage` interface.
 */
class MemoryStorage {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        MemoryStorageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_memorystorage_free(ptr, 0);
    }
    /**
     * Single-key existence check for a sedimentree id (O(1)).
     *
     * Implements the optional `containsSedimentreeId` storage method so the
     * hydration hot path avoids enumerating every id.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<any>}
     */
    containsSedimentreeId(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.memorystorage_containsSedimentreeId(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * Delete all commits for a sedimentree.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<any>}
     */
    deleteAllCommits(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.memorystorage_deleteAllCommits(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * Delete all fragments for a sedimentree.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<any>}
     */
    deleteAllFragments(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.memorystorage_deleteAllFragments(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * Delete a single commit by its ID.
     * @param {SedimentreeId} sedimentree_id
     * @param {CommitId} commit_id
     * @returns {Promise<any>}
     */
    deleteCommit(sedimentree_id, commit_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        _assertClass(commit_id, CommitId);
        const ret = wasm.memorystorage_deleteCommit(this.__wbg_ptr, sedimentree_id.__wbg_ptr, commit_id.__wbg_ptr);
        return ret;
    }
    /**
     * Delete a fragment by its identifier.
     * @param {SedimentreeId} sedimentree_id
     * @param {CommitId} fragment_head
     * @returns {Promise<any>}
     */
    deleteFragment(sedimentree_id, fragment_head) {
        _assertClass(sedimentree_id, SedimentreeId);
        _assertClass(fragment_head, CommitId);
        const ret = wasm.memorystorage_deleteFragment(this.__wbg_ptr, sedimentree_id.__wbg_ptr, fragment_head.__wbg_ptr);
        return ret;
    }
    /**
     * Delete a sedimentree ID.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<any>}
     */
    deleteSedimentreeId(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.memorystorage_deleteSedimentreeId(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * List all commit IDs for a sedimentree.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<any>}
     */
    listCommitIds(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.memorystorage_listCommitIds(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * List all fragment IDs for a sedimentree.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<any>}
     */
    listFragmentIds(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.memorystorage_listFragmentIds(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * Load all commits for a sedimentree, returning `CommitWithBlob[]`.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<any>}
     */
    loadAllCommits(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.memorystorage_loadAllCommits(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * Load all fragments for a sedimentree, returning `FragmentWithBlob[]`.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<any>}
     */
    loadAllFragments(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.memorystorage_loadAllFragments(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
    /**
     * Load all sedimentree IDs.
     * @returns {Promise<any>}
     */
    loadAllSedimentreeIds() {
        const ret = wasm.memorystorage_loadAllSedimentreeIds(this.__wbg_ptr);
        return ret;
    }
    /**
     * Load a single commit by its ID, returning `CommitWithBlob` or null.
     * @param {SedimentreeId} sedimentree_id
     * @param {CommitId} commit_id
     * @returns {Promise<any>}
     */
    loadCommit(sedimentree_id, commit_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        _assertClass(commit_id, CommitId);
        const ret = wasm.memorystorage_loadCommit(this.__wbg_ptr, sedimentree_id.__wbg_ptr, commit_id.__wbg_ptr);
        return ret;
    }
    /**
     * Load a fragment by its identifier, returning `FragmentWithBlob` or null.
     * @param {SedimentreeId} sedimentree_id
     * @param {CommitId} fragment_head
     * @returns {Promise<any>}
     */
    loadFragment(sedimentree_id, fragment_head) {
        _assertClass(sedimentree_id, SedimentreeId);
        _assertClass(fragment_head, CommitId);
        const ret = wasm.memorystorage_loadFragment(this.__wbg_ptr, sedimentree_id.__wbg_ptr, fragment_head.__wbg_ptr);
        return ret;
    }
    /**
     * Create a new in-memory storage instance.
     */
    constructor() {
        const ret = wasm.memorystorage_new();
        this.__wbg_ptr = ret;
        MemoryStorageFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Save commits and fragments in a single batch.
     * @param {SedimentreeId} sedimentree_id
     * @param {Array<any>} commits
     * @param {Array<any>} fragments
     * @returns {Promise<any>}
     */
    saveBatchAll(sedimentree_id, commits, fragments) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.memorystorage_saveBatchAll(this.__wbg_ptr, sedimentree_id.__wbg_ptr, commits, fragments);
        return ret;
    }
    /**
     * Save a commit with its blob.
     *
     * The `commit_id` parameter must match the `head()` embedded in
     * the signed commit payload. Returns an error if they differ.
     *
     * # Errors
     *
     * Returns a JS error if:
     * - The signed payload cannot be decoded
     * - The `commit_id` does not match the embedded `head()`
     * @param {SedimentreeId} sedimentree_id
     * @param {CommitId} commit_id
     * @param {SignedLooseCommit} signed_commit
     * @param {Uint8Array} blob
     * @returns {Promise<any>}
     */
    saveCommit(sedimentree_id, commit_id, signed_commit, blob) {
        _assertClass(sedimentree_id, SedimentreeId);
        _assertClass(commit_id, CommitId);
        _assertClass(signed_commit, SignedLooseCommit);
        const ret = wasm.memorystorage_saveCommit(this.__wbg_ptr, sedimentree_id.__wbg_ptr, commit_id.__wbg_ptr, signed_commit.__wbg_ptr, blob);
        return ret;
    }
    /**
     * Save a fragment with its blob.
     * @param {SedimentreeId} sedimentree_id
     * @param {CommitId} _fragment_head
     * @param {SignedFragment} signed_fragment
     * @param {Uint8Array} blob
     * @returns {Promise<any>}
     */
    saveFragment(sedimentree_id, _fragment_head, signed_fragment, blob) {
        _assertClass(sedimentree_id, SedimentreeId);
        _assertClass(_fragment_head, CommitId);
        _assertClass(signed_fragment, SignedFragment);
        const ret = wasm.memorystorage_saveFragment(this.__wbg_ptr, sedimentree_id.__wbg_ptr, _fragment_head.__wbg_ptr, signed_fragment.__wbg_ptr, blob);
        return ret;
    }
    /**
     * Save a sedimentree ID.
     * @param {SedimentreeId} sedimentree_id
     * @returns {Promise<any>}
     */
    saveSedimentreeId(sedimentree_id) {
        _assertClass(sedimentree_id, SedimentreeId);
        const ret = wasm.memorystorage_saveSedimentreeId(this.__wbg_ptr, sedimentree_id.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) MemoryStorage.prototype[Symbol.dispose] = MemoryStorage.prototype.free;
exports.MemoryStorage = MemoryStorage;

/**
 * A `Transport` backed by a `MessagePort` (or any object with
 * `postMessage` / `onmessage` / `close`).
 *
 * Implements the byte-oriented `Transport` interface (`sendBytes`,
 * `recvBytes`, `disconnect`) using the port as the underlying channel.
 * After the handshake, the [`Authenticated`] wrapper provides the sync API.
 */
class MessagePortTransport {
    static __wrap(ptr) {
        const obj = Object.create(MessagePortTransport.prototype);
        obj.__wbg_ptr = ptr;
        MessagePortTransportFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        MessagePortTransportFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_messageporttransport_free(ptr, 0);
    }
    /**
     * Disconnect (close the port) and fire the `onDisconnect` callback
     * if registered. The callback is taken out of the cell before
     * invocation, so it may safely re-enter the transport (e.g. to
     * register a new callback) without tripping a `BorrowMutError`.
     * @returns {Promise<any>}
     */
    disconnect() {
        const ret = wasm.messageporttransport_disconnect(this.__wbg_ptr);
        return ret;
    }
    /**
     * Create a new connection wrapping the given `MessagePort`.
     * @param {any} port
     */
    constructor(port) {
        const ret = wasm.messageporttransport_new(port);
        this.__wbg_ptr = ret;
        MessagePortTransportFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Register a callback to be invoked when the transport disconnects.
     * Part of the [`Transport`](super::JsTransport) interface contract.
     * @param {Function} callback
     */
    onDisconnect(callback) {
        wasm.messageporttransport_onDisconnect(this.__wbg_ptr, callback);
    }
    /**
     * Receive raw bytes (for the handshake phase).
     * @returns {Promise<any>}
     */
    recvBytes() {
        const ret = wasm.messageporttransport_recvBytes(this.__wbg_ptr);
        return ret;
    }
    /**
     * Send raw bytes (for the handshake phase).
     * @param {Uint8Array} bytes
     * @returns {Promise<any>}
     */
    sendBytes(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.messageporttransport_sendBytes(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
}
if (Symbol.dispose) MessagePortTransport.prototype[Symbol.dispose] = MessagePortTransport.prototype.free;
exports.MessagePortTransport = MessagePortTransport;

/**
 * A 64-bit nonce represented as big-endian bytes.
 */
class Nonce {
    static __wrap(ptr) {
        const obj = Object.create(Nonce.prototype);
        obj.__wbg_ptr = ptr;
        NonceFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        NonceFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_nonce_free(ptr, 0);
    }
    /**
     * Get the nonce as big-endian bytes.
     * @returns {Uint8Array}
     */
    get bytes() {
        const ret = wasm.nonce_bytes(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * Create a new [`WasmNonce`] from exactly 8 big-endian bytes.
     *
     * # Errors
     *
     * Returns [`WasmNonceError`] if the input is not exactly 8 bytes.
     * @param {Uint8Array} bytes
     */
    constructor(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.nonce_new(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        NonceFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Generate a random nonce.
     *
     * # Panics
     *
     * Panics if the system random number generator fails.
     * @returns {Nonce}
     */
    static random() {
        const ret = wasm.nonce_random();
        return Nonce.__wrap(ret);
    }
}
if (Symbol.dispose) Nonce.prototype[Symbol.dispose] = Nonce.prototype.free;
exports.Nonce = Nonce;

/**
 * Result of a peer batch sync request.
 */
class PeerBatchSyncResult {
    static __wrap(ptr) {
        const obj = Object.create(PeerBatchSyncResult.prototype);
        obj.__wbg_ptr = ptr;
        PeerBatchSyncResultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PeerBatchSyncResultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_peerbatchsyncresult_free(ptr, 0);
    }
    /**
     * Statistics about the sync operation.
     * @returns {SyncStats}
     */
    get stats() {
        const ret = wasm.peerbatchsyncresult_stats(this.__wbg_ptr);
        return SyncStats.__wrap(ret);
    }
    /**
     * Whether the batch sync was successful with at least one connection.
     * @returns {boolean}
     */
    get success() {
        const ret = wasm.peerbatchsyncresult_success(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Errors that occurred during the batch sync.
     * @returns {Error[]}
     */
    get transportErrors() {
        const ret = wasm.peerbatchsyncresult_transportErrors(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) PeerBatchSyncResult.prototype[Symbol.dispose] = PeerBatchSyncResult.prototype.free;
exports.PeerBatchSyncResult = PeerBatchSyncResult;

/**
 * A JavaScript-compatible wrapper around the Rust `PeerId` type.
 */
class PeerId {
    static __wrap(ptr) {
        const obj = Object.create(PeerId.prototype);
        obj.__wbg_ptr = ptr;
        PeerIdFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PeerIdFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_peerid_free(ptr, 0);
    }
    /**
     * Creates a new `WasmPeerId` from a `PeerId`.
     *
     * # Errors
     *
     * Returns a `WasmInvalidPeerId` if the provided byte slice is not exactly 32 bytes long.
     * @param {Uint8Array} bytes
     */
    constructor(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.peerid_new(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        PeerIdFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Returns the byte representation of the `PeerId`.
     * @returns {Uint8Array}
     */
    toBytes() {
        const ret = wasm.peerid_toBytes(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * Returns the string representation of the `PeerId`.
     * @returns {string}
     */
    toString() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.peerid_toString(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) PeerId.prototype[Symbol.dispose] = PeerId.prototype.free;
exports.PeerId = PeerId;

/**
 * Map of peer IDs to their batch sync results.
 */
class PeerResultMap {
    static __wrap(ptr) {
        const obj = Object.create(PeerResultMap.prototype);
        obj.__wbg_ptr = ptr;
        PeerResultMapFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PeerResultMapFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_peerresultmap_free(ptr, 0);
    }
    /**
     * Get all entries in the peer result map.
     * @returns {PeerBatchSyncResult[]}
     */
    entries() {
        const ret = wasm.peerresultmap_entries(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Get the result for a specific peer ID.
     * @param {PeerId} peer_id
     * @returns {PeerBatchSyncResult | undefined}
     */
    getResult(peer_id) {
        _assertClass(peer_id, PeerId);
        const ret = wasm.peerresultmap_getResult(this.__wbg_ptr, peer_id.__wbg_ptr);
        return ret === 0 ? undefined : PeerBatchSyncResult.__wrap(ret);
    }
}
if (Symbol.dispose) PeerResultMap.prototype[Symbol.dispose] = PeerResultMap.prototype.free;
exports.PeerResultMap = PeerResultMap;

/**
 * Wasm wrapper for [`RequestId`].
 */
class RequestId {
    static __wrap(ptr) {
        const obj = Object.create(RequestId.prototype);
        obj.__wbg_ptr = ptr;
        RequestIdFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        RequestIdFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_requestid_free(ptr, 0);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmRequestId`].
     * @returns {RequestId}
     */
    __wasm_refgen_toWasmRequestId() {
        const ret = wasm.requestid___wasm_refgen_toWasmRequestId(this.__wbg_ptr);
        return RequestId.__wrap(ret);
    }
    /**
     * Create a new [`RequestId`] from a requestor peer ID and nonce.
     * @param {PeerId} requestor
     * @param {Nonce} nonce
     */
    constructor(requestor, nonce) {
        _assertClass(requestor, PeerId);
        _assertClass(nonce, Nonce);
        const ret = wasm.requestid_new(requestor.__wbg_ptr, nonce.__wbg_ptr);
        this.__wbg_ptr = ret;
        RequestIdFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * The request nonce.
     * @returns {Nonce}
     */
    get nonce() {
        const ret = wasm.requestid_nonce(this.__wbg_ptr);
        return Nonce.__wrap(ret);
    }
    /**
     * The peer ID of the requestor.
     * @returns {PeerId}
     */
    get requestor() {
        const ret = wasm.requestid_requestor(this.__wbg_ptr);
        return PeerId.__wrap(ret);
    }
}
if (Symbol.dispose) RequestId.prototype[Symbol.dispose] = RequestId.prototype.free;
exports.RequestId = RequestId;

/**
 * The main Sedimentree data structure.
 */
class Sedimentree {
    static __wrap(ptr) {
        const obj = Object.create(Sedimentree.prototype);
        obj.__wbg_ptr = ptr;
        SedimentreeFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SedimentreeFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sedimentree_free(ptr, 0);
    }
    /**
     * Create an empty Sedimentree.
     * @returns {Sedimentree}
     */
    static empty() {
        const ret = wasm.sedimentree_empty();
        return Sedimentree.__wrap(ret);
    }
    /**
     * Create a new Sedimentree from fragments and loose commits.
     * @param {Fragment[]} fragments
     * @param {LooseCommit[]} commits
     */
    constructor(fragments, commits) {
        const ptr0 = passArrayJsValueToWasm0(fragments, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayJsValueToWasm0(commits, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.sedimentree_new(ptr0, len0, ptr1, len1);
        this.__wbg_ptr = ret;
        SedimentreeFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
}
if (Symbol.dispose) Sedimentree.prototype[Symbol.dispose] = Sedimentree.prototype.free;
exports.Sedimentree = Sedimentree;

/**
 * Heads of a single sedimentree, returned by
 * [`WasmSubduction::get_all_heads`](WasmSubduction::get_all_heads).
 */
class SedimentreeHeads {
    static __wrap(ptr) {
        const obj = Object.create(SedimentreeHeads.prototype);
        obj.__wbg_ptr = ptr;
        SedimentreeHeadsFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SedimentreeHeadsFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sedimentreeheads_free(ptr, 0);
    }
    /**
     * The current heads of the sedimentree.
     * @returns {CommitId[]}
     */
    get heads() {
        const ret = wasm.sedimentreeheads_heads(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * The sedimentree ID these heads belong to.
     * @returns {SedimentreeId}
     */
    get id() {
        const ret = wasm.sedimentreeheads_id(this.__wbg_ptr);
        return SedimentreeId.__wrap(ret);
    }
}
if (Symbol.dispose) SedimentreeHeads.prototype[Symbol.dispose] = SedimentreeHeads.prototype.free;
exports.SedimentreeHeads = SedimentreeHeads;

/**
 * A Wasm wrapper around the [`SedimentreeId`] type.
 */
class SedimentreeId {
    static __wrap(ptr) {
        const obj = Object.create(SedimentreeId.prototype);
        obj.__wbg_ptr = ptr;
        SedimentreeIdFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    static __unwrap(jsValue) {
        if (!(jsValue instanceof SedimentreeId)) {
            return 0;
        }
        return jsValue.__destroy_into_raw();
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SedimentreeIdFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sedimentreeid_free(ptr, 0);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmSedimentreeId`].
     * @returns {SedimentreeId}
     */
    __wasm_refgen_toWasmSedimentreeId() {
        const ret = wasm.sedimentreeid___wasm_refgen_toWasmSedimentreeId(this.__wbg_ptr);
        return SedimentreeId.__wrap(ret);
    }
    /**
     * Create an ID from a byte array.
     *
     * # Errors
     *
     * Returns `Not32Bytes` if the provided byte array is not exactly 32 bytes long.
     * @param {Uint8Array} bytes
     * @returns {SedimentreeId}
     */
    static fromBytes(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.sedimentreeid_fromBytes(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return SedimentreeId.__wrap(ret[0]);
    }
    /**
     * Returns the raw bytes of this ID.
     * @returns {Uint8Array}
     */
    toBytes() {
        const ret = wasm.sedimentreeid_toBytes(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * Returns the string representation of the ID.
     * @returns {string}
     */
    toString() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.sedimentreeid_toString(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) SedimentreeId.prototype[Symbol.dispose] = SedimentreeId.prototype.free;
exports.SedimentreeId = SedimentreeId;

class SedimentreeIdsArray {
    static __wrap(ptr) {
        const obj = Object.create(SedimentreeIdsArray.prototype);
        obj.__wbg_ptr = ptr;
        SedimentreeIdsArrayFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SedimentreeIdsArrayFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sedimentreeidsarray_free(ptr, 0);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmSedimentreeIdsArray`].
     * @returns {SedimentreeIdsArray}
     */
    __wasm_refgen_toWasmSedimentreeIdsArray() {
        const ret = wasm.sedimentreeidsarray___wasm_refgen_toWasmSedimentreeIdsArray(this.__wbg_ptr);
        return SedimentreeIdsArray.__wrap(ret);
    }
}
if (Symbol.dispose) SedimentreeIdsArray.prototype[Symbol.dispose] = SedimentreeIdsArray.prototype.free;
exports.SedimentreeIdsArray = SedimentreeIdsArray;

/**
 * A Wasm wrapper around `Signed<Fragment>`.
 */
class SignedFragment {
    static __wrap(ptr) {
        const obj = Object.create(SignedFragment.prototype);
        obj.__wbg_ptr = ptr;
        SignedFragmentFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    static __unwrap(jsValue) {
        if (!(jsValue instanceof SignedFragment)) {
            return 0;
        }
        return jsValue.__destroy_into_raw();
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SignedFragmentFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_signedfragment_free(ptr, 0);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmSignedFragment`].
     * @returns {SignedFragment}
     */
    __wasm_refgen_toWasmSignedFragment() {
        const ret = wasm.signedfragment___wasm_refgen_toWasmSignedFragment(this.__wbg_ptr);
        return SignedFragment.__wrap(ret);
    }
    /**
     * Encode this signed fragment to raw bytes.
     * @returns {Uint8Array}
     */
    encode() {
        const ret = wasm.signedfragment_encode(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get the unsigned payload without re-verifying the signature.
     *
     * # Errors
     *
     * Returns an error if the payload cannot be decoded.
     * @returns {Fragment}
     */
    get payload() {
        const ret = wasm.signedfragment_payload(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return Fragment.__wrap(ret[0]);
    }
    /**
     * Decode a `SignedFragment` from raw bytes.
     *
     * # Errors
     *
     * Returns an error if the bytes are not a valid signed fragment.
     * @param {Uint8Array} bytes
     * @returns {SignedFragment}
     */
    static tryDecode(bytes) {
        const ret = wasm.signedfragment_tryDecode(bytes);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return SignedFragment.__wrap(ret[0]);
    }
}
if (Symbol.dispose) SignedFragment.prototype[Symbol.dispose] = SignedFragment.prototype.free;
exports.SignedFragment = SignedFragment;

/**
 * A Wasm wrapper around `Signed<LooseCommit>`.
 */
class SignedLooseCommit {
    static __wrap(ptr) {
        const obj = Object.create(SignedLooseCommit.prototype);
        obj.__wbg_ptr = ptr;
        SignedLooseCommitFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    static __unwrap(jsValue) {
        if (!(jsValue instanceof SignedLooseCommit)) {
            return 0;
        }
        return jsValue.__destroy_into_raw();
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SignedLooseCommitFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_signedloosecommit_free(ptr, 0);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmSignedLooseCommit`].
     * @returns {SignedLooseCommit}
     */
    __wasm_refgen_toWasmSignedLooseCommit() {
        const ret = wasm.signedloosecommit___wasm_refgen_toWasmSignedLooseCommit(this.__wbg_ptr);
        return SignedLooseCommit.__wrap(ret);
    }
    /**
     * Encode this signed loose commit to raw bytes.
     * @returns {Uint8Array}
     */
    encode() {
        const ret = wasm.signedloosecommit_encode(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get the unsigned payload without re-verifying the signature.
     *
     * # Errors
     *
     * Returns an error if the payload cannot be decoded.
     * @returns {LooseCommit}
     */
    get payload() {
        const ret = wasm.signedloosecommit_payload(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LooseCommit.__wrap(ret[0]);
    }
    /**
     * Decode a `SignedLooseCommit` from raw bytes.
     *
     * # Errors
     *
     * Returns an error if the bytes are not a valid signed loose commit.
     * @param {Uint8Array} bytes
     * @returns {SignedLooseCommit}
     */
    static tryDecode(bytes) {
        const ret = wasm.signedloosecommit_tryDecode(bytes);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return SignedLooseCommit.__wrap(ret[0]);
    }
}
if (Symbol.dispose) SignedLooseCommit.prototype[Symbol.dispose] = SignedLooseCommit.prototype.free;
exports.SignedLooseCommit = SignedLooseCommit;

/**
 * Wasm bindings for [`Subduction`](subduction_core::Subduction)
 */
class Subduction {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SubductionFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_subduction_free(ptr, 0);
    }
    /**
     * Accept a connection from a peer over any [`Transport`](JsTransport).
     *
     * Performs the responder side of the handshake, then adds the authenticated
     * connection. This is the counterpart to [`connectTransport`](Self::connect_transport).
     *
     * # Arguments
     *
     * * `transport` - Any JS object with `sendBytes`/`recvBytes`/`disconnect`
     * * `service_name` - Shared service name for discovery
     *
     * # Errors
     *
     * Returns an error if the handshake or connection fails.
     * @param {Transport} transport
     * @param {string} service_name
     * @returns {Promise<PeerId>}
     */
    acceptTransport(transport, service_name) {
        const ptr0 = passStringToWasm0(service_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_acceptTransport(this.__wbg_ptr, transport, ptr0, len0);
        return ret;
    }
    /**
     * Bulk-insert commits and fragments into a sedimentree, then broadcast
     * (the `add_*` combinator = [`storeBuiltBatch`](Self::store_built_batch) +
     * [`syncWithAllPeers`](Self::sync_with_all_peers)).
     *
     * Unlike [`addCommit`](Self::add_commit) and
     * [`addFragment`](Self::add_fragment) — which each re-minimize the tree
     * and push to peers per call — this method inserts everything first,
     * runs `minimize_tree` once at the end, and then performs a single
     * `sync_with_all_peers` to propagate the new state. For workloads that
     * add many commits or fragments at once this avoids `O(N²)` minimize work
     * and `N` redundant broadcasts.
     *
     * Returns the per-peer broadcast outcome as a
     * [`PeerResultMap`](WasmPeerResultMap). This **awaits the broadcast**, so
     * an unresponsive peer can stall the call for up to `timeout_milliseconds`
     * (or the configured default when omitted); callers wanting a
     * non-blocking durable write should use
     * [`storeBuiltBatch`](Self::store_built_batch) instead.
     *
     * Either list may be empty; passing two empty lists is a no-op (no
     * minimize, no broadcast) and yields an empty map.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if any blob does not match its claimed
     * [`BlobMeta`](sedimentree_core::blob::BlobMeta), or if a local
     * [`Storage`](sedimentree_wasm::storage::JsStorage) error is hit while
     * persisting the batch or while ingesting inbound data during the
     * trailing broadcast. Per-peer transport failures are reported inside the
     * returned map, not as an error.
     * @param {SedimentreeId} id
     * @param {CommitInput[]} commits
     * @param {FragmentInput[]} fragments
     * @param {number | null} [timeout_milliseconds]
     * @returns {Promise<PeerResultMap>}
     */
    addBatch(id, commits, fragments, timeout_milliseconds) {
        _assertClass(id, SedimentreeId);
        const ptr0 = passArrayJsValueToWasm0(commits, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayJsValueToWasm0(fragments, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_addBatch(this.__wbg_ptr, id.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(timeout_milliseconds) ? Number.MAX_SAFE_INTEGER : (timeout_milliseconds) >>> 0);
        return ret;
    }
    /**
     * Add a commit with its associated blob to the storage, then push it to
     * authorized subscribers (the `add_*` combinator =
     * [`storeCommit`](Self::store_commit) + best-effort push).
     *
     * The commit metadata (including `BlobMeta`) is computed internally from
     * the provided blob, ensuring consistency by construction.
     *
     * Propagation is a best-effort `send` to subscribers; it does not block
     * on peer acks (no per-peer result is produced for single-item pushes).
     * For a durable write with no propagation, use
     * [`storeCommit`](Self::store_commit).
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if storage, networking, or policy fail.
     * @param {SedimentreeId} id
     * @param {CommitId} head
     * @param {CommitId[]} parents
     * @param {Uint8Array} blob
     * @returns {Promise<FragmentRequested | undefined>}
     */
    addCommit(id, head, parents, blob) {
        _assertClass(id, SedimentreeId);
        _assertClass(head, CommitId);
        const ptr0 = passArrayJsValueToWasm0(parents, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_addCommit(this.__wbg_ptr, id.__wbg_ptr, head.__wbg_ptr, ptr0, len0, blob);
        return ret;
    }
    /**
     * Bulk-insert commits into a sedimentree, then broadcast (the `add_*`
     * combinator = [`storeCommitsBatch`](Self::store_commits_batch) +
     * [`syncWithAllPeers`](Self::sync_with_all_peers)).
     *
     * Like [`addBatch`](Self::add_batch) for the commits half only. Returns
     * the per-peer broadcast outcome as a
     * [`PeerResultMap`](WasmPeerResultMap) and **awaits the broadcast** (an
     * unresponsive peer can stall the call for up to `timeout_milliseconds`).
     * An empty list is a no-op and yields an empty map.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if any blob does not match its claimed
     * [`BlobMeta`](sedimentree_core::blob::BlobMeta), or if storage fails.
     * Per-peer transport failures are reported inside the returned map.
     * @param {SedimentreeId} id
     * @param {CommitInput[]} commits
     * @param {number | null} [timeout_milliseconds]
     * @returns {Promise<PeerResultMap>}
     */
    addCommitsBatch(id, commits, timeout_milliseconds) {
        _assertClass(id, SedimentreeId);
        const ptr0 = passArrayJsValueToWasm0(commits, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_addCommitsBatch(this.__wbg_ptr, id.__wbg_ptr, ptr0, len0, isLikeNone(timeout_milliseconds) ? Number.MAX_SAFE_INTEGER : (timeout_milliseconds) >>> 0);
        return ret;
    }
    /**
     * Onboard an authenticated transport: add it and sync all sedimentrees.
     *
     * Accepts an [`AuthenticatedTransport`](WasmAuthenticatedTransport),
     * obtained via [`AuthenticatedTransport.setup`](WasmAuthenticatedTransport::setup),
     * [`AuthenticatedWebSocket.toTransport`], or [`AuthenticatedLongPoll.toTransport`].
     *
     * Returns `true` if this is a new peer, `false` if already connected.
     *
     * Add an authenticated transport to tracking.
     *
     * This does not perform any synchronization. To sync after adding,
     * call [`fullSyncWithPeer`](Self::full_sync_with_peer).
     *
     * Returns `true` if this is a new peer, `false` if already connected.
     *
     * # Errors
     *
     * Returns an error if the connection is rejected by the policy.
     * @param {AuthenticatedTransport} transport
     * @returns {Promise<boolean>}
     */
    addConnection(transport) {
        _assertClass(transport, AuthenticatedTransport);
        const ret = wasm.subduction_addConnection(this.__wbg_ptr, transport.__wbg_ptr);
        return ret;
    }
    /**
     * Add a fragment with its associated blob to the storage, then push it to
     * authorized subscribers (the `add_*` combinator =
     * [`storeFragment`](Self::store_fragment) + best-effort push).
     *
     * The fragment metadata (including `BlobMeta`) is computed internally from
     * the provided blob, ensuring consistency by construction.
     *
     * Propagation is a best-effort `send` to subscribers; it does not block
     * on peer acks. For a durable write with no propagation, use
     * [`storeFragment`](Self::store_fragment).
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if storage, networking, or policy fail.
     * @param {SedimentreeId} id
     * @param {CommitId} head
     * @param {CommitId[]} boundary
     * @param {CommitId[]} checkpoints
     * @param {Uint8Array} blob
     * @returns {Promise<void>}
     */
    addFragment(id, head, boundary, checkpoints, blob) {
        _assertClass(id, SedimentreeId);
        _assertClass(head, CommitId);
        const ptr0 = passArrayJsValueToWasm0(boundary, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayJsValueToWasm0(checkpoints, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_addFragment(this.__wbg_ptr, id.__wbg_ptr, head.__wbg_ptr, ptr0, len0, ptr1, len1, blob);
        return ret;
    }
    /**
     * Bulk-insert fragments into a sedimentree, then broadcast (the `add_*`
     * combinator = [`storeFragmentsBatch`](Self::store_fragments_batch) +
     * [`syncWithAllPeers`](Self::sync_with_all_peers)).
     *
     * Like [`addBatch`](Self::add_batch) for the fragments half only. Returns
     * the per-peer broadcast outcome as a
     * [`PeerResultMap`](WasmPeerResultMap) and **awaits the broadcast** (an
     * unresponsive peer can stall the call for up to `timeout_milliseconds`).
     * An empty list is a no-op and yields an empty map.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if any blob does not match its claimed
     * [`BlobMeta`](sedimentree_core::blob::BlobMeta), or if storage fails.
     * Per-peer transport failures are reported inside the returned map.
     * @param {SedimentreeId} id
     * @param {FragmentInput[]} fragments
     * @param {number | null} [timeout_milliseconds]
     * @returns {Promise<PeerResultMap>}
     */
    addFragmentsBatch(id, fragments, timeout_milliseconds) {
        _assertClass(id, SedimentreeId);
        const ptr0 = passArrayJsValueToWasm0(fragments, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_addFragmentsBatch(this.__wbg_ptr, id.__wbg_ptr, ptr0, len0, isLikeNone(timeout_milliseconds) ? Number.MAX_SAFE_INTEGER : (timeout_milliseconds) >>> 0);
        return ret;
    }
    /**
     * Persist a whole [`Sedimentree`](sedimentree_wasm::WasmSedimentree)
     * **and** broadcast it to all connected peers (the `add_*` combinator =
     * [`storeSedimentree`](Self::store_sedimentree) +
     * [`syncWithAllPeers`](Self::sync_with_all_peers)).
     *
     * Returns the per-peer broadcast outcome as a
     * [`PeerResultMap`](WasmPeerResultMap). This **awaits the broadcast**, so
     * an unresponsive peer can stall the call for up to `timeout_milliseconds`
     * (or the configured default when omitted); callers wanting a
     * non-blocking durable write should use
     * [`storeSedimentree`](Self::store_sedimentree) instead.
     *
     * # Errors
     *
     * Returns [`WasmWriteError`] if a referenced blob is missing, or on
     * storage I/O — including storage errors hit while ingesting inbound data
     * during the trailing sync. The local store uses the trusting local
     * putter (no network policy check). Per-peer transport failures during
     * the broadcast are reported inside the returned map, not as an error.
     * @param {SedimentreeId} id
     * @param {Sedimentree} sedimentree
     * @param {Uint8Array[]} blobs
     * @param {number | null} [timeout_milliseconds]
     * @returns {Promise<PeerResultMap>}
     */
    addSedimentree(id, sedimentree, blobs, timeout_milliseconds) {
        _assertClass(id, SedimentreeId);
        _assertClass(sedimentree, Sedimentree);
        const ptr0 = passArrayJsValueToWasm0(blobs, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_addSedimentree(this.__wbg_ptr, id.__wbg_ptr, sedimentree.__wbg_ptr, ptr0, len0, isLikeNone(timeout_milliseconds) ? Number.MAX_SAFE_INTEGER : (timeout_milliseconds) >>> 0);
        return ret;
    }
    /**
     * Compute the [`WasmDepth`] of a commit identifier under this node's
     * configured hash metric.
     *
     * Combine with [`WasmDepth::isBoundary`] to decide whether a commit is an
     * eligible fragment head — for example after [`addBatch`](Self::add_batch),
     * where the per-call `FragmentRequested` signal returned by
     * [`addCommit`](Self::add_commit) is unavailable.
     * @param {CommitId} commit_id
     * @returns {Depth}
     */
    commitDepth(commit_id) {
        _assertClass(commit_id, CommitId);
        const ret = wasm.subduction_commitDepth(this.__wbg_ptr, commit_id.__wbg_ptr);
        return Depth.__wrap(ret);
    }
    /**
     * Connect to a peer via WebSocket and add the connection.
     *
     * This performs the cryptographic handshake, verifies the server's identity,
     * and adds the authenticated connection for syncing.
     *
     * Returns the verified peer ID on success.
     *
     * # Arguments
     *
     * * `address` - The WebSocket URL to connect to
     * * `expected_peer_id` - The expected server peer ID (verified during handshake)
     *
     * # Errors
     *
     * Returns an error if connection, handshake, or adding the connection fails.
     * @param {URL} address
     * @param {PeerId} expected_peer_id
     * @returns {Promise<PeerId>}
     */
    connect(address, expected_peer_id) {
        _assertClass(expected_peer_id, PeerId);
        const ret = wasm.subduction_connect(this.__wbg_ptr, address, expected_peer_id.__wbg_ptr);
        return ret;
    }
    /**
     * Connect to a peer via WebSocket using discovery mode and add the connection.
     *
     * Returns the discovered and verified peer ID on success.
     *
     * # Arguments
     *
     * * `address` - The WebSocket URL to connect to
     * * `service_name` - The service name for discovery (defaults to URL host)
     *
     * # Errors
     *
     * Returns an error if connection, handshake, or adding the connection fails.
     * @param {URL} address
     * @param {string | null} [service_name]
     * @returns {Promise<PeerId>}
     */
    connectDiscover(address, service_name) {
        var ptr0 = isLikeNone(service_name) ? 0 : passStringToWasm0(service_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_connectDiscover(this.__wbg_ptr, address, ptr0, len0);
        return ret;
    }
    /**
     * Connect to a peer via HTTP long-poll using discovery mode.
     *
     * Returns the discovered and verified peer ID on success.
     *
     * # Arguments
     *
     * * `base_url` - The server's HTTP base URL (e.g., `http://localhost:8080`)
     * * `service_name` - The service name for discovery (defaults to `base_url`)
     *
     * # Errors
     *
     * Returns an error if connection, handshake, or adding the connection fails.
     * @param {string} base_url
     * @param {string | null} [service_name]
     * @returns {Promise<PeerId>}
     */
    connectDiscoverLongPoll(base_url, service_name) {
        const ptr0 = passStringToWasm0(base_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(service_name) ? 0 : passStringToWasm0(service_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_connectDiscoverLongPoll(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        return ret;
    }
    /**
     * Connect to a peer via HTTP long-poll and add the connection.
     *
     * Returns the verified peer ID on success.
     *
     * # Arguments
     *
     * * `base_url` - The server's HTTP base URL (e.g., `http://localhost:8080`)
     * * `expected_peer_id` - The expected server peer ID (verified during handshake)
     *
     * # Errors
     *
     * Returns an error if connection, handshake, or adding the connection fails.
     * @param {string} base_url
     * @param {PeerId} expected_peer_id
     * @returns {Promise<PeerId>}
     */
    connectLongPoll(base_url, expected_peer_id) {
        const ptr0 = passStringToWasm0(base_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        _assertClass(expected_peer_id, PeerId);
        const ret = wasm.subduction_connectLongPoll(this.__wbg_ptr, ptr0, len0, expected_peer_id.__wbg_ptr);
        return ret;
    }
    /**
     * Connect to a peer over any [`Transport`](JsTransport) using discovery mode.
     *
     * Performs a discovery handshake, then adds the authenticated connection.
     * The peer's identity is discovered during the handshake.
     *
     * # Arguments
     *
     * * `transport` - Any JS object with `sendBytes`/`recvBytes`/`disconnect`
     * * `service_name` - Shared service name for discovery
     *
     * # Errors
     *
     * Returns an error if the handshake or connection fails.
     * @param {Transport} transport
     * @param {string} service_name
     * @returns {Promise<PeerId>}
     */
    connectTransport(transport, service_name) {
        const ptr0 = passStringToWasm0(service_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_connectTransport(this.__wbg_ptr, transport, ptr0, len0);
        return ret;
    }
    /**
     * Disconnect from all peers.
     *
     * # Errors
     *
     * Returns a [`WasmDisconnectionError`] if disconnection was not graceful.
     * @returns {Promise<void>}
     */
    disconnectAll() {
        const ret = wasm.subduction_disconnectAll(this.__wbg_ptr);
        return ret;
    }
    /**
     * Disconnect from a peer by its ID.
     *
     * # Errors
     *
     * Returns a `WasmDisconnectionError` if disconnection fails.
     * @param {PeerId} peer_id
     * @returns {Promise<boolean>}
     */
    disconnectFromPeer(peer_id) {
        _assertClass(peer_id, PeerId);
        const ret = wasm.subduction_disconnectFromPeer(this.__wbg_ptr, peer_id.__wbg_ptr);
        return ret;
    }
    /**
     * Fetch blobs by their digests, with an optional timeout in milliseconds.
     *
     * # Errors
     *
     * Returns a [`WasmIoError`] if storage or networking fail.
     * @param {SedimentreeId} id
     * @param {number | null} [timeout_milliseconds]
     * @returns {Promise<Uint8Array[] | undefined>}
     */
    fetchBlobs(id, timeout_milliseconds) {
        _assertClass(id, SedimentreeId);
        const ret = wasm.subduction_fetchBlobs(this.__wbg_ptr, id.__wbg_ptr, isLikeNone(timeout_milliseconds) ? Number.MAX_SAFE_INTEGER : (timeout_milliseconds) >>> 0);
        return ret;
    }
    /**
     * Sync all known Sedimentree IDs with all connected peers.
     * @param {number | null} [timeout_milliseconds]
     * @returns {Promise<PeerBatchSyncResult>}
     */
    fullSyncWithAllPeers(timeout_milliseconds) {
        const ret = wasm.subduction_fullSyncWithAllPeers(this.__wbg_ptr, isLikeNone(timeout_milliseconds) ? Number.MAX_SAFE_INTEGER : (timeout_milliseconds) >>> 0);
        return ret;
    }
    /**
     * Sync all known Sedimentree IDs with a single peer.
     *
     * # Arguments
     *
     * * `peer_id` - The peer to sync with
     * * `subscribe` - Whether to subscribe to future updates (default: `true`)
     * * `timeout_milliseconds` - Optional per-call total deadline in milliseconds; omit to use the configured default
     * @param {PeerId} peer_id
     * @param {boolean | null} [subscribe]
     * @param {number | null} [timeout_milliseconds]
     * @returns {Promise<PeerBatchSyncResult>}
     */
    fullSyncWithPeer(peer_id, subscribe, timeout_milliseconds) {
        _assertClass(peer_id, PeerId);
        const ret = wasm.subduction_fullSyncWithPeer(this.__wbg_ptr, peer_id.__wbg_ptr, isLikeNone(subscribe) ? 0xFFFFFF : subscribe ? 1 : 0, isLikeNone(timeout_milliseconds) ? Number.MAX_SAFE_INTEGER : (timeout_milliseconds) >>> 0);
        return ret;
    }
    /**
     * Get the current heads for every locally known sedimentree.
     *
     * An inner empty heads array means the sedimentree exists but has no
     * heads yet.
     * @returns {Promise<SedimentreeHeads[]>}
     */
    getAllHeads() {
        const ret = wasm.subduction_getAllHeads(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get a local blob by its digest.
     *
     * # Errors
     *
     * Returns a [`JsStorageError`] if JS storage fails.
     * @param {SedimentreeId} id
     * @param {Digest} digest
     * @returns {Promise<Uint8Array | undefined>}
     */
    getBlob(id, digest) {
        _assertClass(id, SedimentreeId);
        _assertClass(digest, Digest);
        const ret = wasm.subduction_getBlob(this.__wbg_ptr, id.__wbg_ptr, digest.__wbg_ptr);
        return ret;
    }
    /**
     * Get all local blobs for a given Sedimentree ID.
     *
     * # Errors
     *
     * Returns a [`JsStorageError`] if JS storage fails.
     * @param {SedimentreeId} id
     * @returns {Promise<Uint8Array[]>}
     */
    getBlobs(id) {
        _assertClass(id, SedimentreeId);
        const ret = wasm.subduction_getBlobs(this.__wbg_ptr, id.__wbg_ptr);
        return ret;
    }
    /**
     * Get all commits for a given Sedimentree ID
     * @param {SedimentreeId} id
     * @returns {Promise<LooseCommit[] | undefined>}
     */
    getCommits(id) {
        _assertClass(id, SedimentreeId);
        const ret = wasm.subduction_getCommits(this.__wbg_ptr, id.__wbg_ptr);
        return ret;
    }
    /**
     * Get the peer IDs of all connected peers.
     * @returns {Promise<PeerId[]>}
     */
    getConnectedPeerIds() {
        const ret = wasm.subduction_getConnectedPeerIds(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get all fragments for a given Sedimentree ID
     * @param {SedimentreeId} id
     * @returns {Promise<Fragment[] | undefined>}
     */
    getFragments(id) {
        _assertClass(id, SedimentreeId);
        const ret = wasm.subduction_getFragments(this.__wbg_ptr, id.__wbg_ptr);
        return ret;
    }
    /**
     * Link two local [`Subduction`](WasmSubduction) instances over a
     * [`MessageChannel`](web_sys::MessageChannel).
     *
     * Creates a `MessageChannel`, performs a discovery handshake between
     * the two instances, and adds the connections to both. This is the
     * simplest way to sync two local instances.
     *
     * # Errors
     *
     * Returns an error if the handshake or connection fails.
     * @param {Subduction} a
     * @param {Subduction} b
     * @returns {Promise<void>}
     */
    static link(a, b) {
        _assertClass(a, Subduction);
        _assertClass(b, Subduction);
        const ret = wasm.subduction_link(a.__wbg_ptr, b.__wbg_ptr);
        return ret;
    }
    /**
     * Create a new [`Subduction`] instance from an options object.
     *
     * ```js
     * new Subduction({ signer, storage, serviceName: "sync.example.com" });
     * ```
     *
     * `signer` and `storage` are required; all other fields are optional.
     * See [`SubductionOptions`] for the full field list and defaults.
     *
     * # Errors
     *
     * Returns a [`WasmInitError`] if the required `signer` or `storage` field
     * is missing (`undefined`/`null`). The TypeScript interface marks these as
     * required, so this only fires for callers that bypass the type checker.
     *
     * # Panics
     *
     * Panics if `hashMetricOverride` is provided but the underlying JS value
     * cannot be cast to a `Function`.
     * @param {SubductionOptions} opts
     */
    constructor(opts) {
        const ret = wasm.subduction_new(opts);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        SubductionFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Publish an ephemeral message to all subscribers of a topic.
     *
     * The payload is opaque bytes — encoding is the caller's responsibility.
     * Messages are fire-and-forget; delivery is best-effort.
     *
     * # Panics
     *
     * Panics if the platform's random number generator fails.
     * @param {Topic} topic
     * @param {Uint8Array} payload
     * @returns {Promise<void>}
     */
    publishEphemeral(topic, payload) {
        _assertClass(topic, Topic);
        const ptr0 = passArray8ToWasm0(payload, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_publishEphemeral(this.__wbg_ptr, topic.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Register a handler for keyhive protocol frames.
     *
     * When a frame arrives with the `SUK\0` schema header, the CBOR
     * payload (without the SUK envelope) and the sender's peer ID are
     * forwarded to the handler's `onMessage` method. When a peer
     * disconnects, `onPeerDisconnect` is called.
     *
     * Only one handler can be registered at a time. Calling this again
     * replaces the previous handler. Pass `null`/`undefined` to unregister.
     * @param {FrameHandler | null} [handler]
     * @returns {Promise<void>}
     */
    registerFrameHandler(handler) {
        const ret = wasm.subduction_registerFrameHandler(this.__wbg_ptr, isLikeNone(handler) ? 0 : addToExternrefTable0(handler));
        return ret;
    }
    /**
     * Remove a Sedimentree and all associated data.
     *
     * # Errors
     *
     * Returns a [`WasmIoError`] if storage or networking fail.
     * @param {SedimentreeId} id
     * @returns {Promise<void>}
     */
    removeSedimentree(id) {
        _assertClass(id, SedimentreeId);
        const ret = wasm.subduction_removeSedimentree(this.__wbg_ptr, id.__wbg_ptr);
        return ret;
    }
    /**
     * Get all known Sedimentree IDs
     * @returns {Promise<SedimentreeId[]>}
     */
    sedimentreeIds() {
        const ret = wasm.subduction_sedimentreeIds(this.__wbg_ptr);
        return ret;
    }
    /**
     * Send a keyhive frame to a specific peer.
     *
     * `payload` is the CBOR-encoded content (e.g., a `SignedMessage`).
     * Subduction wraps it in the `SUK\0` envelope before sending.
     *
     * # Errors
     *
     * Returns an error if the peer has no active connection or if sending fails.
     * @param {Uint8Array} payload
     * @param {PeerId} peer_id
     * @returns {Promise<void>}
     */
    sendKeyhiveMessage(payload, peer_id) {
        const ptr0 = passArray8ToWasm0(payload, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        _assertClass(peer_id, PeerId);
        const ret = wasm.subduction_sendKeyhiveMessage(this.__wbg_ptr, ptr0, len0, peer_id.__wbg_ptr);
        return ret;
    }
    /**
     * Get the backing storage.
     * @returns {any}
     */
    get storage() {
        const ret = wasm.subduction_storage(this.__wbg_ptr);
        return ret;
    }
    /**
     * Bulk-insert commits and fragments into a sedimentree **without**
     * broadcasting (the `store_*` tier).
     *
     * Inserts everything first and runs `minimize_tree` once at the end —
     * avoiding the `O(N²)` minimize work of looping
     * [`storeCommit`](Self::store_commit) — but performs **no** network
     * propagation. Useful for ingestion paths (local replay, hydration from
     * another store) where the caller drives sync separately or not at all.
     *
     * Each [`WasmCommitInput`] bundles an unsigned
     * [`LooseCommit`](sedimentree_core::loose_commit::LooseCommit) with its
     * blob; each [`WasmFragmentInput`] bundles an unsigned
     * [`Fragment`](sedimentree_core::fragment::Fragment) with its blob.
     * Either list may be empty; two empty lists is a no-op.
     *
     * Use [`addBatch`](Self::add_batch) for the store-and-broadcast
     * combinator.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if any blob does not match its claimed
     * [`BlobMeta`](sedimentree_core::blob::BlobMeta), or if storage fails.
     * @param {SedimentreeId} id
     * @param {CommitInput[]} commits
     * @param {FragmentInput[]} fragments
     * @returns {Promise<void>}
     */
    storeBuiltBatch(id, commits, fragments) {
        _assertClass(id, SedimentreeId);
        const ptr0 = passArrayJsValueToWasm0(commits, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayJsValueToWasm0(fragments, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_storeBuiltBatch(this.__wbg_ptr, id.__wbg_ptr, ptr0, len0, ptr1, len1);
        return ret;
    }
    /**
     * Persist a single commit with its blob locally **without** broadcasting
     * (the `store_*` tier).
     *
     * The commit metadata (including `BlobMeta`) is computed internally from
     * the provided blob, ensuring consistency by construction.
     *
     * Durability only: never waits on a peer. Use
     * [`addCommit`](Self::add_commit) for the store-and-push combinator.
     *
     * Returns the [`WasmFragmentRequested`] signal when the commit lands on a
     * fragment boundary, exactly as [`addCommit`](Self::add_commit) does.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] on storage I/O failure. This local-only
     * path uses the trusting local putter, so no network policy is consulted.
     * @param {SedimentreeId} id
     * @param {CommitId} head
     * @param {CommitId[]} parents
     * @param {Uint8Array} blob
     * @returns {Promise<FragmentRequested | undefined>}
     */
    storeCommit(id, head, parents, blob) {
        _assertClass(id, SedimentreeId);
        _assertClass(head, CommitId);
        const ptr0 = passArrayJsValueToWasm0(parents, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_storeCommit(this.__wbg_ptr, id.__wbg_ptr, head.__wbg_ptr, ptr0, len0, blob);
        return ret;
    }
    /**
     * Bulk-insert commits into a sedimentree **without** broadcasting (the
     * `store_*` tier).
     *
     * Like [`storeBuiltBatch`](Self::store_built_batch) for the commits half
     * only. Each [`WasmCommitInput`] bundles an unsigned commit with its
     * blob; an empty list is a no-op.
     *
     * Use [`addCommitsBatch`](Self::add_commits_batch) for the
     * store-and-broadcast combinator.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if any blob does not match its claimed
     * [`BlobMeta`](sedimentree_core::blob::BlobMeta), or if storage fails.
     * @param {SedimentreeId} id
     * @param {CommitInput[]} commits
     * @returns {Promise<void>}
     */
    storeCommitsBatch(id, commits) {
        _assertClass(id, SedimentreeId);
        const ptr0 = passArrayJsValueToWasm0(commits, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_storeCommitsBatch(this.__wbg_ptr, id.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Persist a single fragment with its blob locally **without**
     * broadcasting (the `store_*` tier).
     *
     * The fragment metadata (including `BlobMeta`) is computed internally from
     * the provided blob, ensuring consistency by construction.
     *
     * Durability only: never waits on a peer. Use
     * [`addFragment`](Self::add_fragment) for the store-and-push combinator.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] on storage I/O failure. This local-only
     * path uses the trusting local putter, so no network policy is consulted.
     * @param {SedimentreeId} id
     * @param {CommitId} head
     * @param {CommitId[]} boundary
     * @param {CommitId[]} checkpoints
     * @param {Uint8Array} blob
     * @returns {Promise<void>}
     */
    storeFragment(id, head, boundary, checkpoints, blob) {
        _assertClass(id, SedimentreeId);
        _assertClass(head, CommitId);
        const ptr0 = passArrayJsValueToWasm0(boundary, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayJsValueToWasm0(checkpoints, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_storeFragment(this.__wbg_ptr, id.__wbg_ptr, head.__wbg_ptr, ptr0, len0, ptr1, len1, blob);
        return ret;
    }
    /**
     * Bulk-insert fragments into a sedimentree **without** broadcasting (the
     * `store_*` tier).
     *
     * Like [`storeBuiltBatch`](Self::store_built_batch) for the fragments
     * half only. Each [`WasmFragmentInput`] bundles an unsigned fragment with
     * its blob; an empty list is a no-op.
     *
     * Use [`addFragmentsBatch`](Self::add_fragments_batch) for the
     * store-and-broadcast combinator.
     *
     * # Errors
     *
     * Returns a [`WasmWriteError`] if any blob does not match its claimed
     * [`BlobMeta`](sedimentree_core::blob::BlobMeta), or if storage fails.
     * @param {SedimentreeId} id
     * @param {FragmentInput[]} fragments
     * @returns {Promise<void>}
     */
    storeFragmentsBatch(id, fragments) {
        _assertClass(id, SedimentreeId);
        const ptr0 = passArrayJsValueToWasm0(fragments, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_storeFragmentsBatch(this.__wbg_ptr, id.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Persist a whole [`Sedimentree`](sedimentree_wasm::WasmSedimentree)
     * locally **without** broadcasting (the `store_*` tier).
     *
     * Durability only: never waits on a peer. Drive
     * [`syncWithAllPeers`](Self::sync_with_all_peers) yourself to propagate.
     * Use [`addSedimentree`](Self::add_sedimentree) for the
     * store-and-broadcast combinator.
     *
     * # Errors
     *
     * Returns [`WasmWriteError`] if a referenced blob is missing or storage
     * I/O fails. This local-only path uses the trusting local putter, so no
     * network policy is consulted.
     * @param {SedimentreeId} id
     * @param {Sedimentree} sedimentree
     * @param {Uint8Array[]} blobs
     * @returns {Promise<void>}
     */
    storeSedimentree(id, sedimentree, blobs) {
        _assertClass(id, SedimentreeId);
        _assertClass(sedimentree, Sedimentree);
        const ptr0 = passArrayJsValueToWasm0(blobs, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_storeSedimentree(this.__wbg_ptr, id.__wbg_ptr, sedimentree.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Subscribe to ephemeral messages for the given topics
     * from all connected peers.
     * @param {Topic[]} topics
     * @returns {Promise<void>}
     */
    subscribeEphemeral(topics) {
        const ptr0 = passArrayJsValueToWasm0(topics, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_subscribeEphemeral(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Request batch sync for a given Sedimentree ID from all connected peers.
     *
     * # Arguments
     *
     * * `id` - The sedimentree ID to sync
     * * `subscribe` - Whether to subscribe for incremental updates
     * * `timeout_milliseconds` - Optional per-call total deadline in milliseconds; omit to use the configured default
     *
     * # Errors
     *
     * Returns a [`WasmIoError`] if storage or networking fail.
     * @param {SedimentreeId} id
     * @param {boolean} subscribe
     * @param {number | null} [timeout_milliseconds]
     * @returns {Promise<PeerResultMap>}
     */
    syncWithAllPeers(id, subscribe, timeout_milliseconds) {
        _assertClass(id, SedimentreeId);
        const ret = wasm.subduction_syncWithAllPeers(this.__wbg_ptr, id.__wbg_ptr, subscribe, isLikeNone(timeout_milliseconds) ? Number.MAX_SAFE_INTEGER : (timeout_milliseconds) >>> 0);
        return ret;
    }
    /**
     * Request batch sync for a given Sedimentree ID from a specific peer.
     *
     * # Arguments
     *
     * * `to_ask` - The peer ID to sync with
     * * `id` - The sedimentree ID to sync
     * * `subscribe` - Whether to subscribe for incremental updates
     * * `timeout_milliseconds` - Optional per-call total deadline in milliseconds; omit to use the configured default
     *
     * # Cancellation
     *
     * The call is bounded by `timeout_milliseconds` (or the configured
     * default). **Abandoning the returned `Promise` — e.g. via
     * `Promise.race([syncWithPeer(...), timeout(5000)])` — does NOT cancel
     * the underlying sync:** the work runs on the Wasm executor, not the
     * `Promise`, so it continues until the deadline elapses, the response
     * arrives, or the peer disconnects. To stop it early, set a shorter
     * `timeout_milliseconds` or disconnect the peer
     * ([`disconnect_from_peer`](Self::disconnect_from_peer) /
     * [`disconnect_all`](Self::disconnect_all)).
     *
     * # Errors
     *
     * Returns a [`WasmIoError`] if storage or networking fail.
     * @param {PeerId} to_ask
     * @param {SedimentreeId} id
     * @param {boolean} subscribe
     * @param {number | null} [timeout_milliseconds]
     * @returns {Promise<PeerBatchSyncResult>}
     */
    syncWithPeer(to_ask, id, subscribe, timeout_milliseconds) {
        _assertClass(to_ask, PeerId);
        _assertClass(id, SedimentreeId);
        const ret = wasm.subduction_syncWithPeer(this.__wbg_ptr, to_ask.__wbg_ptr, id.__wbg_ptr, subscribe, isLikeNone(timeout_milliseconds) ? Number.MAX_SAFE_INTEGER : (timeout_milliseconds) >>> 0);
        return ret;
    }
    /**
     * Unsubscribe from ephemeral messages for the given topics
     * from all connected peers.
     * @param {Topic[]} topics
     * @returns {Promise<void>}
     */
    unsubscribeEphemeral(topics) {
        const ptr0 = passArrayJsValueToWasm0(topics, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.subduction_unsubscribeEphemeral(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
}
if (Symbol.dispose) Subduction.prototype[Symbol.dispose] = Subduction.prototype.free;
exports.Subduction = Subduction;

/**
 * JS-facing wrapper around [`HttpLongPollTransport`] that exposes the
 * byte-oriented [`Transport`](super::JsTransport) interface
 * (`sendBytes`/`recvBytes`/`disconnect`/`onDisconnect`) so it can be used as a
 * duck-typed `JsTransport` from JavaScript.
 */
class SubductionHttpLongPoll {
    static __wrap(ptr) {
        const obj = Object.create(SubductionHttpLongPoll.prototype);
        obj.__wbg_ptr = ptr;
        SubductionHttpLongPollFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SubductionHttpLongPollFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_subductionhttplongpoll_free(ptr, 0);
    }
    /**
     * Disconnect from the peer gracefully.
     *
     * Fires the `onDisconnect` callback if one is registered.
     *
     * # Errors
     *
     * Returns an error if the disconnect fails.
     * @returns {Promise<void>}
     */
    disconnect() {
        const ret = wasm.subductionhttplongpoll_disconnect(this.__wbg_ptr);
        return ret;
    }
    /**
     * Register a callback to be invoked when the transport disconnects.
     *
     * Part of the [`Transport`](super::JsTransport) interface contract.
     * Typically called by internal wiring rather than directly by user code.
     * @param {Function} callback
     */
    onDisconnect(callback) {
        wasm.subductionhttplongpoll_onDisconnect(this.__wbg_ptr, callback);
    }
    /**
     * Receive the next message frame as raw bytes.
     *
     * # Errors
     *
     * Returns an error if the inbound channel is closed.
     * @returns {Promise<Uint8Array>}
     */
    recvBytes() {
        const ret = wasm.subductionhttplongpoll_recvBytes(this.__wbg_ptr);
        return ret;
    }
    /**
     * Send raw bytes over the transport.
     *
     * # Errors
     *
     * Returns an error if the outbound channel is closed.
     * @param {Uint8Array} bytes
     * @returns {Promise<void>}
     */
    sendBytes(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.subductionhttplongpoll_sendBytes(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
}
if (Symbol.dispose) SubductionHttpLongPoll.prototype[Symbol.dispose] = SubductionHttpLongPoll.prototype.free;
exports.SubductionHttpLongPoll = SubductionHttpLongPoll;

/**
 * HTTP long-poll transport factory for browser/worker environments.
 *
 * Analogous to [`SubductionWebSocket`] but uses HTTP long-poll instead of WebSocket.
 */
class SubductionLongPoll {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SubductionLongPollFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_subductionlongpoll_free(ptr, 0);
    }
    /**
     * Connect to a server with a known peer ID.
     *
     * # Arguments
     *
     * * `base_url` - The server's HTTP base URL (e.g., `http://localhost:8080`)
     * * `signer` - The client's signer for authentication
     * * `expected_peer_id` - The expected server peer ID (verified during handshake)
     * * `on_disconnect` - Optional callback invoked with the peer's [`PeerId`] when the connection closes
     *
     * # Errors
     *
     * Returns [`LongPollTransportError`] if connection or handshake fails.
     * @param {string} base_url
     * @param {Signer} signer
     * @param {PeerId} expected_peer_id
     * @param {Function | null} [on_disconnect]
     * @returns {Promise<AuthenticatedLongPoll>}
     */
    static tryConnect(base_url, signer, expected_peer_id, on_disconnect) {
        const ptr0 = passStringToWasm0(base_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        _assertClass(expected_peer_id, PeerId);
        const ret = wasm.subductionlongpoll_tryConnect(ptr0, len0, signer, expected_peer_id.__wbg_ptr, isLikeNone(on_disconnect) ? 0 : addToExternrefTable0(on_disconnect));
        return ret;
    }
    /**
     * Connect to a server using discovery mode.
     *
     * # Arguments
     *
     * * `base_url` - The server's HTTP base URL (e.g., `http://localhost:8080`)
     * * `signer` - The client's signer for authentication
     * * `service_name` - The service name for discovery. If omitted, the base URL is used.
     *
     * # Errors
     *
     * Returns [`LongPollTransportError`] if connection or handshake fails.
     * @param {string} base_url
     * @param {Signer} signer
     * @param {string | null} [service_name]
     * @param {Function | null} [on_disconnect]
     * @returns {Promise<AuthenticatedLongPoll>}
     */
    static tryDiscover(base_url, signer, service_name, on_disconnect) {
        const ptr0 = passStringToWasm0(base_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(service_name) ? 0 : passStringToWasm0(service_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.subductionlongpoll_tryDiscover(ptr0, len0, signer, ptr1, len1, isLikeNone(on_disconnect) ? 0 : addToExternrefTable0(on_disconnect));
        return ret;
    }
}
if (Symbol.dispose) SubductionLongPoll.prototype[Symbol.dispose] = SubductionLongPoll.prototype.free;
exports.SubductionLongPoll = SubductionLongPoll;

/**
 * A WebSocket transport exposing the byte-oriented `Transport` interface.
 *
 * Raw bytes from the WebSocket's `onmessage` handler are buffered in an
 * `async_channel` and returned via `recvBytes`. No message decoding or
 * request-response routing happens here — that's handled by
 * [`MessageTransport`](subduction_core::transport::message::MessageTransport).
 */
class SubductionWebSocket {
    static __wrap(ptr) {
        const obj = Object.create(SubductionWebSocket.prototype);
        obj.__wbg_ptr = ptr;
        SubductionWebSocketFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SubductionWebSocketFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_subductionwebsocket_free(ptr, 0);
    }
    /**
     * Disconnect from the peer gracefully.
     * @returns {Promise<void>}
     */
    disconnect() {
        const ret = wasm.subductionwebsocket_disconnect(this.__wbg_ptr);
        return ret;
    }
    /**
     * Register a callback to be invoked when the WebSocket closes.
     *
     * Part of the [`Transport`](super::JsTransport) interface contract.
     * Typically called by internal wiring (factory methods like `tryConnect`
     * and `tryDiscover`) rather than directly by user code.
     *
     * The callback is fired from the browser WebSocket's `onclose` handler.
     * @param {Function} callback
     */
    onDisconnect(callback) {
        wasm.subductionwebsocket_onDisconnect(this.__wbg_ptr, callback);
    }
    /**
     * Receive the next message frame as raw bytes.
     *
     * # Errors
     *
     * Returns [`ReadFromClosedChannel`] if the channel has been closed.
     * @returns {Promise<Uint8Array>}
     */
    recvBytes() {
        const ret = wasm.subductionwebsocket_recvBytes(this.__wbg_ptr);
        return ret;
    }
    /**
     * Send raw bytes over the WebSocket.
     *
     * # Errors
     *
     * Returns [`WasmSendError`] if the bytes could not be sent.
     * @param {Uint8Array} bytes
     * @returns {Promise<void>}
     */
    sendBytes(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.subductionwebsocket_sendBytes(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Authenticate an existing WebSocket via handshake.
     *
     * This performs the Subduction handshake protocol over the provided WebSocket
     * to establish mutual identity. The WebSocket can be in CONNECTING or OPEN state.
     *
     * # Arguments
     *
     * * `ws` - An existing WebSocket (CONNECTING or OPEN)
     * * `signer` - The client's signer for authentication
     * * `expected_peer_id` - The expected server peer ID (verified during handshake)
     * * `on_disconnect` - Optional callback invoked with the peer's [`PeerId`] when the connection closes
     *
     * # Errors
     *
     * Returns an error if the handshake fails (signature invalid, wrong peer, etc.)
     * @param {WebSocket} ws
     * @param {Signer} signer
     * @param {PeerId} expected_peer_id
     * @param {Function | null} [on_disconnect]
     * @returns {Promise<AuthenticatedWebSocket>}
     */
    static setup(ws, signer, expected_peer_id, on_disconnect) {
        _assertClass(expected_peer_id, PeerId);
        const ret = wasm.subductionwebsocket_setup(ws, signer, expected_peer_id.__wbg_ptr, isLikeNone(on_disconnect) ? 0 : addToExternrefTable0(on_disconnect));
        return ret;
    }
    /**
     * Connect to a WebSocket server with mutual authentication via handshake.
     *
     * # Arguments
     *
     * * `address` - The WebSocket URL to connect to
     * * `signer` - The client's signer for authentication
     * * `expected_peer_id` - The expected server peer ID (verified during handshake)
     * * `on_disconnect` - Optional callback invoked with the peer's [`PeerId`] when the connection closes
     *
     * # Errors
     *
     * Returns an error if:
     * - The WebSocket connection could not be established
     * - The handshake fails (signature invalid, wrong server, clock drift, etc.)
     * @param {URL} address
     * @param {Signer} signer
     * @param {PeerId} expected_peer_id
     * @param {Function | null} [on_disconnect]
     * @returns {Promise<AuthenticatedWebSocket>}
     */
    static tryConnect(address, signer, expected_peer_id, on_disconnect) {
        _assertClass(expected_peer_id, PeerId);
        const ret = wasm.subductionwebsocket_tryConnect(address, signer, expected_peer_id.__wbg_ptr, isLikeNone(on_disconnect) ? 0 : addToExternrefTable0(on_disconnect));
        return ret;
    }
    /**
     * Connect to a WebSocket server using discovery mode.
     *
     * This method performs a cryptographic handshake using a service name
     * instead of a known peer ID. The server's peer ID is discovered during
     * the handshake and returned.
     *
     * # Arguments
     *
     * * `address` - The WebSocket URL to connect to
     * * `signer` - The client's signer for authentication
     * * `service_name` - The service name for discovery (e.g., `localhost:8080`).
     *   If omitted, the host is extracted from the URL.
     * * `on_disconnect` - Optional callback invoked with the peer's [`PeerId`] when the connection closes
     *
     * # Errors
     *
     * Returns an error if:
     * - The WebSocket connection could not be established
     * - The handshake fails (signature invalid, clock drift, etc.)
     * @param {URL} address
     * @param {Signer} signer
     * @param {string | null} [service_name]
     * @param {Function | null} [on_disconnect]
     * @returns {Promise<AuthenticatedWebSocket>}
     */
    static tryDiscover(address, signer, service_name, on_disconnect) {
        var ptr0 = isLikeNone(service_name) ? 0 : passStringToWasm0(service_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.subductionwebsocket_tryDiscover(address, signer, ptr0, len0, isLikeNone(on_disconnect) ? 0 : addToExternrefTable0(on_disconnect));
        return ret;
    }
}
if (Symbol.dispose) SubductionWebSocket.prototype[Symbol.dispose] = SubductionWebSocket.prototype.free;
exports.SubductionWebSocket = SubductionWebSocket;

/**
 * Wasm wrapper for [`SyncMessage`].
 */
class SyncMessage {
    static __wrap(ptr) {
        const obj = Object.create(SyncMessage.prototype);
        obj.__wbg_ptr = ptr;
        SyncMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SyncMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_syncmessage_free(ptr, 0);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmMessage`].
     * @returns {SyncMessage}
     */
    __wasm_refgen_toWasmMessage() {
        const ret = wasm.syncmessage___wasm_refgen_toWasmMessage(this.__wbg_ptr);
        return SyncMessage.__wrap(ret);
    }
    /**
     * Create a [`SyncMessage::BatchSyncRequest`] message.
     * @param {BatchSyncRequest} request
     * @returns {SyncMessage}
     */
    static batchSyncRequest(request) {
        _assertClass(request, BatchSyncRequest);
        const ret = wasm.syncmessage_batchSyncRequest(request.__wbg_ptr);
        return SyncMessage.__wrap(ret);
    }
    /**
     * Create a [`SyncMessage::BatchSyncResponse`] message.
     * @param {BatchSyncResponse} response
     * @returns {SyncMessage}
     */
    static batchSyncResponse(response) {
        _assertClass(response, BatchSyncResponse);
        const ret = wasm.syncmessage_batchSyncResponse(response.__wbg_ptr);
        return SyncMessage.__wrap(ret);
    }
    /**
     * The `Blob` for commit or fragment messages, if applicable.
     * @returns {Uint8Array | undefined}
     */
    get blob() {
        const ret = wasm.syncmessage_blob(this.__wbg_ptr);
        return ret;
    }
    /**
     * The [`LooseCommit`] for a [`SyncMessage::LooseCommit`], if applicable.
     *
     * Decodes the signed payload to extract the underlying commit.
     * @returns {LooseCommit | undefined}
     */
    get commit() {
        const ret = wasm.syncmessage_commit(this.__wbg_ptr);
        return ret === 0 ? undefined : LooseCommit.__wrap(ret);
    }
    /**
     * The [`Fragment`] for a [`SyncMessage::Fragment`], if applicable.
     *
     * Decodes the signed payload to extract the underlying fragment.
     * @returns {Fragment | undefined}
     */
    get fragment() {
        const ret = wasm.syncmessage_fragment(this.__wbg_ptr);
        return ret === 0 ? undefined : Fragment.__wrap(ret);
    }
    /**
     * Deserialize a message from bytes.
     *
     * # Errors
     *
     * Returns a [`JsMessageDeserializationError`] if deserialization fails.
     * @param {Uint8Array} bytes
     * @returns {SyncMessage}
     */
    static fromBytes(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.syncmessage_fromBytes(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return SyncMessage.__wrap(ret[0]);
    }
    /**
     * The [`BatchSyncRequest`] for a [`SyncMessage::BatchSyncRequest`], if applicable.
     * @returns {BatchSyncRequest | undefined}
     */
    get request() {
        const ret = wasm.syncmessage_request(this.__wbg_ptr);
        return ret === 0 ? undefined : BatchSyncRequest.__wrap(ret);
    }
    /**
     * The [`BatchSyncResponse`] for a [`SyncMessage::BatchSyncResponse`], if applicable.
     * @returns {BatchSyncResponse | undefined}
     */
    get response() {
        const ret = wasm.syncmessage_response(this.__wbg_ptr);
        return ret === 0 ? undefined : BatchSyncResponse.__wrap(ret);
    }
    /**
     * The [`SedimentreeId`] associated with this message, if any.
     * @returns {SedimentreeId | undefined}
     */
    get sedimentreeId() {
        const ret = wasm.syncmessage_sedimentreeId(this.__wbg_ptr);
        return ret === 0 ? undefined : SedimentreeId.__wrap(ret);
    }
    /**
     * Serialize the message to bytes.
     * @returns {Uint8Array}
     */
    toBytes() {
        const ret = wasm.syncmessage_toBytes(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * The message variant name.
     * @returns {string}
     */
    get type() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.syncmessage_type(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) SyncMessage.prototype[Symbol.dispose] = SyncMessage.prototype.free;
exports.SyncMessage = SyncMessage;

/**
 * Statistics from a sync operation.
 *
 * The "sent" counts reflect items that were _successfully_ sent over the wire,
 * not just items that were requested.
 */
class SyncStats {
    static __wrap(ptr) {
        const obj = Object.create(SyncStats.prototype);
        obj.__wbg_ptr = ptr;
        SyncStatsFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SyncStatsFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_syncstats_free(ptr, 0);
    }
    /**
     * Number of commits received from the peer.
     * @returns {number}
     */
    get commitsReceived() {
        const ret = wasm.syncstats_commitsReceived(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Number of commits successfully sent to the peer.
     * @returns {number}
     */
    get commitsSent() {
        const ret = wasm.syncstats_commitsSent(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Number of fragments received from the peer.
     * @returns {number}
     */
    get fragmentsReceived() {
        const ret = wasm.syncstats_fragmentsReceived(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Number of fragments successfully sent to the peer.
     * @returns {number}
     */
    get fragmentsSent() {
        const ret = wasm.syncstats_fragmentsSent(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Returns true if no commits or fragments were transferred.
     *
     * Note: `remoteHeads` may still be non-empty (heads metadata is not
     * considered "data" for this check).
     * @returns {boolean}
     */
    get isEmpty() {
        const ret = wasm.syncstats_isEmpty(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * The remote peer's heads for this sedimentree.
     * @returns {CommitId[]}
     */
    get remoteHeads() {
        const ret = wasm.syncstats_remoteHeads(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Total items received (commits + fragments).
     * @returns {number}
     */
    get totalReceived() {
        const ret = wasm.syncstats_totalReceived(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Total items sent (commits + fragments).
     * @returns {number}
     */
    get totalSent() {
        const ret = wasm.syncstats_totalSent(this.__wbg_ptr);
        return ret >>> 0;
    }
}
if (Symbol.dispose) SyncStats.prototype[Symbol.dispose] = SyncStats.prototype.free;
exports.SyncStats = SyncStats;

/**
 * A Wasm wrapper around the ephemeral [`Topic`] type.
 *
 * Topics are opaque 32-byte identifiers for ephemeral pubsub channels.
 * A [`SedimentreeId`] can be used as a topic, but topics are not
 * limited to sedimentrees.
 *
 * [`SedimentreeId`]: sedimentree_core::id::SedimentreeId
 */
class Topic {
    static __wrap(ptr) {
        const obj = Object.create(Topic.prototype);
        obj.__wbg_ptr = ptr;
        TopicFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        TopicFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_topic_free(ptr, 0);
    }
    /**
     * Upcasts; to the JS-import type for [`WasmTopic`].
     * @returns {Topic}
     */
    __wasm_refgen_toWasmTopic() {
        const ret = wasm.topic___wasm_refgen_toWasmTopic(this.__wbg_ptr);
        return Topic.__wrap(ret);
    }
    /**
     * Create a topic from a 32-byte array.
     *
     * # Errors
     *
     * Returns an error if the provided byte array is not exactly 32 bytes.
     * @param {Uint8Array} bytes
     * @returns {Topic}
     */
    static fromBytes(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.topic_fromBytes(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return Topic.__wrap(ret[0]);
    }
    /**
     * Returns the raw 32 bytes of this topic.
     * @returns {Uint8Array}
     */
    toBytes() {
        const ret = wasm.topic_toBytes(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * Returns a shortened hex prefix representation (first 4 bytes + `…`).
     * @returns {string}
     */
    toString() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.topic_toString(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) Topic.prototype[Symbol.dispose] = Topic.prototype.free;
exports.Topic = Topic;

/**
 * An Ed25519 signer using the browser's `WebCrypto` API.
 *
 * This signer generates and stores Ed25519 keys using `crypto.subtle`,
 * providing secure key generation and signing operations. The key is
 * persisted to `IndexedDB` so it survives page reloads.
 *
 * # Example
 *
 * ```javascript
 * import { WebCryptoSigner } from "@automerge/subduction";
 *
 * const signer = await WebCryptoSigner.setup();
 * console.log("Peer ID:", signer.peerId().toString());
 * ```
 */
class WebCryptoSigner {
    static __wrap(ptr) {
        const obj = Object.create(WebCryptoSigner.prototype);
        obj.__wbg_ptr = ptr;
        WebCryptoSignerFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WebCryptoSignerFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_webcryptosigner_free(ptr, 0);
    }
    /**
     * Get the peer ID derived from this signer's verifying key.
     *
     * # Panics
     *
     * Panics if the stored public key bytes are invalid (should never happen).
     * @returns {PeerId}
     */
    peerId() {
        const ret = wasm.webcryptosigner_peerId(this.__wbg_ptr);
        return PeerId.__wrap(ret);
    }
    /**
     * Set up the signer, loading an existing key from `IndexedDB` or generating a new one.
     *
     * # Errors
     *
     * Returns an error if `WebCrypto` or `IndexedDB` operations fail.
     * @returns {Promise<WebCryptoSigner>}
     */
    static setup() {
        const ret = wasm.webcryptosigner_setup();
        return ret;
    }
    /**
     * Sign a message and return the 64-byte Ed25519 signature.
     *
     * # Errors
     *
     * Returns an error if `WebCrypto` signing fails.
     * @param {Uint8Array} message
     * @returns {Promise<Uint8Array>}
     */
    sign(message) {
        const ptr0 = passArray8ToWasm0(message, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.webcryptosigner_sign(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Get the 32-byte Ed25519 verifying (public) key.
     * @returns {Uint8Array}
     */
    verifyingKey() {
        const ret = wasm.webcryptosigner_verifyingKey(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) WebCryptoSigner.prototype[Symbol.dispose] = WebCryptoSigner.prototype.free;
exports.WebCryptoSigner = WebCryptoSigner;

/**
 * Clear the JavaScript logger callback registered via [`set_subduction_logger`].
 * See [`set_subduction_log_level`].
 */
function clear_subduction_logger() {
    wasm.clear_subduction_logger();
}
exports.clear_subduction_logger = clear_subduction_logger;

/**
 * Compute the commit ID of a base58-encoded ID string.
 *
 * # Errors
 *
 * Returns a `WasmFromBase58Error` if the input string is not valid base58.
 * @param {string} b58_str
 * @returns {CommitId}
 */
function commitIdOfBase58Id(b58_str) {
    const ptr0 = passStringToWasm0(b58_str, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.commitIdOfBase58Id(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return CommitId.__wrap(ret[0]);
}
exports.commitIdOfBase58Id = commitIdOfBase58Id;

/**
 * Install the panic hook and the shared rich tracing stack (reloadable level
 * filter + console layer + JS-callback layer). The initial level is read from
 * `SUBDUCTION_LOG_LEVEL` (`localStorage` / `process.env`), defaulting to WARN.
 * Idempotent; whichever subscriber installs first wins.
 */
function init() {
    wasm.init();
}
exports.init = init;

/**
 * Convenience factory — equivalent to `new MessagePortTransport(port)`.
 * @param {any} port
 * @returns {MessagePortTransport}
 */
function makeMessagePortTransport(port) {
    const ret = wasm.makeMessagePortTransport(port);
    return MessagePortTransport.__wrap(ret);
}
exports.makeMessagePortTransport = makeMessagePortTransport;

/**
 * Set the log level at runtime. Valid: `"trace"`, `"debug"`, `"info"`,
 * `"warn"`, `"error"`, `"off"`. Persisted to `localStorage`.
 *
 * This crate is the single definition site for the workspace's Wasm log
 * controls. Crates that depend on it (`subduction_wasm`, and transitively the
 * umbrella) re-export these via `pub use` rather than redefining them, so the
 * JS export appears exactly once per bundle with no duplicate-symbol clash.
 *
 * # Errors
 *
 * Returns an error if the level string is invalid or tracing is uninitialized.
 * @param {string} level
 */
function setSubductionLogLevel(level) {
    const ptr0 = passStringToWasm0(level, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.setSubductionLogLevel(ptr0, len0);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}
exports.setSubductionLogLevel = setSubductionLogLevel;

/**
 * Forward every tracing event to a JavaScript callback
 * `(level, target, message, fields)`. See [`set_subduction_log_level`].
 * @param {Function} callback
 */
function set_subduction_logger(callback) {
    wasm.set_subduction_logger(callback);
}
exports.set_subduction_logger = set_subduction_logger;
const import1 = require("./snippets/subduction_wasm-cee68c83c337ea4c/inline0.js");
const import2 = require("./snippets/subduction_wasm-cee68c83c337ea4c/inline1.js");

function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg___wasm_refgen_toWasmCommitId_761f335a68bfce0e: function(arg0) {
            const ret = arg0.__wasm_refgen_toWasmCommitId();
            _assertClass(ret, CommitId);
            var ptr1 = ret.__destroy_into_raw();
            return ptr1;
        },
        __wbg___wasm_refgen_toWasmCommitWithBlob_0e7f70b09f50713c: function(arg0) {
            const ret = arg0.__wasm_refgen_toWasmCommitWithBlob();
            _assertClass(ret, CommitWithBlob);
            var ptr1 = ret.__destroy_into_raw();
            return ptr1;
        },
        __wbg___wasm_refgen_toWasmDepth_d79743256448d708: function(arg0) {
            const ret = arg0.__wasm_refgen_toWasmDepth();
            _assertClass(ret, Depth);
            var ptr1 = ret.__destroy_into_raw();
            return ptr1;
        },
        __wbg___wasm_refgen_toWasmFragmentWithBlob_0f2d1e48f0aca2aa: function(arg0) {
            const ret = arg0.__wasm_refgen_toWasmFragmentWithBlob();
            _assertClass(ret, FragmentWithBlob);
            var ptr1 = ret.__destroy_into_raw();
            return ptr1;
        },
        __wbg___wasm_refgen_toWasmFragment_1d0bbaeff4029813: function(arg0) {
            const ret = arg0.__wasm_refgen_toWasmFragment();
            _assertClass(ret, Fragment);
            var ptr1 = ret.__destroy_into_raw();
            return ptr1;
        },
        __wbg___wasm_refgen_toWasmLooseCommit_7b89a0ab23b0763a: function(arg0) {
            const ret = arg0.__wasm_refgen_toWasmLooseCommit();
            _assertClass(ret, LooseCommit);
            var ptr1 = ret.__destroy_into_raw();
            return ptr1;
        },
        __wbg___wasm_refgen_toWasmTopic_206e3be521de173f: function(arg0) {
            const ret = arg0.__wasm_refgen_toWasmTopic();
            _assertClass(ret, Topic);
            var ptr1 = ret.__destroy_into_raw();
            return ptr1;
        },
        __wbg___wbindgen_debug_string_edece8177ad01481: function(arg0, arg1) {
            const ret = debugString(arg1);
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_is_falsy_402d3af0d5f09bc6: function(arg0) {
            const ret = !arg0;
            return ret;
        },
        __wbg___wbindgen_is_function_5cd60d5cf78b4eef: function(arg0) {
            const ret = typeof(arg0) === 'function';
            return ret;
        },
        __wbg___wbindgen_is_null_2042690d351e14f0: function(arg0) {
            const ret = arg0 === null;
            return ret;
        },
        __wbg___wbindgen_is_object_b4593df85baada48: function(arg0) {
            const val = arg0;
            const ret = typeof(val) === 'object' && val !== null;
            return ret;
        },
        __wbg___wbindgen_is_string_dde0fd9020db4434: function(arg0) {
            const ret = typeof(arg0) === 'string';
            return ret;
        },
        __wbg___wbindgen_is_undefined_35bb9f4c7fd651d5: function(arg0) {
            const ret = arg0 === undefined;
            return ret;
        },
        __wbg___wbindgen_jsval_eq_c0ed08b3e0f393b9: function(arg0, arg1) {
            const ret = arg0 === arg1;
            return ret;
        },
        __wbg___wbindgen_number_get_f73a1244370fcc2c: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'number' ? obj : undefined;
            getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_string_get_d109740c0d18f4d7: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'string' ? obj : undefined;
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_throw_9c31b086c2b26051: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg__wbg_cb_unref_3fa391f3fcdb55f8: function(arg0) {
            arg0._wbg_cb_unref();
        },
        __wbg_arrayBuffer_cb5d4748b5f3cad5: function() { return handleError(function (arg0) {
            const ret = arg0.arrayBuffer();
            return ret;
        }, arguments); },
        __wbg_authenticatedlongpoll_new: function(arg0) {
            const ret = AuthenticatedLongPoll.__wrap(arg0);
            return ret;
        },
        __wbg_authenticatedtransport_new: function(arg0) {
            const ret = AuthenticatedTransport.__wrap(arg0);
            return ret;
        },
        __wbg_authenticatedwebsocket_new: function(arg0) {
            const ret = AuthenticatedWebSocket.__wrap(arg0);
            return ret;
        },
        __wbg_authorizeConnect_8848d1f535cd27f3: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.authorizeConnect(PeerId.__wrap(arg1));
            return ret;
        }, arguments); },
        __wbg_authorizeFetch_64678ad62a787d28: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.authorizeFetch(PeerId.__wrap(arg1), SedimentreeId.__wrap(arg2));
            return ret;
        }, arguments); },
        __wbg_authorizePublish_566dffe58d4dfc4b: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.authorizePublish(PeerId.__wrap(arg1), Topic.__wrap(arg2));
            return ret;
        }, arguments); },
        __wbg_authorizePut_06a173899bece99a: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = arg0.authorizePut(PeerId.__wrap(arg1), PeerId.__wrap(arg2), SedimentreeId.__wrap(arg3));
            return ret;
        }, arguments); },
        __wbg_authorizeSubscribe_1a7d7e06fb992003: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.authorizeSubscribe(PeerId.__wrap(arg1), Topic.__wrap(arg2));
            return ret;
        }, arguments); },
        __wbg_buffer_8d6798e32d1afd34: function(arg0) {
            const ret = arg0.buffer;
            return ret;
        },
        __wbg_call_084ee3e860ee9f92: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
            const ret = arg0.call(arg1, arg2, arg3, arg4);
            return ret;
        }, arguments); },
        __wbg_call_13665d9f14390edc: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.call(arg1);
            return ret;
        }, arguments); },
        __wbg_call_93d90490983b7e17: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4, arg5) {
            const ret = arg0.call(arg1, arg2, arg3, arg4, arg5);
            return ret;
        }, arguments); },
        __wbg_call_dfde26266607c996: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.call(arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_call_faa0a261f288f846: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = arg0.call(arg1, arg2, arg3);
            return ret;
        }, arguments); },
        __wbg_close_afa2d5eecf7413c6: function(arg0) {
            arg0.close();
        },
        __wbg_close_b66c780bfc7dd92c: function(arg0) {
            arg0.close();
        },
        __wbg_close_e323e9eee669c291: function() { return handleError(function (arg0) {
            arg0.close();
        }, arguments); },
        __wbg_commitid_new: function(arg0) {
            const ret = CommitId.__wrap(arg0);
            return ret;
        },
        __wbg_commitid_unwrap: function(arg0) {
            const ret = CommitId.__unwrap(arg0);
            return ret;
        },
        __wbg_commitinput_unwrap: function(arg0) {
            const ret = CommitInput.__unwrap(arg0);
            return ret;
        },
        __wbg_commitwithblob_new: function(arg0) {
            const ret = CommitWithBlob.__wrap(arg0);
            return ret;
        },
        __wbg_containsSedimentreeId_e1f269878a4bc742: function(arg0, arg1) {
            const ret = arg0.containsSedimentreeId(arg1);
            return ret;
        },
        __wbg_contains_8cc81e164db3d554: function(arg0, arg1, arg2) {
            const ret = arg0.contains(getStringFromWasm0(arg1, arg2));
            return ret;
        },
        __wbg_continue_6f5a7d3d3bc4a125: function() { return handleError(function (arg0) {
            arg0.continue();
        }, arguments); },
        __wbg_createIndex_a67989669d7d0766: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
            const ret = arg0.createIndex(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
            return ret;
        }, arguments); },
        __wbg_createObjectStore_7aa4cf3fcb65c75a: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = arg0.createObjectStore(getStringFromWasm0(arg1, arg2), arg3);
            return ret;
        }, arguments); },
        __wbg_createObjectStore_ce6be0d6715f0760: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.createObjectStore(getStringFromWasm0(arg1, arg2));
            return ret;
        }, arguments); },
        __wbg_crypto_38df2bab126b63dc: function(arg0) {
            const ret = arg0.crypto;
            return ret;
        },
        __wbg_data_5fc79a19e47d1531: function(arg0) {
            const ret = arg0.data;
            return ret;
        },
        __wbg_debug_34920bd6235e3373: function(arg0, arg1) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.debug(getStringFromWasm0(arg0, arg1));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_debug_bd7e4951f50faa97: function(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.debug(getStringFromWasm0(arg0, arg1), getStringFromWasm0(arg2, arg3), getStringFromWasm0(arg4, arg5), getStringFromWasm0(arg6, arg7));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_defaultTimeoutMilliseconds_f39ea77d624e52fa: function(arg0) {
            const ret = arg0.defaultTimeoutMilliseconds;
            return isLikeNone(ret) ? Number.MAX_SAFE_INTEGER : (ret) >>> 0;
        },
        __wbg_deleteAllCommits_c97a1b3edabb5f91: function(arg0, arg1) {
            const ret = arg0.deleteAllCommits(arg1);
            return ret;
        },
        __wbg_deleteAllFragments_b8b116a43c63984e: function(arg0, arg1) {
            const ret = arg0.deleteAllFragments(arg1);
            return ret;
        },
        __wbg_deleteSedimentreeId_7f99273125cfafbc: function(arg0, arg1) {
            const ret = arg0.deleteSedimentreeId(arg1);
            return ret;
        },
        __wbg_delete_9c4e8b22a8b0ff3c: function() { return handleError(function (arg0) {
            const ret = arg0.delete();
            return ret;
        }, arguments); },
        __wbg_delete_bc03f88e7f14db56: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.delete(arg1);
            return ret;
        }, arguments); },
        __wbg_disconnect_d9420d9f1acad3d0: function(arg0) {
            const ret = arg0.disconnect();
            return ret;
        },
        __wbg_ephemeralPolicy_b6d595c0947c79b2: function(arg0) {
            const ret = arg0.ephemeralPolicy;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_error_08e8eecac75a593c: function(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.error(getStringFromWasm0(arg0, arg1), getStringFromWasm0(arg2, arg3), getStringFromWasm0(arg4, arg5), getStringFromWasm0(arg6, arg7));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_error_a6fa202b58aa1cd3: function(arg0, arg1) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.error(getStringFromWasm0(arg0, arg1));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_error_acac4310d298f5c5: function(arg0, arg1) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.error(getStringFromWasm0(arg0, arg1));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_error_ef9cbaece146d1d5: function() { return handleError(function (arg0) {
            const ret = arg0.error;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        }, arguments); },
        __wbg_exportKey_7f32d63ed6dd8985: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = arg0.exportKey(getStringFromWasm0(arg1, arg2), arg3);
            return ret;
        }, arguments); },
        __wbg_fetch_2998af8c54e0997c: function(arg0, arg1) {
            const ret = arg0.fetch(arg1);
            return ret;
        },
        __wbg_fetch_47ebc0e53aa08033: function(arg0, arg1) {
            const ret = arg0.fetch(arg1);
            return ret;
        },
        __wbg_filterAuthorizedFetch_4486416c4ac29a49: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            var v0 = getArrayJsValueFromWasm0(arg2, arg3).slice();
            wasm.__wbindgen_free(arg2, arg3 * 4, 4);
            const ret = arg0.filterAuthorizedFetch(PeerId.__wrap(arg1), v0);
            return ret;
        }, arguments); },
        __wbg_filterAuthorizedSubscribers_21b6d44cb51f7a06: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            var v0 = getArrayJsValueFromWasm0(arg2, arg3).slice();
            wasm.__wbindgen_free(arg2, arg3 * 4, 4);
            const ret = arg0.filterAuthorizedSubscribers(Topic.__wrap(arg1), v0);
            return ret;
        }, arguments); },
        __wbg_fragment_new: function(arg0) {
            const ret = Fragment.__wrap(arg0);
            return ret;
        },
        __wbg_fragmentinput_unwrap: function(arg0) {
            const ret = FragmentInput.__unwrap(arg0);
            return ret;
        },
        __wbg_fragmentrequested_new: function(arg0) {
            const ret = FragmentRequested.__wrap(arg0);
            return ret;
        },
        __wbg_fragmentwithblob_new: function(arg0) {
            const ret = FragmentWithBlob.__wrap(arg0);
            return ret;
        },
        __wbg_from_fa561fa561dc8031: function(arg0) {
            const ret = Array.from(arg0);
            return ret;
        },
        __wbg_generateKey_b5dfc33de52ef56a: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = arg0.generateKey(arg1, arg2 !== 0, arg3);
            return ret;
        }, arguments); },
        __wbg_getAllKeys_07d656e168400060: function() { return handleError(function (arg0) {
            const ret = arg0.getAllKeys();
            return ret;
        }, arguments); },
        __wbg_getAll_5633f36a9fdb7ebf: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.getAll(arg1);
            return ret;
        }, arguments); },
        __wbg_getRandomValues_c44a50d8cfdaebeb: function() { return handleError(function (arg0, arg1) {
            arg0.getRandomValues(arg1);
        }, arguments); },
        __wbg_get_0b3f3bb74d16b7ad: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = arg1.get(getStringFromWasm0(arg2, arg3));
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        }, arguments); },
        __wbg_get_98fdf51d029a75eb: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_get_b6f278d067d9edad: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.get(arg1);
            return ret;
        }, arguments); },
        __wbg_get_dcf82ab8aad1a593: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_get_unchecked_1dfe6d05ad91d9b7: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_has_ef192b1f278770eb: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.has(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_hashMetricOverride_692288eb9358e974: function(arg0) {
            const ret = arg0.hashMetricOverride;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_headers_18f39f24d3837dc1: function(arg0) {
            const ret = arg0.headers;
            return ret;
        },
        __wbg_host_ffb95c4e3af9f12f: function(arg0, arg1) {
            const ret = arg1.host;
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_href_299e42f92257b25c: function(arg0, arg1) {
            const ret = arg1.href;
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_importKey_23679217c2a0386e: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4, arg5, arg6) {
            const ret = arg0.importKey(getStringFromWasm0(arg1, arg2), arg3, arg4, arg5 !== 0, arg6);
            return ret;
        }, arguments); },
        __wbg_indexNames_02343634d37560b2: function(arg0) {
            const ret = arg0.indexNames;
            return ret;
        },
        __wbg_index_1eb6fae6472ecb14: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.index(getStringFromWasm0(arg1, arg2));
            return ret;
        }, arguments); },
        __wbg_indexeddbstorage_new: function(arg0) {
            const ret = IndexedDbStorage.__wrap(arg0);
            return ret;
        },
        __wbg_instanceof_ArrayBuffer_53db37b06f6b9afe: function(arg0) {
            let result;
            try {
                result = arg0 instanceof ArrayBuffer;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Crypto_67290f92514e0aff: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Crypto;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_IdbCursor_9dd6ddde8160efcf: function(arg0) {
            let result;
            try {
                result = arg0 instanceof IDBCursor;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_IdbDatabase_102b0fe5255eee9c: function(arg0) {
            let result;
            try {
                result = arg0 instanceof IDBDatabase;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_IdbFactory_49a7625c235ffb0a: function(arg0) {
            let result;
            try {
                result = arg0 instanceof IDBFactory;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_IdbOpenDbRequest_2cce7fd687448f0f: function(arg0) {
            let result;
            try {
                result = arg0 instanceof IDBOpenDBRequest;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_IdbRequest_eef501cff5d0b7c1: function(arg0) {
            let result;
            try {
                result = arg0 instanceof IDBRequest;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Promise_09012cfa9708520a: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Promise;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Response_ecfc823e8fb354e2: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Response;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Uint8Array_abd07d4bd221d50b: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Uint8Array;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Window_faa5cf994f49cca7: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Window;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_WorkerGlobalScope_a93ee1765e6a23bf: function(arg0) {
            let result;
            try {
                result = arg0 instanceof WorkerGlobalScope;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_isArray_94898ed3aad6947b: function(arg0) {
            const ret = Array.isArray(arg0);
            return ret;
        },
        __wbg_isSafeInteger_01e964d144ad3a55: function(arg0) {
            const ret = Number.isSafeInteger(arg0);
            return ret;
        },
        __wbg_length_2591a0f4f659a55c: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_length_56fcd3e2b7e0299d: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_loadAllCommits_1ae4c040bb42b5ba: function(arg0, arg1) {
            const ret = arg0.loadAllCommits(arg1);
            return ret;
        },
        __wbg_loadAllFragments_bb9cad52754fe5c9: function(arg0, arg1) {
            const ret = arg0.loadAllFragments(arg1);
            return ret;
        },
        __wbg_loadAllSedimentreeIds_33adb668316be632: function(arg0) {
            const ret = arg0.loadAllSedimentreeIds();
            return ret;
        },
        __wbg_loadCommit_04946b0dcff6f110: function(arg0, arg1, arg2) {
            const ret = arg0.loadCommit(arg1, arg2);
            return ret;
        },
        __wbg_loadFragment_e40d245f52cdae98: function(arg0, arg1, arg2) {
            const ret = arg0.loadFragment(arg1, arg2);
            return ret;
        },
        __wbg_log_0a32538eefbe6799: function(arg0, arg1) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.log(getStringFromWasm0(arg0, arg1));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_log_3dc517c67d1aca1b: function(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.log(getStringFromWasm0(arg0, arg1), getStringFromWasm0(arg2, arg3), getStringFromWasm0(arg4, arg5), getStringFromWasm0(arg6, arg7));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_loosecommit_new: function(arg0) {
            const ret = LooseCommit.__wrap(arg0);
            return ret;
        },
        __wbg_mark_2750ec75966b2615: function(arg0, arg1) {
            performance.mark(getStringFromWasm0(arg0, arg1));
        },
        __wbg_maxResidentTrees_4ba238c56a970ca7: function(arg0) {
            const ret = arg0.maxResidentTrees;
            return isLikeNone(ret) ? Number.MAX_SAFE_INTEGER : (ret) >>> 0;
        },
        __wbg_measure_e4f071ac4398e4d0: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            let deferred0_0;
            let deferred0_1;
            let deferred1_0;
            let deferred1_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                deferred1_0 = arg2;
                deferred1_1 = arg3;
                performance.measure(getStringFromWasm0(arg0, arg1), getStringFromWasm0(arg2, arg3));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
                wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
            }
        }, arguments); },
        __wbg_messageporttransport_new: function(arg0) {
            const ret = MessagePortTransport.__wrap(arg0);
            return ret;
        },
        __wbg_msCrypto_bd5a034af96bcba6: function(arg0) {
            const ret = arg0.msCrypto;
            return ret;
        },
        __wbg_new_02d162bc6cf02f60: function() {
            const ret = new Object();
            return ret;
        },
        __wbg_new_0d10e9bbbdeecb5d: function() { return handleError(function () {
            const ret = new MessageChannel();
            return ret;
        }, arguments); },
        __wbg_new_1f236d63ba0c4784: function(arg0, arg1) {
            const ret = new Error(getStringFromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_new_227d7c05414eb861: function() {
            const ret = new Error();
            return ret;
        },
        __wbg_new_310879b66b6e95e1: function() {
            const ret = new Array();
            return ret;
        },
        __wbg_new_7ddec6de44ff8f5d: function(arg0) {
            const ret = new Uint8Array(arg0);
            return ret;
        },
        __wbg_new_b1280f836646084c: function() { return handleError(function (arg0, arg1) {
            const ret = new WebSocket(getStringFromWasm0(arg0, arg1));
            return ret;
        }, arguments); },
        __wbg_new_c75e85159e69cd5e: function(arg0, arg1) {
            const ret = new TypeError(getStringFromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_new_d8dfd33fa007511d: function(arg0, arg1) {
            try {
                var state0 = {a: arg0, b: arg1};
                var cb0 = (arg0, arg1) => {
                    const a = state0.a;
                    state0.a = 0;
                    try {
                        return wasm_bindgen__convert__closures_____invoke__h8ef3110ad623c422(a, state0.b, arg0, arg1);
                    } finally {
                        state0.a = a;
                    }
                };
                const ret = new Promise(cb0);
                return ret;
            } finally {
                state0.a = 0;
            }
        },
        __wbg_new_ee0be486d8f01282: function() { return handleError(function () {
            const ret = new Headers();
            return ret;
        }, arguments); },
        __wbg_new_from_slice_269e35316ed2d061: function(arg0, arg1) {
            const ret = new Uint8Array(getArrayU8FromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_new_typed_c072c4ce9a2a0cdf: function(arg0, arg1) {
            try {
                var state0 = {a: arg0, b: arg1};
                var cb0 = (arg0, arg1) => {
                    const a = state0.a;
                    state0.a = 0;
                    try {
                        return wasm_bindgen__convert__closures_____invoke__h8ef3110ad623c422(a, state0.b, arg0, arg1);
                    } finally {
                        state0.a = a;
                    }
                };
                const ret = new Promise(cb0);
                return ret;
            } finally {
                state0.a = 0;
            }
        },
        __wbg_new_with_length_99887c91eae4abab: function(arg0) {
            const ret = new Uint8Array(arg0 >>> 0);
            return ret;
        },
        __wbg_new_with_length_c2a8f9ac6aaaac03: function(arg0) {
            const ret = new Array(arg0 >>> 0);
            return ret;
        },
        __wbg_new_with_str_and_init_ffe9977c986ea039: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = new Request(getStringFromWasm0(arg0, arg1), arg2);
            return ret;
        }, arguments); },
        __wbg_node_84ea875411254db1: function(arg0) {
            const ret = arg0.node;
            return ret;
        },
        __wbg_now_81363d44c96dd239: function() {
            const ret = Date.now();
            return ret;
        },
        __wbg_objectStoreNames_7eb10221ec542d29: function(arg0) {
            const ret = arg0.objectStoreNames;
            return ret;
        },
        __wbg_objectStore_b28adb984a77902e: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.objectStore(getStringFromWasm0(arg1, arg2));
            return ret;
        }, arguments); },
        __wbg_of_5ac20b48264ca018: function(arg0, arg1) {
            const ret = Array.of(arg0, arg1);
            return ret;
        },
        __wbg_of_d694dacacb7afa7f: function(arg0) {
            const ret = Array.of(arg0);
            return ret;
        },
        __wbg_onDisconnect_4b11d965870a11cd: function(arg0, arg1) {
            arg0.onDisconnect(arg1);
        },
        __wbg_onEphemeral_fe79d624f39817f2: function(arg0) {
            const ret = arg0.onEphemeral;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_onMessage_9351f2f00f8ecc49: function() { return handleError(function (arg0, arg1, arg2) {
            arg0.onMessage(arg1, PeerId.__wrap(arg2));
        }, arguments); },
        __wbg_onPeerDisconnect_84f2ecfe0fc8b357: function() { return handleError(function (arg0, arg1) {
            arg0.onPeerDisconnect(PeerId.__wrap(arg1));
        }, arguments); },
        __wbg_onRemoteHeads_6d2fd7bf1ca0251b: function(arg0) {
            const ret = arg0.onRemoteHeads;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_only_3094814d82083194: function() { return handleError(function (arg0) {
            const ret = IDBKeyRange.only(arg0);
            return ret;
        }, arguments); },
        __wbg_openKeyCursor_195ed0a9ee188505: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.openKeyCursor(arg1);
            return ret;
        }, arguments); },
        __wbg_open_40ab11cdd8f5ac5a: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = arg0.open(getStringFromWasm0(arg1, arg2), arg3 >>> 0);
            return ret;
        }, arguments); },
        __wbg_peerbatchsyncresult_new: function(arg0) {
            const ret = PeerBatchSyncResult.__wrap(arg0);
            return ret;
        },
        __wbg_peerid_new: function(arg0) {
            const ret = PeerId.__wrap(arg0);
            return ret;
        },
        __wbg_peerresultmap_new: function(arg0) {
            const ret = PeerResultMap.__wrap(arg0);
            return ret;
        },
        __wbg_policy_4b5ac6a9d5fd271c: function(arg0) {
            const ret = arg0.policy;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_port1_43d1f7dfdc192929: function(arg0) {
            const ret = arg0.port1;
            return ret;
        },
        __wbg_port2_8b1be7acb46ef0ee: function(arg0) {
            const ret = arg0.port2;
            return ret;
        },
        __wbg_postMessage_04ace1099fe05014: function(arg0, arg1) {
            arg0.postMessage(arg1);
        },
        __wbg_process_44c7a14e11e9f69e: function(arg0) {
            const ret = arg0.process;
            return ret;
        },
        __wbg_prototypesetcall_5f9bdc8d75e07276: function(arg0, arg1, arg2) {
            Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
        },
        __wbg_push_b77c476b01548d0a: function(arg0, arg1) {
            const ret = arg0.push(arg1);
            return ret;
        },
        __wbg_put_848906967513a84d: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.put(arg1);
            return ret;
        }, arguments); },
        __wbg_put_ad17713e2c2f12fa: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.put(arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_queueMicrotask_78d584b53af520f5: function(arg0) {
            const ret = arg0.queueMicrotask;
            return ret;
        },
        __wbg_queueMicrotask_b39ea83c7f01971a: function(arg0) {
            queueMicrotask(arg0);
        },
        __wbg_randomFillSync_6c25eac9869eb53c: function() { return handleError(function (arg0, arg1) {
            arg0.randomFillSync(arg1);
        }, arguments); },
        __wbg_readyState_a1a00cc8898812ac: function(arg0) {
            const ret = arg0.readyState;
            return ret;
        },
        __wbg_recvBytes_0c11505d38ab654a: function(arg0) {
            const ret = arg0.recvBytes();
            return ret;
        },
        __wbg_require_b4edbdcf3e2a1ef0: function() { return handleError(function () {
            const ret = module.require;
            return ret;
        }, arguments); },
        __wbg_resolve_d17db9352f5a220e: function(arg0) {
            const ret = Promise.resolve(arg0);
            return ret;
        },
        __wbg_result_c4cb33cd39c97cac: function() { return handleError(function (arg0) {
            const ret = arg0.result;
            return ret;
        }, arguments); },
        __wbg_saveBatchAll_523c737788be4791: function(arg0, arg1, arg2, arg3) {
            const ret = arg0.saveBatchAll(arg1, arg2, arg3);
            return ret;
        },
        __wbg_saveCommit_13624c4f3dea9dc4: function(arg0, arg1, arg2, arg3, arg4) {
            const ret = arg0.saveCommit(arg1, arg2, arg3, arg4);
            return ret;
        },
        __wbg_saveFragment_be8756017b452410: function(arg0, arg1, arg2, arg3, arg4) {
            const ret = arg0.saveFragment(arg1, arg2, arg3, arg4);
            return ret;
        },
        __wbg_saveSedimentreeId_34b06b763236b605: function(arg0, arg1) {
            const ret = arg0.saveSedimentreeId(arg1);
            return ret;
        },
        __wbg_sedimentreeheads_new: function(arg0) {
            const ret = SedimentreeHeads.__wrap(arg0);
            return ret;
        },
        __wbg_sedimentreeid_new: function(arg0) {
            const ret = SedimentreeId.__wrap(arg0);
            return ret;
        },
        __wbg_sedimentreeid_unwrap: function(arg0) {
            const ret = SedimentreeId.__unwrap(arg0);
            return ret;
        },
        __wbg_sendBytes_e6456dfab5212344: function(arg0, arg1) {
            const ret = arg0.sendBytes(arg1);
            return ret;
        },
        __wbg_send_b9d998a91cbc8429: function() { return handleError(function (arg0, arg1, arg2) {
            arg0.send(getArrayU8FromWasm0(arg1, arg2));
        }, arguments); },
        __wbg_serviceName_4a25fdb1a1e9c5b6: function(arg0, arg1) {
            const ret = arg1.serviceName;
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_setTimeout_67b1fe42829d6451: function(arg0, arg1) {
            const ret = setTimeout(arg0, arg1);
            return ret;
        },
        __wbg_set_78ea6a19f4818587: function(arg0, arg1, arg2) {
            arg0[arg1 >>> 0] = arg2;
        },
        __wbg_set_a0e911be3da02782: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = Reflect.set(arg0, arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_set_auto_increment_4ee17cf1e95c0938: function(arg0, arg1) {
            arg0.autoIncrement = arg1 !== 0;
        },
        __wbg_set_binaryType_5c0002dfcf194934: function(arg0, arg1) {
            arg0.binaryType = __wbindgen_enum_BinaryType[arg1];
        },
        __wbg_set_body_7f56457720e81672: function(arg0, arg1) {
            arg0.body = arg1;
        },
        __wbg_set_d57e5106f0271787: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
            arg0.set(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
        }, arguments); },
        __wbg_set_headers_97ed66619adb1e3e: function(arg0, arg1) {
            arg0.headers = arg1;
        },
        __wbg_set_key_path_8f8e19a098d0851c: function(arg0, arg1) {
            arg0.keyPath = arg1;
        },
        __wbg_set_method_4d69a1a7e34c0aca: function(arg0, arg1, arg2) {
            arg0.method = getStringFromWasm0(arg1, arg2);
        },
        __wbg_set_mode_dfc59bbbe25b1d14: function(arg0, arg1) {
            arg0.mode = __wbindgen_enum_RequestMode[arg1];
        },
        __wbg_set_name_e500733c75ec36b0: function(arg0, arg1, arg2) {
            arg0.name = getStringFromWasm0(arg1, arg2);
        },
        __wbg_set_onclose_3121e15055418a37: function(arg0, arg1) {
            arg0.onclose = arg1;
        },
        __wbg_set_onerror_1dd52df6279c8dd2: function(arg0, arg1) {
            arg0.onerror = arg1;
        },
        __wbg_set_onerror_38740b892815eedc: function(arg0, arg1) {
            arg0.onerror = arg1;
        },
        __wbg_set_onmessage_9eb2cf76e70783ad: function(arg0, arg1) {
            arg0.onmessage = arg1;
        },
        __wbg_set_onmessage_d7390c3556ca0c88: function(arg0, arg1) {
            arg0.onmessage = arg1;
        },
        __wbg_set_onopen_6f3fc5e2ad3144f1: function(arg0, arg1) {
            arg0.onopen = arg1;
        },
        __wbg_set_onsuccess_b556141053d02ea7: function(arg0, arg1) {
            arg0.onsuccess = arg1;
        },
        __wbg_set_onupgradeneeded_f885fa17614acd2b: function(arg0, arg1) {
            arg0.onupgradeneeded = arg1;
        },
        __wbg_sign_86c546a8f2bf382e: function(arg0, arg1) {
            const ret = arg0.sign(arg1);
            return ret;
        },
        __wbg_sign_ba5e5ce94b9a0e7d: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
            const ret = arg0.sign(arg1, arg2, getArrayU8FromWasm0(arg3, arg4));
            return ret;
        }, arguments); },
        __wbg_signedfragment_new: function(arg0) {
            const ret = SignedFragment.__wrap(arg0);
            return ret;
        },
        __wbg_signedfragment_unwrap: function(arg0) {
            const ret = SignedFragment.__unwrap(arg0);
            return ret;
        },
        __wbg_signedloosecommit_new: function(arg0) {
            const ret = SignedLooseCommit.__wrap(arg0);
            return ret;
        },
        __wbg_signedloosecommit_unwrap: function(arg0) {
            const ret = SignedLooseCommit.__unwrap(arg0);
            return ret;
        },
        __wbg_signer_27a7f52a102e92c8: function(arg0) {
            const ret = arg0.signer;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_stack_3b0d974bbf31e44f: function(arg0, arg1) {
            const ret = arg1.stack;
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_start_1a084dca5d0c3430: function(arg0) {
            arg0.start();
        },
        __wbg_static_accessor_GLOBAL_THIS_02344c9b09eb08a9: function() {
            const ret = typeof globalThis === 'undefined' ? null : globalThis;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_GLOBAL_ac6d4ac874d5cd54: function() {
            const ret = typeof global === 'undefined' ? null : global;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_SELF_9b2406c23aeb2023: function() {
            const ret = typeof self === 'undefined' ? null : self;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_WINDOW_b34d2126934e16ba: function() {
            const ret = typeof window === 'undefined' ? null : window;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_status_0853c9f5752c7ee2: function(arg0) {
            const ret = arg0.status;
            return ret;
        },
        __wbg_storage_3b1c55f37716550d: function(arg0) {
            const ret = arg0.storage;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_subarray_7c6a0da8f3b4a1ba: function(arg0, arg1, arg2) {
            const ret = arg0.subarray(arg1 >>> 0, arg2 >>> 0);
            return ret;
        },
        __wbg_subductionhttplongpoll_new: function(arg0) {
            const ret = SubductionHttpLongPoll.__wrap(arg0);
            return ret;
        },
        __wbg_subductionwebsocket_new: function(arg0) {
            const ret = SubductionWebSocket.__wrap(arg0);
            return ret;
        },
        __wbg_subtle_a5e9e758ed333bed: function(arg0) {
            const ret = arg0.subtle;
            return ret;
        },
        __wbg_target_84e05e84ffc12989: function(arg0) {
            const ret = arg0.target;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_then_837494e384b37459: function(arg0, arg1) {
            const ret = arg0.then(arg1);
            return ret;
        },
        __wbg_then_bd927500e8905df2: function(arg0, arg1, arg2) {
            const ret = arg0.then(arg1, arg2);
            return ret;
        },
        __wbg_topic_new: function(arg0) {
            const ret = Topic.__wrap(arg0);
            return ret;
        },
        __wbg_transaction_38cea079a9d82352: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.transaction(arg1, __wbindgen_enum_IdbTransactionMode[arg2]);
            return ret;
        }, arguments); },
        __wbg_transaction_b7261fed68fa4264: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = arg0.transaction(getStringFromWasm0(arg1, arg2), __wbindgen_enum_IdbTransactionMode[arg3]);
            return ret;
        }, arguments); },
        __wbg_transaction_fbb22de1d45411c2: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.transaction(getStringFromWasm0(arg1, arg2));
            return ret;
        }, arguments); },
        __wbg_tryIntoJsSedimentreeIdsArray_f9d7cbd4568fbe86: function() { return handleError(function (arg0, arg1) {
            const ret = tryIntoJsSedimentreeIdsArray(arg1);
            const ptr1 = passArrayJsValueToWasm0(ret, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        }, arguments); },
        __wbg_verifyingKey_678a7e41c619caa9: function(arg0) {
            const ret = arg0.verifyingKey();
            return ret;
        },
        __wbg_versions_276b2795b1c6a219: function(arg0) {
            const ret = arg0.versions;
            return ret;
        },
        __wbg_warn_156448bc30d3aeec: function(arg0, arg1) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.warn(getStringFromWasm0(arg0, arg1));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_warn_3fca2112044055e5: function(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.warn(getStringFromWasm0(arg0, arg1), getStringFromWasm0(arg2, arg3), getStringFromWasm0(arg4, arg5), getStringFromWasm0(arg6, arg7));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_webcryptosigner_new: function(arg0) {
            const ret = WebCryptoSigner.__wrap(arg0);
            return ret;
        },
        __wbindgen_cast_0000000000000001: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [Externref], shim_idx: 420, ret: Result(Unit), inner_ret: Some(Result(Unit)) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__h6e0461e306ad1f34);
            return ret;
        },
        __wbindgen_cast_0000000000000002: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [Externref], shim_idx: 591, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__ha2daa47ddbda2e84);
            return ret;
        },
        __wbindgen_cast_0000000000000003: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [NamedExternref("Event")], shim_idx: 16, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__h47e877a3f87f9efa);
            return ret;
        },
        __wbindgen_cast_0000000000000004: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [NamedExternref("IDBVersionChangeEvent")], shim_idx: 16, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__h47e877a3f87f9efa_3);
            return ret;
        },
        __wbindgen_cast_0000000000000005: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [NamedExternref("MessageEvent")], shim_idx: 591, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__ha2daa47ddbda2e84_4);
            return ret;
        },
        __wbindgen_cast_0000000000000006: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [], shim_idx: 589, ret: Unit, inner_ret: Some(Unit) }, mutable: false }) -> Externref`.
            const ret = makeClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__h590bd7256dd06378);
            return ret;
        },
        __wbindgen_cast_0000000000000007: function(arg0) {
            // Cast intrinsic for `F64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_cast_0000000000000008: function(arg0, arg1) {
            // Cast intrinsic for `Ref(Slice(U8)) -> NamedExternref("Uint8Array")`.
            const ret = getArrayU8FromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_cast_0000000000000009: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_cast_000000000000000a: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("CommitId")) -> Externref`.
            const ret = v0;
            return ret;
        },
        __wbindgen_cast_000000000000000b: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("CommitWithBlob")) -> Externref`.
            const ret = v0;
            return ret;
        },
        __wbindgen_cast_000000000000000c: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("Fragment")) -> Externref`.
            const ret = v0;
            return ret;
        },
        __wbindgen_cast_000000000000000d: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("FragmentWithBlob")) -> Externref`.
            const ret = v0;
            return ret;
        },
        __wbindgen_cast_000000000000000e: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("LooseCommit")) -> Externref`.
            const ret = v0;
            return ret;
        },
        __wbindgen_cast_000000000000000f: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("PeerId")) -> Externref`.
            const ret = v0;
            return ret;
        },
        __wbindgen_cast_0000000000000010: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("SedimentreeHeads")) -> Externref`.
            const ret = v0;
            return ret;
        },
        __wbindgen_cast_0000000000000011: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("SedimentreeId")) -> Externref`.
            const ret = v0;
            return ret;
        },
        __wbindgen_cast_0000000000000012: function(arg0, arg1) {
            var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
            wasm.__wbindgen_free(arg0, arg1 * 4, 4);
            // Cast intrinsic for `Vector(NamedExternref("Uint8Array")) -> Externref`.
            const ret = v0;
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./automerge_subduction_wasm_bg.js": import0,
        "./snippets/subduction_wasm-cee68c83c337ea4c/inline0.js": import1,
        "./snippets/subduction_wasm-cee68c83c337ea4c/inline1.js": import2,
    };
}

function wasm_bindgen__convert__closures_____invoke__h590bd7256dd06378(arg0, arg1) {
    wasm.wasm_bindgen__convert__closures_____invoke__h590bd7256dd06378(arg0, arg1);
}

function wasm_bindgen__convert__closures_____invoke__ha2daa47ddbda2e84(arg0, arg1, arg2) {
    wasm.wasm_bindgen__convert__closures_____invoke__ha2daa47ddbda2e84(arg0, arg1, arg2);
}

function wasm_bindgen__convert__closures_____invoke__h47e877a3f87f9efa(arg0, arg1, arg2) {
    wasm.wasm_bindgen__convert__closures_____invoke__h47e877a3f87f9efa(arg0, arg1, arg2);
}

function wasm_bindgen__convert__closures_____invoke__h47e877a3f87f9efa_3(arg0, arg1, arg2) {
    wasm.wasm_bindgen__convert__closures_____invoke__h47e877a3f87f9efa_3(arg0, arg1, arg2);
}

function wasm_bindgen__convert__closures_____invoke__ha2daa47ddbda2e84_4(arg0, arg1, arg2) {
    wasm.wasm_bindgen__convert__closures_____invoke__ha2daa47ddbda2e84_4(arg0, arg1, arg2);
}

function wasm_bindgen__convert__closures_____invoke__h6e0461e306ad1f34(arg0, arg1, arg2) {
    const ret = wasm.wasm_bindgen__convert__closures_____invoke__h6e0461e306ad1f34(arg0, arg1, arg2);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

function wasm_bindgen__convert__closures_____invoke__h8ef3110ad623c422(arg0, arg1, arg2, arg3) {
    wasm.wasm_bindgen__convert__closures_____invoke__h8ef3110ad623c422(arg0, arg1, arg2, arg3);
}


const __wbindgen_enum_BinaryType = ["blob", "arraybuffer"];


const __wbindgen_enum_IdbTransactionMode = ["readonly", "readwrite", "versionchange", "readwriteflush", "cleanup"];


const __wbindgen_enum_RequestMode = ["same-origin", "no-cors", "cors", "navigate"];
const MemorySignerFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_memorysigner_free(ptr, 1));
const MemoryStorageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_memorystorage_free(ptr, 1));
const PeerBatchSyncResultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_peerbatchsyncresult_free(ptr, 1));
const AuthenticatedLongPollFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_authenticatedlongpoll_free(ptr, 1));
const AuthenticatedTransportFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_authenticatedtransport_free(ptr, 1));
const AuthenticatedWebSocketFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_authenticatedwebsocket_free(ptr, 1));
const BatchSyncRequestFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_batchsyncrequest_free(ptr, 1));
const BatchSyncResponseFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_batchsyncresponse_free(ptr, 1));
const BlobMetaFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_blobmeta_free(ptr, 1));
const CallErrorFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_callerror_free(ptr, 1));
const CommitIdFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_commitid_free(ptr, 1));
const CommitInputFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_commitinput_free(ptr, 1));
const CommitWithBlobFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_commitwithblob_free(ptr, 1));
const DepthFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_depth_free(ptr, 1));
const DigestFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_digest_free(ptr, 1));
const FragmentFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_fragment_free(ptr, 1));
const FragmentInputFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_fragmentinput_free(ptr, 1));
const FragmentRequestedFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_fragmentrequested_free(ptr, 1));
const FragmentWithBlobFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_fragmentwithblob_free(ptr, 1));
const FragmentsArrayFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_fragmentsarray_free(ptr, 1));
const HashMetricFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_hashmetric_free(ptr, 1));
const SubductionHttpLongPollFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_subductionhttplongpoll_free(ptr, 1));
const IndexedDbStorageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_indexeddbstorage_free(ptr, 1));
const SubductionLongPollFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_subductionlongpoll_free(ptr, 1));
const LooseCommitFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_loosecommit_free(ptr, 1));
const SyncMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_syncmessage_free(ptr, 1));
const MessagePortTransportFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_messageporttransport_free(ptr, 1));
const NonceFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_nonce_free(ptr, 1));
const PeerIdFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_peerid_free(ptr, 1));
const PeerResultMapFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_peerresultmap_free(ptr, 1));
const RequestIdFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_requestid_free(ptr, 1));
const SedimentreeFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sedimentree_free(ptr, 1));
const SedimentreeHeadsFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sedimentreeheads_free(ptr, 1));
const SedimentreeIdFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sedimentreeid_free(ptr, 1));
const SedimentreeIdsArrayFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sedimentreeidsarray_free(ptr, 1));
const SignedFragmentFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_signedfragment_free(ptr, 1));
const SignedLooseCommitFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_signedloosecommit_free(ptr, 1));
const SubductionFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_subduction_free(ptr, 1));
const SyncStatsFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_syncstats_free(ptr, 1));
const TopicFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_topic_free(ptr, 1));
const SubductionWebSocketFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_subductionwebsocket_free(ptr, 1));
const WebCryptoSignerFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_webcryptosigner_free(ptr, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
}

const CLOSURE_DTORS = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(state => wasm.__wbindgen_destroy_closure(state.a, state.b));

function debugString(val) {
    // primitive types
    const type = typeof val;
    if (type == 'number' || type == 'boolean' || val == null) {
        return  `${val}`;
    }
    if (type == 'string') {
        return `"${val}"`;
    }
    if (type == 'symbol') {
        const description = val.description;
        if (description == null) {
            return 'Symbol';
        } else {
            return `Symbol(${description})`;
        }
    }
    if (type == 'function') {
        const name = val.name;
        if (typeof name == 'string' && name.length > 0) {
            return `Function(${name})`;
        } else {
            return 'Function';
        }
    }
    // objects
    if (Array.isArray(val)) {
        const length = val.length;
        let debug = '[';
        if (length > 0) {
            debug += debugString(val[0]);
        }
        for(let i = 1; i < length; i++) {
            debug += ', ' + debugString(val[i]);
        }
        debug += ']';
        return debug;
    }
    // Test for built-in
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches && builtInMatches.length > 1) {
        className = builtInMatches[1];
    } else {
        // Failed to match the standard '[object ClassName]'
        return toString.call(val);
    }
    if (className == 'Object') {
        // we're a user defined class or Object
        // JSON.stringify avoids problems with cycles, and is generally much
        // easier than looping through ownProperties of `val`.
        try {
            return 'Object(' + JSON.stringify(val) + ')';
        } catch (_) {
            return 'Object';
        }
    }
    // errors
    if (val instanceof Error) {
        return `${val.name}: ${val.message}\n${val.stack}`;
    }
    // TODO we could test for more things here, like `Set`s and `Map`s.
    return className;
}

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getDataViewMemory0();
    const result = [];
    for (let i = ptr; i < ptr + 4 * len; i += 4) {
        result.push(wasm.__wbindgen_externrefs.get(mem.getUint32(i, true)));
    }
    wasm.__externref_drop_slice(ptr, len);
    return result;
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function getStringFromWasm0(ptr, len) {
    return decodeText(ptr >>> 0, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function makeClosure(arg0, arg1, f) {
    const state = { a: arg0, b: arg1, cnt: 1 };
    const real = (...args) => {

        // First up with a closure we increment the internal reference
        // count. This ensures that the Rust closure environment won't
        // be deallocated while we're invoking it.
        state.cnt++;
        try {
            return f(state.a, state.b, ...args);
        } finally {
            real._wbg_cb_unref();
        }
    };
    real._wbg_cb_unref = () => {
        if (--state.cnt === 0) {
            wasm.__wbindgen_destroy_closure(state.a, state.b);
            state.a = 0;
            CLOSURE_DTORS.unregister(state);
        }
    };
    CLOSURE_DTORS.register(real, state, state);
    return real;
}

function makeMutClosure(arg0, arg1, f) {
    const state = { a: arg0, b: arg1, cnt: 1 };
    const real = (...args) => {

        // First up with a closure we increment the internal reference
        // count. This ensures that the Rust closure environment won't
        // be deallocated while we're invoking it.
        state.cnt++;
        const a = state.a;
        state.a = 0;
        try {
            return f(a, state.b, ...args);
        } finally {
            state.a = a;
            real._wbg_cb_unref();
        }
    };
    real._wbg_cb_unref = () => {
        if (--state.cnt === 0) {
            wasm.__wbindgen_destroy_closure(state.a, state.b);
            state.a = 0;
            CLOSURE_DTORS.unregister(state);
        }
    };
    CLOSURE_DTORS.register(real, state, state);
    return real;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passArrayJsValueToWasm0(array, malloc) {
    const ptr = malloc(array.length * 4, 4) >>> 0;
    for (let i = 0; i < array.length; i++) {
        const add = addToExternrefTable0(array[i]);
        getDataViewMemory0().setUint32(ptr + 4 * i, add, true);
    }
    WASM_VECTOR_LEN = array.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
function decodeText(ptr, len) {
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

const wasmPath = `${__dirname}/automerge_subduction_wasm_bg.wasm`;
const wasmBytes = require('fs').readFileSync(wasmPath);
const wasmModule = new WebAssembly.Module(wasmBytes);
let wasmInstance = new WebAssembly.Instance(wasmModule, __wbg_get_imports());
let wasm = wasmInstance.exports;
wasm.__wbindgen_start();
