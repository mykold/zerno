
export function tryIntoLooseCommitArray(xs) { return xs; }
