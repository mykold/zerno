
export function makeOpenEphemeralPolicy() {
    return {
        authorizeSubscribe() { return Promise.resolve(); },
        authorizePublish() { return Promise.resolve(); },
        filterAuthorizedSubscribers(_topic, peers) { return Promise.resolve(peers); },
    };
}
